#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Synthesised drum kits for firmware/src/drum_synth.c -> felucca_drumkits.h

Each kit has 16 sounds (lanes), one per white key of the drum track:
KICK SNARE CLAP CHH OHH TOMLO TOMHI CRASH RIDE SHAKER CONGA RIM COWBELL CLAVE KICK2 SNARE2.
A sound is written in musical units (Hz, ms, octaves, dB) and converted to the table indices
the firmware uses (MIDI note + 1/16, DECAY_K and CUTOFF_HZ indices). The level of every sound
(LEVELS, tools/drumkit_levels.json) is measured, not guessed: tests/drum_level.c renders each
sound, and every kit comes out as loud as the others, each lane at its place in the mix.

  tools/gen_drumkits.py OUT.h
"""
import copy
import json
import math
import sys
from pathlib import Path

LANES = ["KICK", "SNARE", "CLAP", "CHH", "OHH", "TOMLO", "TOMHI", "CRASH", "RIDE", "SHAKER",
         "CONGA", "RIM", "COWBELL", "CLAVE", "KICK2", "SNARE2"]
WAVE = {None: 0, "sine": 1, "tri": 2, "square": 3, "fm": 4, "bell": 5}
SRC = {None: 0, "white": 1, "metal": 2, "cym": 3, "chip": 4, "clap": 0x11,
       "chain": 0x12}                # Jangada: CLAP bursts of the METAL squares (chains)
FMODE = {None: 0, "lp": 1, "bp": 2, "hp": 3}
LEVELS_FILE = Path(__file__).with_name("drumkit_levels.json")


def note16(hz):                    # MIDI note and 1/16 semitones
    n = 69 + 12 * math.log2(hz / 440.0)
    n16 = max(0, min(127 * 16 + 15, int(round(n * 16))))
    return n16 >> 4, n16 & 15


def note(hz):
    return max(0, min(127, int(round(69 + 12 * math.log2(hz / 440.0)))))


def dec(ms):                       # DECAY_K: 5 ms .. 4 s, index 0..127
    ms = max(5.0, min(4000.0, ms))
    return int(round(127 * math.log(ms / 5.0) / math.log(800)))


def cut(hz):                       # CUTOFF_HZ: 30 Hz .. 16 kHz
    hz = max(30.0, min(16000.0, hz))
    return int(round(127 * math.log(hz / 30.0) / math.log(16000 / 30)))


STEPS_PER_OCT = 127 / math.log2(16000 / 30)


def S(wave=None, hz=100, bend=0, bt=20, hold=0, decay=100, tlev=110, t2=0.0, t2lev=0, click=0,
      src=None, nlev=0, nhold=0, ndec=50, filt=None, fenv=0.0, hpf=None, chip=None, drive=0, level=0.0):
    """wave/hz: the tone; bend semitones falling over bt ms (Jangada: < 0, rising: the cuica);
    hold ms at full, then decay;
    t2: the second partial's ratio (0 = none) and level; click: the attack burst 0..127;
    src: the noise, its level, hold and decay; filt: (mode, Hz, resonance 0..1[, "all"]) on the
    noise (or everything); fenv: octaves the cutoff starts above it, falling with the pitch;
    hpf: Hz of the noise high-pass; chip: Hz of the CHIP noise clock; drive 0..127; level dB"""
    return dict(wave=wave, hz=hz, bend=bend, bt=bt, hold=hold, decay=decay, tlev=tlev, t2=t2,
                t2lev=t2lev, click=click, src=src, nlev=nlev, nhold=nhold, ndec=ndec, filt=filt,
                fenv=fenv, hpf=hpf, chip=chip, drive=drive, level=level)


def enc(s, trim=0.0):
    p, f = note16(s["hz"])
    flt, fcut = 0, 127
    if s["filt"]:
        mode, hz, res = s["filt"][:3]
        flt = FMODE[mode] | (4 if "all" in s["filt"][3:] else 0) | (int(round(res * 31)) << 3)
        fcut = cut(hz)
    lev = int(round(128 + 4 * (s["level"] + trim)))
    v = [WAVE[s["wave"]], SRC[s["src"]], p, f, int(s["bend"]), dec(s["bt"]),
         min(255, int(round(s["hold"] / 2))), dec(s["decay"]), int(s["tlev"]) if s["wave"] else 0,
         int(round(s["t2"] * 32)) if s["t2"] else 0, int(s["t2lev"]), int(s["click"]),
         int(s["nlev"]) if s["src"] else 0, min(255, int(round(s["nhold"] / 2))), dec(s["ndec"]),
         flt, fcut, int(round(s["fenv"] * STEPS_PER_OCT)),
         0 if s["hpf"] is None else cut(s["hpf"]), note(s["chip"]) if s["chip"] else 0,
         int(s["drive"]), max(0, min(255, lev))]
    return v


def kit(base, **mods):
    k = copy.deepcopy(base)
    for lane, ch in mods.items():
        if isinstance(ch, dict) and "wave" in ch:
            k[lane] = ch
        else:
            k[lane].update(ch)
    return k


# ---- base kits ---------------------------------------------------------------------------
K808 = dict(
    KICK=S("sine", 50, 12, 32, 8, 820, 124, click=26, drive=8),
    KICK2=S("sine", 42, 7, 60, 70, 1700, 124, click=14, drive=34),                  # the long boom
    SNARE=S("sine", 185, 3, 14, 0, 120, 96, 1.78, 92, 22, "white", 100, 0, 170, ("hp", 1700, .12)),
    SNARE2=S("tri", 250, 4, 10, 0, 70, 84, 1.5, 60, 30, "white", 96, 0, 120, ("bp", 5200, .3)),
    CLAP=S(None, src="clap", nlev=122, ndec=230, filt=("bp", 1150, .38), hpf=600),
    CHH=S(None, 205, src="metal", nlev=118, ndec=42, filt=("bp", 9200, .42), hpf=6500, click=10),
    OHH=S(None, 205, src="metal", nlev=114, nhold=20, ndec=380, filt=("bp", 9000, .4), hpf=6200),
    TOMLO=S("sine", 98, 6, 60, 10, 420, 118, 1.5, 40, 16, "white", 18, 0, 30, ("lp", 2000, .1)),
    TOMHI=S("sine", 147, 6, 60, 10, 360, 116, 1.5, 40, 16, "white", 18, 0, 30, ("lp", 2600, .1)),
    CRASH=S(None, 205, src="cym", nlev=108, nhold=10, ndec=1800, filt=("hp", 4600, .22)),
    RIDE=S(None, 262, src="metal", nlev=104, ndec=1300, filt=("bp", 5200, .6), hpf=3000, click=12),
    SHAKER=S(None, src="white", nlev=96, nhold=12, ndec=55, filt=("bp", 7200, .3)),
    CONGA=S("sine", 310, 3, 25, 4, 230, 116, 1.5, 30, 24),
    RIM=S("tri", 1700, 0, 5, 0, 22, 92, 1.47, 70, 40, "white", 40, 0, 6, ("bp", 2600, .4, "all")),
    COWBELL=S("bell", 540, 0, 5, 6, 290, 108, filt=("bp", 2600, .5, "all")),
    CLAVE=S("sine", 2500, 0, 5, 0, 48, 108, click=12),
)
K909 = kit(K808,
    KICK=S("sine", 52, 30, 24, 14, 340, 124, click=64, drive=36, src="white", nlev=40, ndec=6,
           filt=("lp", 5000, .1)),
    KICK2=S("sine", 57, 36, 18, 8, 220, 124, click=84, drive=72),
    SNARE=S("tri", 190, 7, 15, 0, 110, 92, 1.6, 70, 30, "white", 116, 0, 220, ("hp", 1000, .1),
            drive=22),
    SNARE2=S("tri", 230, 6, 10, 0, 70, 86, 1.6, 60, 40, "white", 110, 0, 140, ("bp", 6200, .3)),
    CLAP=dict(nlev=124, ndec=290, filt=("bp", 1300, .42), hpf=700),
    CHH=S(None, 230, src="cym", nlev=114, ndec=55, filt=("hp", 8200, .25), hpf=7000, click=12),
    OHH=S(None, 230, src="cym", nlev=110, nhold=20, ndec=460, filt=("hp", 7800, .25), hpf=6800),
    TOMLO=S("sine", 110, 10, 40, 10, 320, 118, 1.5, 36, 22, "white", 26, 0, 30, ("lp", 3000, .1)),
    TOMHI=S("sine", 165, 10, 40, 10, 280, 116, 1.5, 36, 22, "white", 26, 0, 30, ("lp", 3600, .1)),
    CRASH=S(None, 250, src="cym", nlev=110, nhold=10, ndec=1900, filt=("hp", 5000, .2)),
    RIDE=S(None, 300, src="cym", nlev=108, ndec=1500, filt=("bp", 6200, .45), hpf=4000, click=14),
    RIM=S("tri", 1900, 2, 4, 0, 18, 96, 1.47, 60, 48, "white", 60, 0, 6, ("bp", 3000, .4, "all")),
)
K606 = kit(K808,
    KICK=S("sine", 60, 18, 26, 6, 200, 124, click=34, drive=10),
    KICK2=S("sine", 52, 14, 30, 10, 320, 124, click=24, drive=20),
    SNARE=S("tri", 220, 3, 10, 0, 70, 80, 1.7, 50, 24, "white", 104, 0, 120, ("hp", 2500, .15)),
    CHH=S(None, 260, src="metal", nlev=116, ndec=30, filt=("bp", 10000, .45), hpf=8500, click=8),
    OHH=S(None, 260, src="metal", nlev=110, nhold=10, ndec=210, filt=("bp", 9800, .45), hpf=8000),
    TOMLO=S("sine", 150, 4, 30, 6, 190, 114, click=12),
    TOMHI=S("sine", 220, 4, 30, 6, 170, 112, click=12),
    CRASH=S(None, 300, src="metal", nlev=104, ndec=900, filt=("hp", 6000, .3)),
)
KCR78 = kit(K808,
    KICK=S("sine", 65, 8, 20, 4, 170, 120, click=10, filt=("lp", 1800, .2, "all")),
    KICK2=S("sine", 58, 6, 20, 4, 240, 120, click=8, filt=("lp", 1400, .2, "all")),
    SNARE=S("sine", 240, 2, 10, 0, 60, 74, 1.6, 50, 10, "white", 76, 0, 95, ("bp", 3200, .3)),
    SNARE2=S("sine", 300, 2, 8, 0, 40, 70, 1.5, 40, 12, "white", 70, 0, 60, ("bp", 4200, .3)),
    CLAP=S(None, src="white", nlev=92, nhold=8, ndec=140, filt=("bp", 6200, .35), hpf=4000),  # tambourine
    CHH=S(None, 280, src="metal", nlev=106, ndec=25, filt=("bp", 10500, .5), hpf=9000),
    OHH=S(None, 280, src="metal", nlev=100, nhold=6, ndec=160, filt=("bp", 10000, .5), hpf=8500),
    TOMLO=S("sine", 180, 2, 20, 4, 170, 112, click=8),
    TOMHI=S("sine", 260, 2, 20, 4, 150, 110, click=8),
    SHAKER=S(None, src="white", nlev=92, nhold=6, ndec=30, filt=("bp", 8000, .35)),
    CONGA=S("sine", 400, 2, 15, 4, 130, 112, click=14),
    RIM=S("sine", 1600, 0, 5, 0, 30, 100, 1.5, 50, 30),
    COWBELL=S("bell", 800, 0, 5, 4, 160, 104, filt=("bp", 3000, .5, "all")),
)
K707 = kit(K808,                                                # the 80s machines
    KICK=S("sine", 58, 20, 22, 10, 260, 124, click=56, drive=22, src="white", nlev=40, ndec=6,
           filt=("lp", 4500, .1)),
    KICK2=S("sine", 50, 16, 26, 14, 380, 124, click=40, drive=30),
    SNARE=S("tri", 200, 6, 15, 6, 130, 88, 1.62, 70, 36, "white", 112, 10, 270, ("hp", 900, .15),
            drive=30),
    SNARE2=S("tri", 220, 6, 12, 0, 90, 84, 1.62, 60, 40, "white", 112, 0, 200, ("bp", 4800, .3)),
    CLAP=dict(nlev=124, ndec=320, filt=("bp", 1400, .45)),
    CHH=S(None, 240, src="cym", nlev=106, ndec=40, filt=("hp", 8000, .3), hpf=7000, click=10),
    OHH=S(None, 240, src="cym", nlev=102, nhold=20, ndec=320, filt=("hp", 7500, .3), hpf=6800),
    TOMLO=S("sine", 90, 12, 80, 14, 520, 120, 1.5, 40, 24, "white", 22, 0, 40, ("lp", 2500, .1)),
    TOMHI=S("sine", 140, 12, 80, 14, 440, 118, 1.5, 40, 24, "white", 22, 0, 40, ("lp", 3000, .1)),
)
KCHIP = dict(
    KICK=S("square", 70, 30, 40, 4, 130, 104),
    KICK2=S("tri", 60, 36, 50, 10, 220, 116),
    SNARE=S("square", 220, 12, 20, 0, 40, 60, src="chip", nlev=106, nhold=6, ndec=130, chip=1700),
    SNARE2=S(None, src="chip", nlev=108, nhold=4, ndec=90, chip=3500),
    CLAP=S(None, src="chip", nlev=108, nhold=10, ndec=110, chip=2800),
    CHH=S(None, src="chip", nlev=96, ndec=30, chip=11000),
    OHH=S(None, src="chip", nlev=92, nhold=10, ndec=220, chip=10000),
    TOMLO=S("square", 110, 14, 80, 4, 160, 100),
    TOMHI=S("square", 165, 14, 80, 4, 140, 100),
    CRASH=S(None, src="chip", nlev=96, nhold=20, ndec=900, chip=4200),
    RIDE=S("square", 1500, 0, 5, 0, 300, 50, src="chip", nlev=60, ndec=200, chip=12500),
    SHAKER=S(None, src="chip", nlev=84, ndec=45, chip=13000),
    CONGA=S("tri", 330, 5, 30, 4, 120, 110),
    RIM=S("square", 1200, 0, 5, 0, 25, 90),
    COWBELL=S("square", 700, 0, 5, 4, 150, 90),
    CLAVE=S("square", 2000, 0, 5, 0, 35, 90),
)
KFM = dict(
    KICK=S("fm", 55, 40, 30, 8, 220, 120, click=30, drive=30),
    KICK2=S("fm", 48, 30, 40, 20, 420, 120, drive=50),
    SNARE=S("fm", 200, 18, 20, 0, 90, 90, src="white", nlev=90, ndec=140, filt=("bp", 4000, .3)),
    SNARE2=S("fm", 330, 12, 10, 0, 60, 90, src="white", nlev=80, ndec=90, filt=("hp", 3000, .3)),
    CLAP=S(None, src="clap", nlev=118, ndec=180, filt=("bp", 1500, .4), hpf=1000),
    CHH=S("fm", 4200, 0, 5, 0, 30, 70, src="white", nlev=70, ndec=30, filt=("hp", 8000, .2)),
    OHH=S("fm", 4200, 0, 5, 0, 220, 64, src="white", nlev=64, ndec=220, filt=("hp", 7000, .2)),
    TOMLO=S("fm", 120, 30, 120, 6, 260, 110),
    TOMHI=S("fm", 200, 30, 120, 6, 220, 108),
    CRASH=S("fm", 900, 0, 5, 0, 1200, 50, src="cym", nlev=90, ndec=1300, filt=("hp", 4000, .2)),
    RIDE=S("fm", 1300, 0, 5, 0, 900, 60, src="metal", nlev=50, ndec=700, filt=("bp", 6000, .5)),
    SHAKER=S(None, src="white", nlev=80, nhold=8, ndec=50, filt=("bp", 7000, .3)),
    CONGA=S("fm", 330, 12, 40, 4, 160, 108),
    RIM=S("fm", 1500, 4, 5, 0, 25, 96, click=30),
    COWBELL=S("fm", 600, 0, 5, 4, 200, 96),
    CLAVE=S("fm", 2300, 0, 5, 0, 40, 100),
)

KITS = [
    # -- the machines
    ("808", "HIP HOP", 0, K808),
    ("909", "HOUSE", 0, K909),
    ("606", "ACID", 0, K606),
    ("80S", "80S POP", 0, K707),
    ("VINTAGE", "RHYTHM BOX", 0, KCR78),
    # -- hip-hop
    ("TRAP", "TRAP", 0, kit(K808,
        KICK=S("sine", 52, 18, 26, 10, 520, 124, click=50, drive=30),
        KICK2=S("sine", 46, 12, 40, 80, 1900, 124, click=20, drive=48),            # the 808, distorted
        SNARE=S("tri", 210, 6, 10, 0, 90, 80, 1.7, 60, 40, "white", 116, 6, 150, ("hp", 2300, .2), drive=26),
        CLAP=dict(nlev=126, ndec=170, filt=("bp", 1500, .4), hpf=1100),
        CHH=dict(ndec=26, filt=("bp", 10500, .45), hpf=9000),
        OHH=dict(ndec=260))),
    ("DRILL", "UK DRILL", 0, kit(K808,
        KICK=S("sine", 50, 14, 30, 8, 380, 124, click=44, drive=26),
        KICK2=S("sine", 44, 12, 220, 40, 1900, 124, click=16, drive=44),            # the sliding 808
        SNARE=S("tri", 270, 8, 8, 0, 60, 84, 1.6, 60, 46, "white", 108, 4, 110, ("hp", 2600, .25), drive=30),
        SNARE2=S("tri", 330, 6, 6, 0, 40, 80, 1.5, 50, 50, "white", 100, 0, 80, ("bp", 5500, .4)),
        CHH=dict(ndec=28, filt=("bp", 9800, .5), hpf=8500),
        RIM=dict(hz=2000, decay=30, tlev=104))),
    ("BOOMBAP", "HIP HOP", 0x13, kit(K909,
        KICK=S("sine", 56, 14, 22, 12, 280, 124, click=40, drive=70, src="white", nlev=70, ndec=10,
               filt=("lp", 3000, .15)),
        KICK2=S("sine", 50, 10, 26, 16, 360, 124, click=30, drive=80, filt=("lp", 1800, .1, "all")),
        SNARE=S("tri", 175, 5, 15, 8, 140, 96, 1.7, 70, 34, "white", 112, 10, 200, ("bp", 3200, .25),
                drive=50),
        SNARE2=S("tri", 200, 5, 12, 0, 90, 90, 1.7, 60, 30, "white", 104, 0, 140, ("bp", 2600, .3), drive=40),
        CHH=dict(ndec=40, filt=("bp", 7000, .35), hpf=6000),
        OHH=dict(ndec=260, filt=("bp", 6800, .35), hpf=5500))),
    ("LO-FI", "LO-FI", 0x34, kit(K808,
        KICK=S("sine", 54, 10, 30, 10, 420, 120, click=18, drive=24, filt=("lp", 1300, .15, "all")),
        KICK2=S("sine", 48, 8, 30, 14, 560, 120, click=10, drive=30, filt=("lp", 900, .15, "all")),
        SNARE=dict(filt=("bp", 2400, .25), ndec=160, click=10),
        SNARE2=dict(filt=("bp", 1800, .3), ndec=120),
        CLAP=dict(filt=("bp", 1000, .3)),
        CHH=dict(filt=("bp", 5200, .3), hpf=3800, nlev=96), OHH=dict(filt=("bp", 5000, .3), hpf=3600, nlev=92),
        CRASH=dict(filt=("bp", 4000, .2), nlev=88), RIDE=dict(filt=("bp", 4200, .5), hpf=2800, nlev=80))),
    ("PHONK", "PHONK", 0x02, kit(K808,
        KICK=S("sine", 52, 20, 24, 10, 480, 124, click=60, drive=90),
        KICK2=S("sine", 45, 12, 50, 60, 1600, 124, click=30, drive=110),           # blown-out 808
        SNARE=S("tri", 230, 8, 10, 0, 80, 84, 1.6, 60, 44, "white", 116, 6, 140, ("hp", 2000, .25), drive=60),
        CLAP=dict(nlev=126, ndec=150, hpf=1200),
        CHH=dict(ndec=30), OHH=dict(ndec=220),
        COWBELL=S("bell", 560, 0, 5, 30, 520, 116, filt=("bp", 2400, .55, "all"), drive=40))),   # the melodic cowbell
    # -- dance
    ("HOUSE", "HOUSE", 0, kit(K909,
        KICK=dict(decay=380, drive=30, hold=18),
        OHH=dict(ndec=320, nlev=112), CLAP=dict(nlev=126, ndec=340),
        SHAKER=dict(ndec=70, nlev=98))),
    ("D.HOUSE", "DEEP HOUSE", 0, kit(K909,
        KICK=S("sine", 50, 22, 26, 20, 460, 124, click=36, drive=18, filt=("lp", 3000, .1, "all")),
        SNARE=dict(ndec=180, filt=("bp", 2200, .3), click=16, tlev=80),
        CLAP=dict(nlev=118, ndec=420, filt=("bp", 1100, .4)),
        CHH=dict(ndec=48, filt=("bp", 7500, .45), hpf=6200, nlev=100),
        OHH=dict(ndec=300, filt=("bp", 7200, .45), hpf=6000, nlev=100),
        SHAKER=dict(ndec=80, nlev=100, filt=("bp", 6000, .3)),
        RIM=dict(filt=("bp", 2200, .5, "all")))),
    ("TECHNO", "TECHNO", 0, kit(K909,
        KICK=S("sine", 50, 28, 22, 18, 420, 124, click=70, drive=96, src="white", nlev=50, ndec=8,
               filt=("lp", 4000, .2)),
        KICK2=S("sine", 46, 18, 30, 30, 900, 124, click=40, drive=110, filt=("lp", 900, .3, "all")),   # rumble
        CHH=dict(ndec=34, filt=("hp", 9500, .3), hpf=9000), OHH=dict(ndec=280, filt=("hp", 9000, .3)),
        RIDE=dict(nlev=100, ndec=900), RIM=dict(drive=40),
        CLAP=dict(ndec=210, filt=("bp", 1900, .45)))),
    ("MINIMAL", "MINIMAL", 0, kit(K808,
        KICK=S("sine", 58, 18, 12, 6, 160, 124, click=44, drive=12),
        KICK2=S("sine", 52, 10, 14, 8, 240, 124, click=30),
        SNARE=S("tri", 1100, 0, 5, 0, 18, 90, 1.5, 50, 40, "white", 60, 0, 25, ("hp", 3000, .3)),
        CLAP=dict(ndec=90), CHH=dict(ndec=18, filt=("hp", 10000, .3), hpf=9500), OHH=dict(ndec=120),
        CONGA=dict(decay=90, hz=420), RIM=dict(decay=12))),
    ("ELECTRO", "ELECTRO", 0, kit(K808,
        KICK=S("sine", 52, 24, 70, 10, 520, 124, click=40, drive=24),
        SNARE=dict(ndec=120, filt=("hp", 2000, .2), click=36),
        TOMLO=S("fm", 130, 30, 120, 8, 240, 112), TOMHI=S("fm", 220, 30, 120, 8, 200, 110),
        CHH=K606["CHH"], OHH=K606["OHH"])),
    ("DISCO", "DISCO", 0, kit(K909,
        KICK=dict(decay=260, drive=20),
        OHH=dict(ndec=520, nlev=114),
        TOMLO=S("sine", 120, 24, 300, 10, 600, 118, 1.5, 30), TOMHI=S("sine", 180, 24, 300, 10, 520, 116, 1.5, 30))),
    ("GARAGE", "UK GARAGE", 0, kit(K909,
        KICK=S("sine", 54, 26, 20, 10, 260, 124, click=60, drive=40),
        SNARE=S("tri", 240, 8, 10, 0, 80, 88, 1.6, 60, 50, "white", 112, 4, 120, ("hp", 2200, .25), drive=24),
        SNARE2=S("tri", 280, 6, 8, 0, 50, 84, 1.5, 50, 50, "white", 100, 0, 80, ("bp", 6000, .4)),
        CHH=dict(ndec=36, filt=("hp", 9500, .3)), SHAKER=dict(ndec=60, nlev=100),
        RIM=dict(hz=2100, decay=24))),
    ("JUNGLE", "DRUM & BASS", 0, kit(K909,
        KICK=S("sine", 58, 16, 18, 6, 200, 124, click=56, drive=50),
        SNARE=S("tri", 260, 9, 10, 4, 100, 94, 1.6, 70, 50, "white", 114, 6, 170, ("hp", 1500, .25), drive=40),
        SNARE2=S("tri", 300, 7, 8, 0, 60, 90, 1.6, 60, 50, "white", 106, 0, 110, ("bp", 5000, .35), drive=30),
        CHH=dict(ndec=30), RIDE=dict(nlev=100))),
    ("DUBSTEP", "BASS MUSIC", 0, kit(K909,
        KICK=S("sine", 48, 26, 24, 16, 420, 124, click=70, drive=64),
        SNARE=S("tri", 170, 8, 20, 10, 170, 98, 1.7, 70, 50, "white", 122, 30, 420, ("hp", 600, .2), drive=64),
        CLAP=dict(ndec=380), OHH=dict(ndec=300))),
    # -- the world
    ("DEMBOW", "REGGAETON", 0, kit(K808,
        KICK=dict(decay=520, drive=20, click=40),
        SNARE=S("tri", 230, 5, 10, 0, 80, 84, 1.7, 60, 36, "white", 100, 4, 130, ("hp", 1800, .2), drive=20),
        CLAP=dict(ndec=160), RIM=dict(tlev=104), SHAKER=dict(ndec=70, nlev=98))),
    ("AMAPIANO", "AMAPIANO", 0, kit(K808,
        KICK=S("sine", 54, 14, 20, 8, 300, 124, click=40, drive=16),
        KICK2=S("sine", 55, 24, 120, 20, 700, 124, 2.0, 50, 30, drive=56,             # the log drum
                filt=("lp", 1400, .5, "all"), fenv=1.5),
        SHAKER=S(None, src="white", nlev=104, nhold=16, ndec=70, filt=("bp", 6500, .35)),
        CLAP=dict(ndec=260), CONGA=dict(decay=260),
        COWBELL=dict(hz=900, decay=160))),
    ("AFRO", "AFROBEAT", 0, kit(K808,
        KICK=S("sine", 60, 10, 30, 6, 260, 120, click=20, filt=("lp", 2000, .1, "all")),
        SNARE=S("tri", 330, 3, 10, 0, 60, 92, 1.5, 50, 30, "white", 70, 0, 60, ("bp", 5000, .3)),
        CONGA=dict(decay=260, bend=2), TOMLO=S("sine", 160, 2, 20, 6, 260, 114, click=20),
        TOMHI=S("sine", 230, 2, 20, 6, 220, 112, click=20), SHAKER=dict(ndec=80, nlev=100),
        COWBELL=dict(hz=900, decay=180))),
    ("LATIN", "LATIN", 0, kit(KCR78,
        KICK=S("sine", 62, 6, 20, 6, 230, 116, click=16, filt=("lp", 1800, .1, "all")),
        TOMLO=S("sine", 200, 3, 15, 4, 200, 114, 1.6, 40, 40, "white", 26, 0, 15, ("bp", 4000, .3)),   # timbales
        TOMHI=S("sine", 300, 3, 15, 4, 180, 114, 1.6, 40, 40, "white", 26, 0, 15, ("bp", 4500, .3)),
        CONGA=dict(hz=330, decay=240, click=30), COWBELL=dict(hz=650, decay=240),
        CLAVE=dict(hz=2400, decay=55))),
    ("TRIBAL", "TRIBAL", 0, kit(K808,
        KICK=S("sine", 52, 14, 60, 10, 600, 124, click=30, src="white", nlev=30, ndec=10, filt=("lp", 1500, .2)),
        SNARE=S("sine", 160, 6, 30, 6, 260, 112, 1.6, 50, 30, "white", 40, 0, 60, ("lp", 3000, .2)),
        TOMLO=S("sine", 75, 8, 90, 10, 600, 120, 1.5, 40, 30, "white", 26, 0, 30, ("lp", 1500, .2)),
        TOMHI=S("sine", 115, 8, 90, 10, 520, 118, 1.5, 40, 30, "white", 26, 0, 30, ("lp", 2000, .2)),
        CHH=S(None, src="white", nlev=90, ndec=40, filt=("bp", 6000, .3), hpf=5000),
        OHH=S(None, src="white", nlev=92, nhold=10, ndec=160, filt=("bp", 5000, .3), hpf=4000),
        CONGA=dict(decay=320))),
    # -- synths and games
    ("SYNTHWV", "SYNTHWAVE", 0, kit(K707,
        SNARE=dict(ndec=360, drive=50, nlev=120, hold=10),
        TOMLO=S("sine", 85, 18, 160, 14, 600, 120, 1.5, 40, 24, "white", 24, 0, 50, ("lp", 2500, .1)),
        TOMHI=S("sine", 130, 18, 160, 14, 520, 118, 1.5, 40, 24, "white", 24, 0, 50, ("lp", 3000, .1)))),
    ("CHIP", "CHIPTUNE", 0x04, KCHIP),
    ("ARCADE", "VIDEO GAME", 0x02, KFM),
    ("GLITCH", "GLITCH", 0x25, kit(KFM,
        KICK=dict(decay=120, bt=12), SNARE=S(None, src="chip", nlev=112, ndec=70, chip=1300),
        CHH=S(None, src="chip", nlev=100, ndec=15, chip=13000), OHH=S(None, src="chip", nlev=96, ndec=90, chip=11500),
        CLAP=dict(ndec=80), TOMLO=dict(bt=40, decay=120), TOMHI=dict(bt=40, decay=100))),
    ("INDUSTR", "INDUSTRIAL", 0x02, kit(K909,
        KICK=dict(drive=127, decay=380, click=90), SNARE=dict(drive=110, ndec=260),
        CLAP=dict(nlev=127, ndec=280), CHH=dict(src="metal", ndec=60), OHH=dict(src="metal", ndec=500),
        TOMLO=S("fm", 90, 24, 200, 10, 400, 118, drive=100), TOMHI=S("fm", 140, 24, 200, 10, 340, 116, drive=100),
        CRASH=dict(src="metal", ndec=2200, nlev=118))),
    ("HYPER", "HYPERPOP", 0, kit(K909,
        KICK=S("sine", 54, 40, 20, 10, 380, 124, click=90, drive=110),
        SNARE=S("tri", 300, 10, 10, 0, 90, 100, 1.6, 60, 60, "white", 122, 6, 180, ("hp", 2000, .3), drive=80),
        CLAP=dict(nlev=127, ndec=240, hpf=1300),
        CHH=dict(filt=("hp", 10000, .3), ndec=30), OHH=dict(filt=("hp", 9500, .3)))),
    ("AMBIENT", "AMBIENT", 0, kit(K808,
        KICK=S("sine", 48, 8, 40, 10, 900, 104, filt=("lp", 700, .1, "all")),
        SNARE=dict(filt=("lp", 3500, .2), ndec=420, nlev=70, tlev=60, click=0),
        CLAP=dict(filt=("bp", 900, .3), ndec=500, nlev=90),
        CHH=dict(nlev=72, ndec=70, filt=("bp", 7000, .3), hpf=6000), OHH=dict(nlev=72, ndec=900),
        CRASH=dict(nlev=84, ndec=3500), RIDE=dict(nlev=64, ndec=2500, filt=("bp", 6000, .5)))),
    ("JAZZ", "JAZZ", 0, kit(K808,
        KICK=S("sine", 62, 8, 20, 4, 230, 100, click=24, src="white", nlev=30, ndec=8, filt=("lp", 1200, .1)),
        KICK2=S("sine", 70, 6, 16, 4, 160, 96, click=30, src="white", nlev=30, ndec=6, filt=("lp", 1400, .1)),
        SNARE=S("tri", 210, 2, 10, 0, 60, 40, src="white", nlev=92, nhold=30, ndec=320,     # brushes
                filt=("bp", 3500, .2)),
        SNARE2=S("tri", 220, 3, 10, 0, 90, 80, 1.6, 50, 40, "white", 100, 0, 150, ("bp", 2800, .25)),
        CHH=S(None, 300, src="cym", nlev=82, ndec=60, filt=("bp", 8000, .3), hpf=5000),
        OHH=S(None, 300, src="cym", nlev=82, nhold=10, ndec=500, filt=("bp", 7500, .3), hpf=4500),
        RIDE=S(None, 320, src="cym", nlev=90, ndec=2400, filt=("bp", 6500, .35), hpf=3500, click=16),
        TOMLO=S("sine", 110, 3, 30, 6, 400, 106, 1.5, 40, 20, "white", 16, 0, 40, ("lp", 2000, .1)),
        TOMHI=S("sine", 160, 3, 30, 6, 340, 104, 1.5, 40, 20, "white", 16, 0, 40, ("lp", 2500, .1)))),
    # -- Jangada's own (appended: G_KIT is saved by index; KIT_NAV below shows them first)
    ("RUST", "INDUSTRIAL", 0x13, dict(                          # dry and broken: NIN, Ghosts
        KICK=S("sine", 48, 30, 18, 10, 300, 124, click=100, src="white", nlev=60, ndec=8,
               filt=("lp", 6000, .2), drive=120),
        KICK2=S("sine", 42, 24, 30, 30, 700, 124, click=60, filt=("lp", 1200, .4, "all"), drive=127),
        SNARE=S("tri", 180, 8, 12, 0, 90, 90, 1.6, 60, 50, "white", 120, 140, 25, ("bp", 1800, .2),
                drive=80),                                      # gated: the noise held, then cut
        SNARE2=S("fm", 240, 12, 10, 0, 80, 100, src="metal", nlev=100, nhold=60, ndec=20,
                 filt=("hp", 1500, .3), drive=100),             # a clang
        CLAP=S(None, src="clap", nlev=127, nhold=80, ndec=30, filt=("bp", 1600, .5), hpf=900, drive=60),
        CHH=S(None, 300, src="metal", nlev=120, ndec=35, filt=("hp", 7000, .3), hpf=6000, drive=90),
        OHH=S(None, 300, src="metal", nlev=114, nhold=40, ndec=260, filt=("hp", 6500, .3), hpf=5500, drive=90),
        TOMLO=S("fm", 70, 30, 150, 10, 380, 120, drive=110),
        TOMHI=S("fm", 105, 30, 150, 10, 320, 118, drive=110),
        CRASH=S(None, 180, src="cym", nlev=120, nhold=30, ndec=1600, filt=("bp", 3500, .5), drive=80),
        RIDE=S("bell", 820, 0, 5, 0, 600, 110, src="metal", nlev=50, ndec=300,
               filt=("bp", 3000, .6, "all"), drive=40),         # a pipe
        SHAKER=S(None, src="white", nlev=100, nhold=10, ndec=40, filt=("hp", 6000, .2), drive=60),
        CONGA=S("square", 160, 12, 30, 4, 140, 100, filt=("lp", 2000, .5, "all"), fenv=2, drive=70),
        RIM=S("tri", 1400, 0, 5, 0, 20, 100, 2.3, 80, 70, "white", 60, 0, 8, ("bp", 2400, .5, "all"), drive=90),
        COWBELL=S("bell", 330, 0, 5, 10, 240, 116, filt=("bp", 1800, .6, "all"), drive=100),
        CLAVE=S("fm", 1800, 2, 5, 0, 60, 110, click=60, drive=60))),
    ("FORGE", "METAL", 0, dict(                                 # anvils, chains, sheets: inharmonic, ringing
        KICK=S("sine", 55, 18, 20, 8, 260, 124, 2.76, 70, 70, drive=50),       # the hammer and the plate
        KICK2=S("fm", 45, 12, 40, 30, 1200, 120, filt=("lp", 1500, .3, "all"), drive=40),
        SNARE=S("bell", 620, 0, 5, 0, 700, 120, click=60, src="metal", nlev=80, ndec=180,
                filt=("bp", 2600, .7, "all")),                  # the anvil
        SNARE2=S(None, 410, src="metal", nlev=120, ndec=90, filt=("bp", 5000, .5), hpf=2500),
        CLAP=S(None, 340, src="chain", nlev=124, ndec=200, filt=("bp", 4200, .5), hpf=2000),   # chains
        CHH=S(None, 520, src="metal", nlev=118, ndec=45, filt=("bp", 7800, .6), hpf=5000),
        OHH=S(None, 520, src="metal", nlev=110, nhold=10, ndec=600, filt=("bp", 7000, .6), hpf=4500),
        TOMLO=S("bell", 180, 1, 30, 0, 900, 118, filt=("bp", 900, .7, "all")),     # pipes
        TOMHI=S("bell", 270, 1, 30, 0, 800, 116, filt=("bp", 1300, .7, "all")),
        CRASH=S("fm", 700, 0, 5, 0, 1800, 70, src="cym", nlev=110, nhold=20, ndec=2200, filt=("hp", 3000, .3)),
        RIDE=S("fm", 1050, 0, 5, 0, 2000, 110, 2.76, 60, 20, filt=("bp", 3000, .5, "all")),    # it rings
        SHAKER=S(None, 700, src="metal", nlev=100, nhold=8, ndec=50, filt=("hp", 8000, .3)),
        CONGA=S("sine", 380, 0, 5, 0, 600, 116, 2.76, 90, 40),                   # a steel pan
        RIM=S("fm", 2600, 0, 5, 0, 40, 110, click=80),
        COWBELL=S("bell", 880, 0, 5, 4, 1200, 118, filt=("bp", 3500, .75, "all")),
        CLAVE=S("sine", 3100, 0, 5, 0, 300, 110, 2.41, 80, 30))),
    ("PISTON", "MACHINE", 0, dict(                              # engines: clicks, air, steam
        KICK=S("sine", 62, 20, 8, 2, 90, 124, click=90, drive=40),             # short and dry
        KICK2=S("square", 50, 24, 15, 4, 120, 110, filt=("lp", 900, .5, "all"), fenv=2.5, drive=50),
        SNARE=S("tri", 210, 4, 10, 0, 40, 60, 0, 0, 60, "white", 120, 30, 90, ("bp", 3000, .3)),
        SNARE2=S(None, src="white", nlev=110, nhold=60, ndec=180, filt=("hp", 4000, .3), hpf=2000),   # a valve
        CLAP=S(None, src="clap", nlev=120, ndec=40, filt=("bp", 2500, .6), hpf=1200),   # a ratchet
        CHH=S(None, src="white", nlev=110, ndec=12, filt=("hp", 9000, .2), click=80),
        OHH=S(None, src="white", nlev=104, nhold=80, ndec=300, filt=("bp", 6000, .4), hpf=3000),  # steam
        TOMLO=S("tri", 85, 18, 80, 6, 200, 116, filt=("lp", 1500, .5, "all"), fenv=2, drive=30),
        TOMHI=S("tri", 130, 18, 80, 6, 170, 114, filt=("lp", 2000, .5, "all"), fenv=2, drive=30),
        CRASH=S(None, src="white", nlev=110, nhold=200, ndec=900, filt=("bp", 4500, .3), hpf=1500),
        RIDE=S("square", 2400, 0, 5, 0, 25, 80, src="metal", nlev=80, ndec=30, filt=("bp", 5000, .5, "all")),
        SHAKER=S(None, src="chip", nlev=96, ndec=30, chip=9000),
        CONGA=S("sine", 260, 12, 12, 2, 70, 116, click=50),
        RIM=S("square", 1100, 0, 5, 0, 12, 100, click=60),
        COWBELL=S("bell", 460, 0, 5, 0, 70, 112, filt=("bp", 2200, .5, "all")),
        CLAVE=S("sine", 4000, 0, 5, 0, 8, 60, click=127))),                    # a relay
    ("HURT", "FRAGILE", 0, dict(                                # low, muffled, breathing: the quiet NIN
        KICK=S("sine", 46, 6, 40, 10, 500, 116, click=6, filt=("lp", 400, .1, "all")),
        KICK2=S("sine", 40, 4, 40, 20, 900, 110, filt=("lp", 300, .1, "all")),  # a heartbeat
        SNARE=S("tri", 190, 2, 10, 0, 100, 40, src="white", nlev=96, nhold=40, ndec=380,
                filt=("lp", 2500, .3)),
        SNARE2=S("sine", 220, 2, 10, 0, 140, 90, 1.6, 40, 0, "white", 60, 0, 120, ("lp", 1800, .2)),
        CLAP=S(None, src="white", nlev=100, nhold=60, ndec=400, filt=("bp", 1200, .3)),   # a breath
        CHH=S(None, src="white", nlev=80, ndec=40, filt=("bp", 5000, .3), hpf=3000),
        OHH=S(None, src="white", nlev=80, nhold=30, ndec=500, filt=("bp", 4000, .3), hpf=2500),
        TOMLO=S("sine", 70, 3, 40, 10, 700, 114, 1.5, 30, 0, "white", 20, 0, 60, ("lp", 900, .1, "all")),
        TOMHI=S("sine", 100, 3, 40, 10, 600, 112, 1.5, 30, 0, "white", 20, 0, 60, ("lp", 1200, .1, "all")),
        CRASH=S(None, 205, src="cym", nlev=80, nhold=40, ndec=3000, filt=("lp", 3500, .2)),
        RIDE=S(None, 262, src="metal", nlev=80, ndec=1800, filt=("bp", 3800, .5), hpf=2500),
        SHAKER=S(None, src="white", nlev=84, nhold=20, ndec=80, filt=("bp", 4500, .3)),
        CONGA=S("sine", 196, 1, 20, 4, 400, 110, 2.0, 40, filt=("lp", 1200, .2, "all")),
        RIM=S("sine", 900, 0, 5, 0, 40, 90, 1.5, 40, 6),
        COWBELL=S("sine", 1320, 0, 5, 0, 900, 100, 2.76, 50),                  # a music box
        CLAVE=S("sine", 1800, 0, 5, 0, 30, 90))),
    ("MANGUE", "MANGUEBEAT", 0, dict(                           # maracatu, baiao, coco, with the weight
        KICK=S("sine", 62, 10, 35, 12, 450, 124, 1.5, 50, 40, "white", 40, 0, 25, ("lp", 1800, .2),
               drive=60),                                       # alfaia: the body and the skin
        KICK2=S("sine", 55, 8, 25, 6, 260, 124, 1.6, 40, 50, "white", 50, 0, 15, ("lp", 1500, .2),
                drive=70),                                      # zabumba
        SNARE=S("tri", 260, 4, 10, 0, 60, 80, 1.6, 50, 50, "white", 118, 6, 140, ("bp", 4200, .3),
                drive=40),                                      # caixa de maracatu: the snares
        SNARE2=S("tri", 900, 2, 5, 0, 30, 100, 1.5, 60, 70, "white", 70, 0, 20, ("bp", 2800, .5, "all"),
                 drive=30),                                     # bacalhau: the zabumba's stick
        CLAP=S(None, src="clap", nlev=124, ndec=160, filt=("bp", 1300, .4), hpf=700),   # palmas
        CHH=S("sine", 1900, 0, 5, 0, 70, 96, 2.76, 70, src="metal", nlev=40, ndec=60,
              filt=("hp", 5000, .3), hpf=4000),                 # triangulo, closed (it chokes the open one)
        OHH=S("sine", 1900, 0, 5, 0, 900, 96, 2.76, 70, src="metal", nlev=40, ndec=700,
              filt=("hp", 5000, .3), hpf=4000),                 # triangulo, open
        TOMLO=S("sine", 85, 8, 35, 10, 380, 120, 1.5, 50, 40, "white", 35, 0, 20, ("lp", 2200, .2),
                drive=50),                                      # alfaia meiao
        TOMHI=S("tri", 380, -9, 120, 40, 220, 116, 2.0, 40, 0, filt=("bp", 800, .6, "all"), fenv=-1.0),
        CRASH=S(None, 190, src="cym", nlev=112, nhold=10, ndec=1500, filt=("hp", 3500, .3), drive=60),
        RIDE=S("bell", 290, 0, 5, 10, 700, 118, filt=("bp", 1100, .55, "all"), drive=50),   # gongue
        SHAKER=S(None, src="white", nlev=104, nhold=14, ndec=60, filt=("bp", 6000, .35)),   # ganza
        CONGA=S("tri", 560, -7, 110, 30, 160, 116, 2.0, 40, 0, filt=("bp", 1000, .6, "all"),
                fenv=-1.0),                                     # cuica: the glide up
        RIM=S("tri", 1500, 0, 5, 0, 18, 100, 1.47, 70, 60, "white", 50, 0, 6, ("bp", 2600, .4, "all")),
        COWBELL=S("sine", 700, 0, 5, 4, 380, 112, 2.76, 70, 30),               # agogo, low
        CLAVE=S("sine", 935, 0, 5, 4, 340, 110, 2.76, 70, 30))),               # agogo, high
]


# ---- Jangada: the kit browser's order (GLO > KIT, the PRESETS knob on the drum track) -------
# G_KIT keeps the index into KITS (+ 1, 0 = GM): projects saved before keep their kit. The new
# kits sit at the end of KITS and are shown first, right after GM.
KIT_FIRST = ["RUST", "FORGE", "PISTON", "HURT", "MANGUE"]

# ---- Jangada: factory beats (GLO > KIT, KNOB 4 BEAT; a kit loads its own into an empty drum track)
# 16 steps of GM notes (DS_MAP takes them to the lanes; up to 4 a step). A row per note: "." rest,
# anything else a hit. "v": the step's velocity, 1..9 (x 14) or A (accent: 127); "r": ratchet 2..4.
# Notes of MANGUE: 36 alfaia, 43 alfaia meiao, 35 zabumba, 38 caixa, 40 bacalhau, 37 tamanco (rim),
# 42 / 46 triangulo closed / open, 70 ganza, 51 / 53 gongue low / high, 56 / 75 agogo, 63 / 48 cuica,
# 39 palmas.
# Every beat has its virada ("fill": FILL, GLO + 9 held or key 10 for the next bar). "c": a step's chance,
# 1..3 = 75 / 50 / 25 % (SF_CHANCE). GM notes on the other kits: 35 / 36 kick, 37 rim, 38 / 40 snare, 39 clap,
# 42 / 44 / 46 hat closed / pedal / open, 41 43 45 low toms, 47 48 50 high toms, 49 crash, 51 ride, 53 its
# bell, 54 tambourine, 56 cowbell, 60 / 61 bongos, 62 / 63 / 64 congas (mute / open / low), 65 timbale,
# 67 agogo, 69 cabasa, 70 maracas, 75 clave, 76 woodblock, 78 cuica, 80 triangle.
BEATS = [
    # ---- the Jangada kits' own
    ("MARACATU", "MANGUE", {                    # baque virado: alfaias, caixa in 16ths, gongue, ganza
        36: "X..X..X...X.X...",
        43: "........X.....X.",
        51: "X.....X.....X...",
        53: "..X.....X.X...X.",
        38: "XXXXXXXXXXXXXXXX",
        70: "XXXXXXXXXXXXXXXX",
        "v": "A46945958494A486",
        "r": ".......2.......2",
        "fill": {"keep": "XXXXXXXXX.X.X.X."}}),         # the parada: the alfaias answer alone
    ("BAIAO", "MANGUE", {                       # zabumba (grave and bacalhau) and triangulo
        35: "X..X....X..X....",
        40: "..X...X...X...X.",
        42: "XX.XXX.XXX.XXX.X",
        46: "..X...X...X...X.",
        "v": "A4895484A4895484",
        "fill": {"keep": "XXXXXXXXX..X..XX"}}),
    ("COCO", "MANGUE", {                        # zabumba, palmas, tamancos, ganza
        35: "X.....X.X.....X.",
        39: "....X..X....X..X",
        37: "..XX......XX....",
        70: "XXXXXXXXXXXXXXXX",
        "v": "A4799498A4799498",
        "fill": {"keep": "XXXXXXXX.X.X.XXX"}}),
    ("GRIND", "RUST", {                         # the industrial march
        36: "X.....X.X..X....",
        38: "....X.......X...",
        42: "X.X.X.X.X.X.X.XX",
        40: "...............X",
        51: "..........X.....",
        "v": "A363A383938AA367",
        "r": "..............2.",
        "fill": {38: ".........X...X..", 43: ".......X........",
                 "v": ".......8.9...A..", "r": ".........3...4.."}}),
    ("ANVIL", "FORGE", {                        # hammer, anvil, chains
        36: "X.......X..X....",
        38: "....X.......X...",
        39: "......X.......X.",
        56: "..X.......X....X",
        51: "X...............",
        42: "...X...X...X...X",
        "v": "A585A585A585A585",
        "fill": {36: ".........X......", 43: ".....X.......X..", 38: ".X..............",
                 "v": ".6...8...A...A..", "r": ".............3.."}}),
    ("ENGINE", "PISTON", {                      # pistons, ticks, valves, a relay
        36: "X...X...X...X...",
        35: "..X.......X.....",
        42: ".X.X.X.X.X.X.X.X",
        40: "......X.......X.",
        75: "...X.......X....",
        38: "....X.......X...",
        39: "...............X",
        "v": "A4759484A4759486",
        "r": ".......2.......3",
        "fill": {"keep": "XXXXXXXXXXXXX..X"}}),         # the engine stalls, a relay restarts it
    ("FRAGILE", "HURT", {                       # a heartbeat, breaths, a music box
        36: "X.........X.....",
        38: "....X.......X...",
        42: "..X...X...X...X.",
        56: "X......X........",
        43: "............X...",
        "v": "7.3.5.34..6.5.3.",
        "fill": {36: ".........X......", 43: ".............X..", 41: "...............X",
                 "v": ".........6...5.4"}}),         # the heart skips
    # ---- Brasil (on the MANGUE kit)
    ("IJEXA", "MANGUE", {                       # afoxe: agogo, zabumba, tamanco, ganza
        75: "X.X.....X.X.....",
        56: "....X.X.....X.X.",
        35: "X......X..X.....",
        37: "...X......X..X..",
        70: "X.XXX.XXX.XXX.XX",
        "v": "A5795697A5795697",
        "fill": {43: ".X...X...X......", "v": ".6...7...8......"}}),
    ("SAMBA", "MANGUE", {                       # surdo on 2, tamborim, caixa, ganza
        35: "....X.......X...",
        36: "X.......X.......",
        37: "X..X..X.X.X..X..",
        38: "..XX.XX...XX.XX.",
        70: "XXXXXXXXXXXXXXXX",
        "v": "8567A5679567A576",
        "fill": {"keep": "XXXXXXXXXXXXX.XX"}}),
    ("XOTE", "MANGUE", {                        # zabumba, bacalhau, triangulo: the forro's slow one
        35: "X.......X..X....",
        40: "....X.......X...",
        42: "X.XXX.XXX.XXX.XX",
        46: ".X...X...X...X..",
        "v": "A457A457A457A457",
        "fill": {"keep": "XXXXXXXXXXXX...X"}}),
    ("FREVO", "MANGUE", {                       # caixa in 16ths, surdo, the fast march
        36: "X...X...X...X...",
        35: "..X.......X.....",
        38: "XXXXXXXXXXXXXXXX",
        39: "....X.......X...",
        "v": "A496A496A496A49A",
        "r": "...2...2...2...3",
        "fill": {"keep": "XXXXXXXXXXXXX..X"}}),
    ("FUNK", "MANGUE", {                        # tamborzao: the baile's alfaia and caixa
        36: "X..X..X...X..X..",
        38: "....X.X.....X...",
        39: "....X.......X...",
        42: "X.X.X.X.X.X.X.X.",
        "v": "A47A8A47A47AA47.",
        "fill": {36: ".X.......X......", 38: "...........X...X",
                 "v": ".7.......9.A...A", "r": "...........2...3"}}),
    # ---- dark, industrial
    ("CORRODE", "RUST", {                       # the march rusting: late kicks, a broken hat
        36: "X......X..X.....",
        40: "....X.......X...",
        42: "X.X...X.X.X...X.",
        51: "...X.......X....",
        "v": "A.5.A.6799A.A.6.",
        "c": "..1...1...2...1.",
        "fill": {40: ".........X...X.X", 43: ".....X..........",
                 "v": ".....8...7...9.A", "r": ".............3.4"}}),
    ("FOUNDRY", "FORGE", {                      # slow hammers, a chain dragged
        36: "X.......X.......",
        38: "....X.......X...",
        56: "..X...X...X...X.",
        39: ".......X......X.",
        "v": "A.8.A.8A9.8.A.AA",
        "r": ".......3........",
        "fill": {36: ".........X.X....", 43: ".X.X............",
                 "v": ".7.8.....9.A....", "r": "...........2...."}}),
    ("TURBINE", "PISTON", {                     # a turbine winding up in 16ths
        36: "X..X..X...X..X..",
        42: "XXXXXXXXXXXXXXXX",
        75: "..X.......X.....",
        38: "....X.......X...",
        "v": "A345A345A345A345",
        "c": ".2.2.2.2.2.2.2.2",
        "fill": {"keep": "XXXXXXXXXXXXXX.."}}),
    ("WOUND", "HURT", {                         # a heart that stumbles, breath, a bell far off
        36: "X..X......X.....",
        38: "........X.......",
        42: "..X...X.....X...",
        56: "...............X",
        "v": "8.5.3.4.7.6.4..5",
        "c": "......1.....2...",
        "fill": {43: ".....X.......X..", 41: ".............X..", 36: ".........X......",
                 "v": ".....5...6...7.."}}),
    ("DESCENT", "RUST", {                       # halftime, falling toms
        36: "X.........X.....",
        38: "........X.......",
        42: "X.X.X.X.X.X.X.X.",
        46: "......X.........",
        "v": "A.5.6.7.A.5.6.5.",
        "fill": {50: ".......X........", 47: ".........X......", 45: "...........X....",
                 43: ".............X..", 41: "...............X", "keep": "XXXXXXXXX.XX.X.X",
                 "v": ".......A.A.9.8.7"}}),
    # ---- one for each kit, in the browser's order
    ("HIPHOP", "808", {
        36: "X..X......X..X..",
        38: "....X.......X...",
        42: "X.X.X.X.X.X.X.X.",
        "v": "A.5AA.6.7.A5A.6.",
        "fill": {38: ".........X.X...X", "v": ".........6.7...A", "r": "...............2"}}),
    ("CLUB", "909", {                           # four to the floor
        36: "X...X...X...X...",
        39: "....X.......X...",
        42: "..X...X...X...X.",
        54: "......X.......X.",
        "v": "A5859585A5859587",
        "fill": {38: ".........X.X.X.X",
                 "v": ".........5.6.8.A", "r": ".............2.3"}}),
    ("ACID", "606", {
        36: "X...X...X...X...",
        38: "....X.......X..X",
        42: "XX.XXX.XXX.XXX..",
        46: "..X...X...X...X.",
        "v": "A575A575A575A57A",
        "c": ".1...1...1...1..",
        "fill": {"keep": "XXXXXXXXXXXXX..X"}}),
    ("POP80", "80S", {
        36: "X.......X.X.....",
        38: "....X.......X...",
        39: "....X.......X...",
        42: "X.X.X.X.X.X.X.X.",
        "v": "A.6.A.6.9.8.A.6.",
        "fill": {48: ".........X.X....", 45: ".............X..", 41: "...............X",
                 "v": ".........9.8.8.A"}}),
    ("SLOWROCK", "VINTAGE", {                   # the rhythm box's own
        36: "X.....X.X.......",
        37: "....X.......X...",
        69: "X.X.X.X.X.X.X.X.",
        62: "...X.......X....",
        "v": "A.5.A.8.8.5.A.5.",
        "fill": {37: ".............X.X", 63: ".........X......", "v": ".........7...9.A",
                 "r": "...............3"}}),
    ("TRAP", "TRAP", {                          # half time, rolling hats
        36: "X......X..X.....",
        39: "........X.......",
        42: "X.X.X.X.X.X.X.X.",
        "v": "A.6.7.8A9.A.7.8.",
        "r": "......2.......4.",
        "fill": {42: ".........X.X.X.X", 39: "...............X",
                 "v": ".........6.7.8.A", "r": ".........3.2.4.."}}),
    ("DRILL", "DRILL", {                        # sliding kicks, the late snare
        36: "X......X..X...X.",
        38: "....X......X....",
        42: "X..X..X...X..X..",
        "v": "A.7A9.6A.6A9.7A.",
        "fill": {38: "........XX.....X", "v": "........78.....A", "r": "........23......"}}),
    ("BOOMBAP", "BOOMBAP", {
        36: "X......X.XX.....",
        38: "....X.......X...",
        42: "X.X.X.X.X.X.X.X.",
        "v": "A.5.A.57A6A.A.6.",
        "c": "......1.........",
        "fill": {38: "...........X.X.X", "v": "...........7.8.9"}}),
    ("LOFI", "LO-FI", {                         # lazy, behind the beat
        36: "X......X..X.....",
        37: "....X.......X...",
        42: "X.X.X.X.X.X.X.X.",
        "v": "8.4.8.47.4A.8.4.",
        "c": "..2.....2.....2.",
        "fill": {37: ".............X.X", 36: "...........X....", "v": "...........6.7.8"}}),
    ("PHONK", "PHONK", {                        # cowbell melody over a dirty 808
        36: "X..X......X.....",
        39: "....X.......X...",
        56: "X.X..X.X..X..X.X",
        42: ".X.X.X.X.X.X.X.X",
        "v": "A6A7A7A6A6A7A7A6",
        "fill": {"keep": "XXXXXXXXXXXX.X.X"}}),
    ("HOUSE", "HOUSE", {
        36: "X...X...X...X...",
        39: "....X.......X...",
        46: "..X...X...X...X.",
        42: ".X.X.X.X.X.X.X.X",
        "v": "A49.A49.A49.A49.",
        "fill": {"keep": "XXXXXXXXXXXXX.X."}}),
    ("DEEP", "D.HOUSE", {
        36: "X...X...X...X...",
        37: "...X.......X..X.",
        42: "..X...X...X...X.",
        70: ".X...X...X...X..",
        "v": "A.8.A.8.A.8.A.8.",
        "c": ".2...2...2...2..",
        "fill": {37: ".......X.......X", "keep": "XXXXXXXXXXXXX.XX", "v": ".......6.......8"}}),
    ("TECHNO", "TECHNO", {
        36: "X...X...X...X...",
        42: "..X...X...X...X.",
        51: ".X.X.X.X.X.X.X.X",
        39: "....X.......X...",
        "v": "A.9.A.9.A.9.A.9.",
        "c": ".1.1.1.1.1.1.1.1",
        "fill": {"keep": "XXXXXXXXXXXXX..."}}),
    ("MINIMAL", "MINIMAL", {
        36: "X...X...X...X...",
        37: "......X.......X.",
        42: "..X.......X.....",
        76: ".X.......X...X..",
        "v": "A.7.A.6.A.7.A.6.",
        "c": ".1.......2...1..",
        "fill": {37: "...........X...X", "v": "...........5...7"}}),
    ("ELECTRO", "ELECTRO", {                    # the 808 funk: syncopated kicks
        36: "X......X..X.....",
        38: "....X.......X...",
        42: "X.XXX.XXX.XXX.XX",
        39: "...............X",
        "v": "A.5AA.6A8.A5A.6A",
        "fill": {"keep": "XXXXXXXXXXXXXX.X"}}),
    ("DISCO", "DISCO", {
        36: "X...X...X...X...",
        39: "....X.......X...",
        46: "..X...X...X...X.",
        42: "X...X...X...X...",
        "v": "A.9.A.9.A.9.A.9.",
        "fill": {48: ".........X......", 45: "...........X....", 41: ".............X..",
                 "v": ".........9.8.8.."}}),
    ("2STEP", "GARAGE", {                       # the skipping kick
        36: "X.........X.....",
        38: "....X.......X...",
        42: "X.XXX.X.X.XXX.X.",
        37: ".......X......X.",
        "v": "A.5AA.6.9.A5A.6.",
        "fill": {36: ".....X...X......", "v": ".....8...8......"}}),
    ("JUNGLE", "JUNGLE", {                      # a break chopped at 170
        36: "X.........X.....",
        38: "....X..X.X..X...",
        42: "X.X.X.X.X.X.X.X.",
        40: "..............X.",
        "v": "A.6.A.6A7A9.A.8.",
        "c": ".......1........",
        "fill": {38: ".X.X.........X.X", "v": ".6.7.........9.A", "r": "...............2"}}),
    ("DUBSTEP", "DUBSTEP", {                    # half time at 140
        36: "X.........X.....",
        38: "........X.......",
        42: "X.X.X.X.X.X.X.X.",
        "v": "A.5.6.5.A.5.A.5.",
        "fill": {38: ".............X.X", 36: "...........X....", "v": "...........9.A.A",
                 "r": ".............2.4"}}),
    ("DEMBOW", "DEMBOW", {                      # the reggaeton tresillo
        36: "X...X...X...X...",
        38: "...X..X....X..X.",
        42: "X.X.X.X.X.X.X.X.",
        "v": "A.6AA.A.A.6AA.A.",
        "fill": {38: ".........X...X.X", "v": ".........8...9.A"}}),
    ("AMAPIANO", "AMAPIANO", {                  # the log drum's space, shakers
        36: "X...X...X...X...",
        37: "...X......X.....",
        70: "XXXXXXXXXXXXXXXX",
        39: "......X.......X.",
        "v": "A453A453A453A453",
        "c": ".2.2.2.2.2.2.2.2",
        "fill": {"keep": "XXXXXXXXXXXXX..."}}),
    ("AFRO", "AFRO", {                          # afrobeats: the bell and the congas
        36: "X......X..X.....",
        37: "...X..X.......X.",
        56: "X.X.XX.X.XX.X.X.",
        63: "......X.......X.",
        "v": "A.7AA6A.8A6.A.A.",
        "fill": {62: ".X.........X.X.X", "v": ".6.........7.8.A"}}),
    ("LATIN", "LATIN", {                        # clave 3-2, congas, cowbell
        75: "X..X..X...X.X...",
        62: "..X...X...X...X.",
        63: "...X.......X.XX.",
        56: "X...X...X...X...",
        36: "X.......X.......",
        "v": "A.6A7.A.A.A6A.A.",
        "fill": {65: ".X...X...X......", 66: ".......X.......X",
                 "v": ".7...8.9.A.....A"}}),
    ("TRIBAL", "TRIBAL", {                      # toms and a low drum
        36: "X.....X...X.....",
        43: "..X.......X..X..",
        48: "....X..X....X...",
        70: "X.X.X.X.X.X.X.X.",
        "v": "A.7.A.AA7.A.A6..",
        "fill": {45: ".X.X.X..........", 41: ".........X.X...X",
                 "v": ".6.7.8...9.A...A"}}),
    ("DRIVE", "SYNTHWV", {                      # the 80s highway: gated snare
        36: "X...X...X...X...",
        38: "....X.......X...",
        42: "X.X.X.X.X.X.X.X.",
        "v": "A.6.A.6.A.6.A.6.",
        "fill": {50: ".........X......", 47: "...........X....", 43: ".............X..",
                 41: "...............X", "v": ".........A.9.9.A"}}),
    ("CHIP", "CHIP", {
        36: "X.......X.X.....",
        38: "....X.......X...",
        42: "..X...X...X...X.",
        "v": "A...A.8.A.A.A.8.",
        "fill": {38: ".........X.X.X.X", "v": ".........9.A.A.A", "r": ".............2.3"}}),
    ("ARCADE", "ARCADE", {
        36: "X..X..X...X.....",
        38: "....X.......X...",
        42: "X.X.X.X.X.X.X.X.",
        56: "...............X",
        "v": "A6.7A.8.8.AA.A.A",
        "fill": {48: ".........X......", 45: "...........X....", 41: ".............X..",
                 "keep": "XXXXXXXXXXXXXXXX", "v": ".........A.A.A.."}}),
    ("GLITCH", "GLITCH", {                      # stutters and gaps
        36: "X..X.....X.X....",
        38: "....X.......X...",
        42: "XX..X.XX.X..X.XX",
        "v": "A6.7A.68.A.AA.67",
        "r": ".2....3.......4.",
        "c": ".1....2.......1.",
        "fill": {38: "..X..X..X.X..X..", "keep": "XXXXXXXXXXXXXX.X",
                 "v": "..9..A..A.A..A..", "r": "..4..2..3.2..4.."}}),
    ("EBM", "INDUSTR", {                        # body music: 16th bass drum push
        36: "X...X...X...X...",
        38: "....X.......X...",
        42: "..X...X...X...X.",
        40: ".......X......X.",
        "v": "A.8.A.8AA.8.A.AA",
        "fill": {36: ".X.X.X..........", 38: ".........X.X.X.X",
                 "v": ".7.8.9...8.9.A.A", "r": ".............2.3"}}),
    ("HYPER", "HYPER", {
        36: "X......X..X.....",
        39: "....X.......X...",
        42: "X.XXX.XXX.XXX.XX",
        "v": "A.6AA.6A9.A6A.6A",
        "r": "...2.......2...3",
        "fill": {"keep": "XXXXXXXXXXXX...X"}}),
    ("DRIFT", "AMBIENT", {                      # almost nothing
        36: "X.........X.....",
        37: "......X.........",
        70: "..X.......X...X.",
        80: "X.......X.......",
        "v": "6.3.....5.5.4.3.",
        "c": "..2...1...2...3.",
        "fill": {37: ".............X..", 43: "...............X", "v": ".............4.5"}}),
    ("SWING", "JAZZ", {                         # ride, feathered kick, the hats on 2 and 4
        51: "X...X..XX...X..X",
        44: "....X.......X...",
        36: "X.......X.......",
        37: "..............X.",
        "v": "7...8..5A...8.45",
        "c": "..............2.",
        "fill": {38: "..X..X...X.X.X..", "v": "..4..5...5.6.7.."}}),
]


FC_NORM, FC_FILL, FC_NOFILL = 0, 1, 2                                   # core.h FC_*


def beat_rows(name, rows):
    """A beat's steps: the notes the bar and its virada play, the velocity, the flags and the conditions.
    "fill": the virada (FILL: GLO + 9 held, key 10 for the next bar). Its note rows add hits on the bar's
    rests; "keep" ("X" = the bar's step plays in the virada too, "." = it is silent there; default all X).
    A step is one set of notes: where both hit, they hit the same."""
    def hits(rr):
        ns = [[] for _ in range(16)]
        for k, r in rr.items():
            if isinstance(k, int):
                assert len(r) == 16, (name, k)
                for i, c in enumerate(r):
                    if c != ".":
                        ns[i].append(k)
        return ns
    a = hits(rows)
    f = [list(x) for x in a]
    fill = rows.get("fill")
    if fill:
        assert all(len(r) == 16 for k, r in fill.items() if k != "keep" and isinstance(r, str)), name
        fb, keep = hits(fill), fill.get("keep", "X" * 16)
        assert len(keep) == 16, name
        for i in range(16):
            f[i] = fb[i] or (a[i] if keep[i] == "X" else [])
    assert f != a, (name, "a virada like the bar")
    notes, vel, flags, cond = [[] for _ in range(16)], [0] * 16, [0] * 16, 0
    for i in range(16):
        if sorted(a[i]) == sorted(f[i]):
            notes[i], c = a[i], FC_NORM
        elif not f[i]:
            notes[i], c = a[i], FC_NOFILL
        else:
            assert not a[i], (name, "the bar and its virada both hit, differently, on step", i + 1, a[i], f[i])
            notes[i], c = f[i], FC_FILL
        cond |= c << (2 * i)
        assert len(notes[i]) <= 4, (name, i, notes[i])
        src = fill if c == FC_FILL and fill else rows                   # a virada's own steps: its own v / r / c
        v = src.get("v", rows.get("v", "." * 16))[i]
        if v == "A":
            vel[i], flags[i] = 127, 1                                   # SF_ACCENT
        elif v != ".":
            vel[i] = 14 * int(v)
        else:
            vel[i] = 96
        r = src.get("r", "." * 16)[i]
        if r != ".":
            flags[i] |= (int(r) - 1) << 3                               # SF_RATCH
        ch = src.get("c", "." * 16)[i]
        if ch != ".":
            flags[i] |= int(ch) << 5                                    # SF_CHANCE: 1..3 = 75 50 25 %
        if not notes[i]:
            vel[i], flags[i] = 0, 0
    return notes, vel, flags, cond


def beats_c():
    names = [k[0] for k in KITS]
    L = [f"#define DS_NBEATS {len(BEATS)}u", "static const dbeat_t DS_BEATS[DS_NBEATS] = {"]
    for name, kitname, rows in BEATS:
        assert len(name) <= 8 and kitname in names, name
        notes, vel, flags, cond = beat_rows(name, rows)
        L.append(f'    {{"{name}", {{' + ", ".join("{" + ", ".join(str(n) for n in ns) + "}" for ns in notes) + "},")
        L.append("     {" + ", ".join(map(str, vel)) + "}, {" + ", ".join(map(str, flags)) + f"}}, 0x{cond:08X}u}},")
    L.append("};")
    L.append("#define DS_BEAT_NAME_LIST " + ", ".join(f'"{b[0]}"' for b in BEATS))
    first = [names.index(n) + 1 for n in KIT_FIRST]
    nav = [0] + first + [i + 1 for i in range(len(KITS)) if i + 1 not in first]
    L.append("/* the browser's order: G_KIT values (0 = GM) */")
    L.append("static const uint8_t DS_KIT_NAV[DS_NKITS + 1u] = {" + ", ".join(map(str, nav)) + "};")
    own = [0] * (len(KITS) + 1)
    for bi, (name, kitname, rows) in enumerate(BEATS):
        g = names.index(kitname) + 1
        if not own[g]:
            own[g] = bi + 1
    L.append("/* a kit's own beat by G_KIT (DS_BEATS index + 1, 0 = none): loaded into an untouched drum track */")
    L.append("static const uint8_t DS_KIT_BEAT[DS_NKITS + 1u] = {" + ", ".join(map(str, own)) + "};")
    return L


def main(path):
    levels = json.loads(LEVELS_FILE.read_text()) if LEVELS_FILE.exists() else {}
    L = ["/* generated by tools/gen_drumkits.py */", "#pragma once",
         f"#define DS_NKITS {len(KITS)}u", "static const dkit_t DS_KITS[DS_NKITS] = {"]
    for name, style, crush, k in KITS:
        assert len(name) <= 8 and len(style) <= 12, name
        L.append(f'    {{"{name}", "{style}", 0x{crush:02X}, {{')
        for lane in LANES:
            v = enc(k[lane], levels.get(name, {}).get(lane, 0.0))
            assert len(v) == 22 and all(0 <= x <= 255 for i, x in enumerate(v) if i not in (4, 17)), (name, lane, v)
            assert -128 <= v[4] <= 127 and -128 <= v[17] <= 127, (name, lane)   # bend, fenv: int8_t
            L.append("        {" + ", ".join(str(x) for x in v) + f"}},   /* {lane} */")
        L.append("    }},")
    L.append("};")
    L.append("#define DS_KIT_NAME_LIST " + ", ".join(f'"{k[0]}"' for k in KITS))
    L.append("#define DS_KIT_STYLE_LIST " + ", ".join(f'"{k[1]}"' for k in KITS))
    L += beats_c()
    Path(path).write_text("\n".join(L) + "\n")
    print(f"drum kits: {len(KITS)} synthesised, {len(BEATS)} beats -> {path}")


if __name__ == "__main__":
    main(sys.argv[1])
