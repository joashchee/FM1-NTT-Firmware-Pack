/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Felucca user interface. Four columns map to KNOB 1..4. Rendering is lazy:
 * every element remembers what it last drew and is redrawn only on change. */
#ifndef FELUCCA_DATE
#define FELUCCA_DATE __DATE__          /* build.py passes a reproducible one */
#endif
#ifndef FELUCCA_VERSION
#define FELUCCA_VERSION "1.0.1"         /* build.py --release X.Y passes its own */
#endif
static void project_save(uint32_t slot);
static void panel_setup(void);
static void project_load(uint32_t slot);
static int project_used(uint32_t slot);
static int up_used(uint32_t k);              /* user presets: upreset.c */
static int up_load(uint32_t k);
static uint32_t up_count(void);
static uint32_t up_nth(uint32_t n);
static uint32_t up_rank(uint32_t slot);
static void up_name(uint32_t k, char *b);
static void up_slot_label(char *b, uint32_t k);
static void up_ui(uint32_t op, uint32_t k);
static uint32_t user_of(const track_t *t)    /* user preset slot its sound came from, UP_SLOTS = none */
{
    return t->user && up_used(t->user - 1u) ? t->user - 1u : UP_SLOTS;
}
static uint32_t up_gen;                      /* bumped on every user bank change (redraws) */
static uint8_t sync_reload;                  /* engine / preset / project / user preset loaded: editor RELOAD push */

#define ACC C_HI                   /* amber everywhere; white is the only accent */
#define VAL(c) ((c) == ui.hot_col && ui.hot_t ? C_WHITE : C_HI)
#define RATIO(d, v) ((d)->max > (d)->min ? ((int32_t)(v) - (d)->min) * 1000 / ((d)->max - (d)->min) : -1)
/* layout: four 60 px columns, each a card (Jangada, after Felucca 1.0); text lines are the 16 px
 * (S, M) and 32 px (L) boxes of the old Terminus cells (gfx.c: aafont_t box / base) */
#define Y_HEAD 0
#define H_HEAD 20
#define COL_Y 21                      /* the column strips: rows 21 .. 72, the cards 22 .. 71 */
#define COL_H 52
#define Y_LABEL 26
#define Y_VALUE 44
#define Y_GAUGE 64
#define Y_SEP_END 70
#define Y_GRAPH 74
#define H_GRAPH 124
#define G_OY 24                       /* graphs draw in the lower 100 px; the focus readout sits on top */
#define Y_FOOT 202
#define H_FOOT 38

static struct {
    uint8_t home;
    uint8_t page;                /* index into PAGES */
    uint8_t fam_last[FAM_COUNT]; /* last page used per family */
    uint8_t bank;                /* SEQ: 16-step bank (follows the cursor) */
    uint8_t cursor;              /* SEQ: step being edited (STEP page KNOB 1 moves it) */
    uint8_t entry_open;          /* SEQ: keys held since the first press of this entry */
    uint8_t hot_col, hot_t;      /* column whose knob was just turned (drawn white) */
    uint8_t menu;                /* 0 off, 1 list, 2 about (HOME held) */
    uint8_t menu_sel;
    uint32_t menu_sig, home_t0;  /* HOME press time (btn_hold) */
    uint8_t force;               /* full redraw pending */
    uint8_t msg_t;               /* transient message frames */
    uint8_t bpm_t;               /* frames the BPM stays highlighted after a SELECT turn */
    uint8_t arm, arm_t;          /* destructive action armed: param id, frames left to confirm */
    uint32_t rec_t0;             /* REC press time (btn_hold) */
    uint32_t arp_t0;             /* Jangada: ARP press time (btn_hold): held = DRONE OFF */
    uint32_t lfo_t0;             /* Jangada 0.9.7: LFO press time (btn_hold): held = MOMENTARY (ui_input.c) */
    uint8_t confirm;             /* 1 = "clear the sequence?" (REC held on SEQ / ARP), 2 = "clear track n?" (TRACKS) */
    uint8_t confirm_trk;         /* the track the dialog clears */
    uint8_t uslot;               /* SAVE > USER: the selected user preset slot */
    uint8_t pcat;                /* Jangada 0.8.1: the PRESETS filter, a PC_* category (0: all) */
    char msg[24];
    uint32_t enc_t[NE];
    /* drawn-state cache */
    char col[4][32];
    /* Jangada 0.7 (after SLOOP 2.4): the columns' texts for the big values of a page without a graph */
    char big_l[4][8], big_v[4][12], big_u[4][8];
    uint16_t big_c[4];
    int16_t big_r[4];            /* Jangada 0.9.4: their gauges (0..1000, < 0 none), icons and kinds (BK_*), */
    uint8_t big_i[4], big_k[4];  /* for the circles (ui_draw.c graph_big) */
    uint8_t ev_cols;             /* Jangada 0.9.7: an engine's picture below, its knobs as circles in the columns' row */
    uint32_t graph_sig, head_sig, foot_sig, frame;
    uint8_t graph_top;           /* the graph strip's top G_OY rows hold something */
} ui;

static const page_t *cur_page(void) { return &PAGES[ui.page]; }

static uint32_t page_first(uint32_t fam)
{
    uint32_t i;
    for (i = 0; i < NPAGES; i++)
        if (PAGES[i].fam == fam)
            return i;
    return 0;
}

/* transient message in the top bar: a + b */
static void ui_say(const char *a, const char *b)
{
    uint32_t n;
    str_cpy(ui.msg, a, sizeof ui.msg);
    n = str_len(ui.msg);
    str_cpy(ui.msg + n, b, sizeof ui.msg - n);
    ui.msg_t = 40;
}

static void ui_message(const char *s) { ui_say(s, ""); }

static void page_entered(void)
{
    const page_t *pg = cur_page();
    song.seq_mode = !ui.home && pg->fam == FAM_SEQ;
    ui.entry_open = 0;
    ui.hot_t = 0;                                /* the white value / focus box was the old page's */
    ui.force = 1;
}

static int step_on(const step_t *st) { return st->time == ST_NOTE && st->n; }

static void step_clear(step_t *st)
{
    st->n = 0;
    st->time = ST_REST;
    st->flags = 0;
    st->vel = 0;
}

/* SEQ cursor: wraps inside the pattern length, the bank follows, a step entry ends */
static void cursor_set(int32_t c)
{
    int32_t len = TSEL->p[P_SLEN] > 0 ? TSEL->p[P_SLEN] : 1;
    ui.cursor = (uint8_t)((c % len + len) % len);
    ui.bank = (uint8_t)(ui.cursor / 16u);
    ui.entry_open = 0;
}

static void cursor_fix(void)                           /* LEN got shorter: onto the last step */
{
    if (ui.cursor >= (uint32_t)TSEL->p[P_SLEN])
        cursor_set(TSEL->p[P_SLEN] - 1);
}

static void note_name(char *b, uint32_t n)
{
    str_cpy(b, N_NOTE[n % 12u], 4);
    fmt_int(b + str_len(b), (int32_t)(n / 12u) - 1);
}

/* back: 1 = the page before (OCT- held, issue #4), wrapping to the family's last */
static void open_family_dir(uint32_t fam, int back)
{
    if (!ui.home && cur_page()->fam == fam && back) {  /* same button with OCT- held: the page before */
        uint32_t f0 = page_first(fam), l = f0, i = ui.page;
        while (l + 1u < NPAGES && PAGES[l + 1u].fam == fam)
            l++;
        do                                             /* (from the first: on to the family's last) */
            i = i > f0 ? i - 1u : l;
        while (i != ui.page && !page_used(i));
        ui.page = (uint8_t)i;
    } else if (!ui.home && cur_page()->fam == fam) {   /* same button again: next page */
        uint32_t i = ui.page + 1u;
        while (i < NPAGES && PAGES[i].fam == fam && !page_used(i))
            i++;                                       /* EDIT 3 / 4 of an engine without them */
        if (i >= NPAGES || PAGES[i].fam != fam)
            i = page_first(fam);
        ui.page = (uint8_t)i;
    } else {
        ui.page = ui.fam_last[fam] && PAGES[ui.fam_last[fam]].fam == fam && page_used(ui.fam_last[fam])
                      ? ui.fam_last[fam] : (uint8_t)page_first(fam);
    }
    ui.fam_last[fam] = ui.page;
    ui.home = 0;
    page_entered();
}
static void open_family(uint32_t fam) { open_family_dir(fam, 0); }

static void go_home(void)
{
    ui.home = 1;
    ui.entry_open = 0;
    ui.hot_t = 0;
    song.seq_mode = 0;
    ui.force = 1;
}

/* ------------------------------------------------------- track setup --- */
/* factory sequence patterns (presets refer to them with PAT(n)): absolute notes,
 * 0 = rest; flags 1 = accent, 2 = slide, 4 = tie (holds the previous note) */
#define T_ 4
static const struct {
    uint8_t note[16], flags[16];
} PATTERNS[] = {
    {{45, 45, 57, 45, 0, 48, 45, 55, 45, 0, 57, 52, 45, 48, 0, 50},          /* 1 ACID */
     {1, 0, 2, 0, 0, 0, 1, 2, 0, 0, 1, 0, 0, 2, 0, 1}},
    {{0, 36, 0, 36, 0, 36, 0, 48, 0, 36, 0, 36, 0, 39, 0, 43},               /* 2 OFFBEAT bass */
     {0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0}},
    {{60, 0, 67, 0, 72, 67, 0, 64, 62, 0, 69, 0, 74, 69, 0, 67},             /* 3 MELODY pluck */
     {1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0}},
    {{72, 0, 0, 74, 0, 0, 76, 0, 79, 0, 76, 0, 74, 0, 0, 0},                  /* 4 LEAD */
     {1, T_, 0, 2, T_, 0, 0, 0, 1, 0, 2, 0, 0, T_, T_, 0}},
    {{60, 0, 0, 0, 0, 0, 0, 0, 57, 0, 0, 0, 55, 0, 0, 0},                    /* 5 PAD: long notes */
     {0, T_, T_, T_, T_, T_, T_, 0, 0, T_, T_, 0, 0, T_, T_, 0}},
    {{0, 0, 60, 0, 0, 63, 0, 0, 0, 0, 60, 0, 0, 65, 0, 63},                  /* 6 KEYS: offbeat stabs */
     {0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0}},
    {{72, 0, 0, 79, 0, 0, 84, 0, 0, 0, 76, 0, 0, 0, 0, 0},                   /* 7 BELL: sparse */
     {1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0}},
    {{36, 0, 0, 0, 0, 0, 0, 36, 0, 0, 34, 0, 0, 0, 0, 0},                    /* 8 SUB: low, held */
     {1, T_, T_, T_, 0, 0, 0, 0, 0, 0, 0, T_, T_, T_, 0, 0}},
    /* SLICE (eng_slice.c): note = C4 + slice */
    {{60, 61, 62, 67, 64, 65, 60, 69, 68, 70, 62, 67, 72, 72, 74, 64},       /* 9 CHOP: 16 slices re-ordered */
     {1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0}},
    {{60, 60, 61, 61, 62, 0, 63, 63, 64, 65, 65, 0, 66, 66, 66, 67},         /* 10 STUTTER: 8 slices, repeats */
     {1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0}},
    {{60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75},       /* 11 SLICES: in order */
     {1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0}},
    /* Jangada */
    {{36, 0, 0, 43, 0, 0, 46, 0, 36, 0, 0, 43, 0, 42, 43, 46},             /* 12 BAIAO bass: with the zabumba */
     {1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 2, 0, 0}},                     /* (F#: the NORD 4th) */
};
#undef T_
#define NPATTERNS (sizeof PATTERNS / sizeof PATTERNS[0])

/* the parts' sounds at power-on (engine, preset): bass, pad, lead */
static const uint8_t TRK_DEF[NPART][2] = {{0, 4}, {1, 5}, {3, 0}};   /* ANALOG ACID, DIGITAL PAD, LOFI PULSE LD */
static uint32_t trk_def_engine(uint32_t i) { return i < NPART ? TRK_DEF[i][0] : 0u; }

static int seq_is_empty(const track_t *t)
{
    uint32_t i;
    for (i = 0; i < NSTEP; i++)
        if (t->step[i].n)
            return 0;
    return 1;
}

/* A sequence that came from a preset and was not touched since is replaced by the next
 * preset's pattern; one the user recorded, edited or loaded from a project is kept. */
static uint32_t pat_sig[NTRK];               /* seq_sig() right after a preset pattern was loaded */
static uint32_t seq_sig(const track_t *t)    /* FNV-1a over the steps and LEN (and the nudges, conditions, locks) */
{
    const uint8_t *b = (const uint8_t *)t->step, *x = (const uint8_t *)&t->x;
    uint32_t i, h = 2166136261u ^ (uint32_t)(uint16_t)t->p[P_SLEN];
    for (i = 0; i < sizeof t->step; i++)
        h = (h ^ b[i]) * 16777619u;
    for (i = 0; i < sizeof t->x; i++)
        h = (h ^ x[i]) * 16777619u;
    return h;
}
static int seq_replaceable(const track_t *t) { return seq_is_empty(t) || seq_sig(t) == pat_sig[trk_index(t)]; }

static void load_pat16(track_t *t, const uint8_t *note, const uint8_t *flags)   /* PATTERNS[] format (user presets too) */
{
    uint32_t i;
    for (i = 0; i < NSTEP; i++) {
        step_t *s = &t->step[i];
        uint8_t n = i < 16u ? note[i] : 0, fl = i < 16u ? flags[i] : 0;
        s->note[0] = n;
        s->n = n ? 1 : 0;
        s->time = (fl & 4u) ? ST_TIE : n ? ST_NOTE : ST_REST;
        s->flags = n ? (fl & SF_STEP) : 0;              /* Jangada: RTCH / CHNC too */
        s->vel = n ? 96 : 0;
    }
    memset(&t->x, 0, sizeof t->x);                  /* no nudge, condition, lock (zeroed: the ISR may read it; */
    t->p[P_SLEN] = 16;                              /* the locks in force let go at the next step) */
    pat_sig[trk_index(t)] = seq_sig(t);
}

/* Jangada: factory beat b (DS_BEATS, drum_synth.c) into the drum track; untouched since, the next kit's
 * own beat replaces it, as a preset's PAT does on a part */
static void load_beat(uint32_t b)
{
    const dbeat_t *bt = &DS_BEATS[b % DS_NBEATS];
    track_t *t = TDRUM;
    uint32_t i, k;
    for (i = 0; i < NSTEP; i++) {
        step_t *s = &t->step[i];
        uint32_t n = 0;
        for (k = 0; k < 4u; k++)
            s->note[k] = 0;
        if (i < 16u)
            for (k = 0; k < 4u; k++)
                if (bt->note[i][k])
                    s->note[n++] = bt->note[i][k];
        s->n = (uint8_t)n;
        s->time = n ? ST_NOTE : ST_REST;
        s->flags = n ? (uint8_t)(bt->flags[i] & SF_STEP) : 0;
        s->vel = n ? bt->vel[i] : 0;
    }
    memset(&t->x, 0, sizeof t->x);                  /* (as load_pat16) */
    for (i = 0; i < 16u; i++)                       /* the virada: steps only in the fill, or never in it */
        step_cond_set(t, i, bt->cond >> (2u * i) & 3u);
    t->p[P_SLEN] = 16;
    pat_sig[TRK_DRUM] = seq_sig(t);
    drums.beat = (int16_t)(b % DS_NBEATS + 1u);
}

/* Jangada: the drum kit (GLO > KIT, the PRESETS knob on the drum track); an empty or untouched
 * drum track gets the kit's own beat */
static void drum_kit_set(uint32_t kit)
{
    song.g[G_KIT] = (int16_t)(kit % DRUM_KITS);
    if (DS_KIT_BEAT[drum_kit()] && is_drum(TDRUM) && seq_replaceable(TDRUM))
        load_beat(DS_KIT_BEAT[drum_kit()] - 1u);
}

static void track_defaults_steps(track_t *t)
{
    uint32_t i;
    for (i = 0; i < NSTEP; i++)
        step_clear(&t->step[i]);
    seqx_clear(t);                                   /* no nudge, no condition, no lock (after SLOOP 2.4) */
}

/* what loading a sound (factory or user preset) leaves alone: the mix (LEVEL, PAN, MUTE:
 * the TRACKS faders) and the pattern parameters (LEN, DIV, SWING, GATE). The SLICER is part
 * of the sound: a factory preset turns it OFF (its defaults), a user preset brings its own */
static int param_kept(uint32_t i)
{
    return i == P_LEVEL || i == P_PAN || i == P_MUTE || (i >= P_SLEN && i <= P_SGATE) || i == P_TFLT ||   /* (FILT: */
           i == P_STRUM || i == P_VLEAD;                                       /* the mix; STRUM, VLEAD: the playing) */
}

/* preset pi of the engine the track asked for: the whole sound (not the pattern parameters) */
/* Jangada: CHORD needs POLY (MONO / LEGATO / UNISON sound one note of the chord): on with another voice
 * mode, the track goes POLY; its sounding notes are let go, as a VOICE change does */
static void chord_poly(track_t *t)
{
    if (!t->p[P_CHORD] || t->p[P_VOICE] == V_POLY || is_drum(t))
        return;
    t->p[P_VOICE] = V_POLY;
    panic_req |= (uint8_t)(1u << (uint32_t)(t - trk));
    ui_message("VOICE POLY");
}

static void apply_preset_to(track_t *t, uint32_t pi)
{
    const engine_t *e = ENGINES[t->eng_req % NENGINES];
    uint32_t i;
    if (is_drum(t))
        return;
    panic_req |= (uint8_t)(1u << trk_index(t));       /* MONO/POLY may change: release what sounds */
    t->user = 0;
    if (t == TSEL)
        sync_reload = 1;
    if (!e->npresets)
        return;
    pi %= e->npresets;
    t->preset = (uint8_t)pi;
    for (i = 0; i < P_COUNT; i++)                     /* the rest of the sound to its defaults: a preset */
        if (!param_kept(i) && (i < P_E0 || i >= P_E0 + NEDIT))   /* (Jangada DRONES: after P_E15 too) */
            t->p[i] = TP[i].def;                     /* sounds the same after any edit (not the pattern, not the mix) */
    for (i = 0; i < NEDIT; i++)
        t->p[P_E0 + i] = (int16_t)(i < 8u ? e->presets[pi].e[i]
                                          : e->presets[pi].x[i - 8u] ? e->presets[pi].x[i - 8u] - 1 : e->edit[i].def);
    t->p[P_ATK] = e->presets[pi].env[0];
    t->p[P_DEC] = e->presets[pi].env[1];
    t->p[P_SUS] = e->presets[pi].env[2];
    t->p[P_REL] = e->presets[pi].env[3];
    t->p[P_ED_FLT] = e->presets[pi].fenv;
    t->p[P_VOICE] = e->presets[pi].mono && !t->p[P_CHORD] ? V_LEGATO : V_POLY;   /* mono presets keep the legato
                                                                                 * feel (CHORD: POLY, Jangada) */
    {   /* the rest of the patch: sends, arpeggiator, a pattern for an empty sequencer */
        static const uint8_t FX_DEF[4] = {0, 24, 28, 36};
        const preset_t *pr = &e->presets[pi];
        for (i = 0; i < 4u; i++) {
            t->p[P_DIST + i] = (int16_t)(pr->fx[i] ? pr->fx[i] - 1 : FX_DEF[i]);
            t->p[P_AMODE + i] = (int16_t)(pr->arp[i] ? pr->arp[i] - 1 : TP[P_AMODE + i].def);
        }
        if (pr->set) {                                 /* Jangada: the rest of the sound (LFO, matrix, ..) */
            const int16_t (*sp)[2];
            for (sp = pr->set; (*sp)[0] >= 0; sp++)
                if ((*sp)[0] < P_COUNT && !param_kept((uint32_t)(*sp)[0])) {
                    const param_desc_t *d = track_desc(t, (uint32_t)(*sp)[0]);
                    t->p[(*sp)[0]] = (int16_t)clamp((*sp)[1], d->min, d->max);
                }
        }
        if (pr->pat && pr->pat <= NPATTERNS && seq_replaceable(t))
            load_pat16(t, PATTERNS[pr->pat - 1u].note, PATTERNS[pr->pat - 1u].flags);
    }
}

/* the engine's defaults and its first preset. With the audio IRQ off: the ISR sees the old engine with
 * its values or the new one with its own (voice.c engine_block), never one with the other's */
static void set_engine_raw(track_t *t, uint32_t ei)   /* the writes alone: the caller keeps the IRQ off */
{
    const engine_t *e = ENGINES[ei % NENGINES];
    uint32_t i;
    t->eng_req = (uint8_t)(ei % NENGINES);
    for (i = 0; i < NEDIT; i++)
        t->p[P_E0 + i] = e->edit[i].def;
    apply_preset_to(t, 0);
}
static void set_engine_of(track_t *t, uint32_t ei)
{
    if (is_drum(t))
        return;
    fm1_irq_off();
    set_engine_raw(t, ei);
    fm1_irq_on();
}

static void apply_preset(uint32_t pi) { apply_preset_to(TSEL, pi); }

/* Jangada: track 4's notes and voices go at once (IRQ off by the caller): as the drum track
 * nothing renders its synth voices, as a synth its drum notes mean nothing */
static void t4_reset(track_t *t)
{
    uint32_t i;
    for (i = 0; i < NVOICE; i++)
        t->v[i].active = t->v[i].gate = 0;
    t->nheld = t->arp_phys = t->arp_note = t->arp_nch = t->seq_n = t->rat_left = 0;
    t->nmono = t->mono_note = t->xp_n = 0;
}

/* GLO > DRUMS T4 / TRACKS TYPE changed (the knob, the editor, the console): track 4 becomes a
 * synth part with a sound of its own (TRIO), or the drum track again. One IRQ-off block: the
 * audio ISR sees song.t4 change only with the track ready. project_load applies its own. */
static void t4_follow(void)
{
    track_t *t = TDRUM;
    uint32_t want = song.g[G_T4] != 0, i;
    if (want == song.t4)
        return;
    fm1_irq_off();
    t4_reset(t);
    if (want) {
        t->eng_req = 6;                                 /* TRIO, its defaults, then its first preset */
        for (i = 0; i < NEDIT; i++)
            t->p[P_E0 + i] = ENGINES[6]->edit[i].def;
    }
    song.t4 = (uint8_t)want;
    if (want) {
        apply_preset_to(t, 0);
        t->engine = t->eng_req;
    }
    fm1_irq_on();
    ui_message(want ? "TRACK 4: SYNTH" : "TRACK 4: DRUMS");
    sync_reload = 1;
    ui.force = 1;
}
static void set_engine(uint32_t ei) { set_engine_of(TSEL, ei); }

static void track_defaults(track_t *t)
{
    uint32_t i;
    for (i = 0; i < P_COUNT; i++)
        if (i < P_E0 || i >= P_E0 + NEDIT)             /* (Jangada DRONES: parameters after P_E15) */
            t->p[i] = TP[i].def;
    track_defaults_steps(t);
}

/* switch engine (its defaults + first preset) and say so */
static void select_engine(uint32_t e)
{
    if (is_drum(TSEL))
        return;
    set_engine(e);
    ui_say("ENGINE ", ENGINES[TSEL->eng_req]->name);
    ui.force = 1;
}

/* the presets of every engine, then (Jangada 0.6) the used FM6 bank voices by name, then the used user presets, as
 * one list (the PRESETS knob and the PRESETS page browse it). After SLOOP's DX7 engine (majnikool, GPL-3.0): there
 * the loaded DX7 voices follow the factory sounds; here they are the FM6 banks' (eng_fm6.c fm6_bank_used / _nm,
 * kept by fm6_bank.c: no flash read). PRESET_FM6 marks a bank voice in the list, *k its slot (0..63: B1..B64) */
#define PRESET_FM6 (NENGINES + 1u)

static int fm6_list_used(uint32_t k)                 /* bank slot k holds a patch */
{
    return k < FM6_BANK_N && ((fm6_bank_used[k / FM6_BANK_VOICES] >> (k % FM6_BANK_VOICES)) & 1u);
}
static uint32_t fm6_list_count(void)                 /* the used bank slots */
{
    uint32_t b, w, n = 0;
    for (b = 0; b < FM6_BANKS; b++)
        for (w = fm6_bank_used[b]; w; w &= w - 1u)
            n++;
    return n;
}
static uint32_t fm6_list_nth(uint32_t n)             /* the n-th used slot (n < fm6_list_count()) */
{
    uint32_t k;
    for (k = 0; k < FM6_BANK_N; k++)
        if (fm6_list_used(k) && !n--)
            return k;
    return 0;
}
static uint32_t fm6_list_rank(uint32_t k)            /* the used slots before slot k */
{
    uint32_t i, n = 0;
    for (i = 0; i < k && i < FM6_BANK_N; i++)
        n += (uint32_t)fm6_list_used(i);
    return n;
}

static uint32_t preset_pos(uint32_t *total)          /* list index of the selected track's preset */
{
    uint32_t n = 0, cur = 0, e, nb = fm6_list_count();
    int32_t s = TSEL->p[P_E7] - (int32_t)FM6_NFACTORY;
    for (e = 0; e < NENGINES; e++) {
        if (e == TSEL->eng_req)
            cur = n + TSEL->preset % (ENGINES[e]->npresets ? ENGINES[e]->npresets : 1u);
        n += ENGINES[e]->npresets;
    }
    if (TSEL->eng_req == ENGI_FM6 && s >= 0 && fm6_list_used((uint32_t)s))   /* an FM6 track on a bank voice */
        cur = n + fm6_list_rank((uint32_t)s);
    if (user_of(TSEL) < UP_SLOTS)
        cur = n + nb + up_rank(user_of(TSEL));
    *total = n + nb + up_count();
    return cur;
}

/* list index n (< total) -> engine, *k its preset; PRESET_FM6 = an FM6 bank voice, *k its slot; NENGINES = a user
 * preset, *k its slot */
static uint32_t preset_at(uint32_t n, uint32_t *k)
{
    uint32_t e, nb;
    for (e = 0; e < NENGINES && n >= ENGINES[e]->npresets; e++)
        n -= ENGINES[e]->npresets;
    if (e < NENGINES) {
        *k = n;
        return e;
    }
    if (n < (nb = fm6_list_count())) {
        *k = fm6_list_nth(n);
        return PRESET_FM6;
    }
    *k = up_nth(n - nb);
    return NENGINES;
}

/* Jangada 0.6 (after SLOOP's kind jump, majnikool): the group of list index n, in the list's own order: an engine's
 * presets (0..NENGINES-1), an FM6 bank's voices (PG_FM6 + 0 / 1), the user presets (PG_USER). Hold HOME and turn
 * PRESETS, or turn KNOB 3 on the PRESETS page, to go a group at a time; the top bar names it */
enum { PG_FM6 = NENGINES, PG_USER = PG_FM6 + FM6_BANKS };
static uint32_t preset_group(uint32_t n)
{
    uint32_t k, e = preset_at(n, &k);
    return e == PRESET_FM6 ? PG_FM6 + k / FM6_BANK_VOICES : e == NENGINES ? (uint32_t)PG_USER : e;
}
static const char *preset_kind(uint32_t n)           /* the group's short name (the KIND column) */
{
    static const char *const BK[FM6_BANKS] = {"BANK 1", "BANK 2"};
    uint32_t g = preset_group(n);
    return g < PG_FM6 ? ENGINES[g]->name : g < PG_USER ? BK[g - PG_FM6] : "USER";
}
static const char *preset_kind_long(uint32_t n)      /* ... and in the top bar */
{
    static const char *const BK[FM6_BANKS] = {"FM6 BANK 1", "FM6 BANK 2"};
    uint32_t g = preset_group(n);
    return g < PG_FM6 ? ENGINES[g]->name : g < PG_USER ? BK[g - PG_FM6] : "USER PRESETS";
}
/* Jangada 0.8.1 (issue #2): the categories. Each factory preset has one (preset_t.cat: BASS, LEAD, ..); KNOB 2 on the
 * PRESETS page picks one and then every way of browsing (the PRESETS knob, KNOB 1, the group jump) walks only
 * its presets, across the engines. ALL: the whole list as before. The FM6 bank voices and the user presets
 * have none: ALL only. (KNOB 4 in 0.8.1; 0.8.2 put it where ENG was) */
static const char *const PC_NAMES[PC_COUNT] = {"ALL", "BASS", "LEAD", "PAD", "KEYS", "PLUCK", "PERC", "DRONE", "FX"};
static uint32_t preset_cat(uint32_t n)               /* the category of list index n, PC_NONE = none */
{
    uint32_t k, e = preset_at(n, &k);
    return e < NENGINES ? ENGINES[e]->presets[k].cat : PC_NONE;
}
static int preset_in(uint32_t n) { return !ui.pcat || preset_cat(n) == ui.pcat; }   /* shown by the filter */

/* the next (dir > 0) or the previous entry the filter shows, wrapping round; cur when there is none */
static uint32_t preset_step(uint32_t cur, int32_t dir)
{
    uint32_t total, i, n;
    preset_pos(&total);
    if (!total)
        return 0;
    for (i = 1; i <= total; i++) {
        n = dir > 0 ? (cur + i) % total : (cur + total * 2u - i) % total;
        if (preset_in(n))
            return n;
    }
    return cur;
}

/* the first entry the filter shows of the next (dir > 0) or the previous group, wrapping round */
static uint32_t preset_group_jump(uint32_t cur, int32_t dir)
{
    uint32_t total, n, g, i;
    preset_pos(&total);
    if (!total)
        return 0;
    cur %= total;
    g = preset_group(cur);
    for (i = 1; i < total; i++) {
        n = dir > 0 ? (cur + i) % total : (cur + total - i) % total;
        if (!preset_in(n) || preset_group(n) == g)
            continue;
        if (dir < 0) {                                   /* the previous group: back to its first shown */
            g = preset_group(n);
            while (n && preset_group(n - 1u) == g)
                n--;
            while (!preset_in(n))
                n++;
        }
        return n;                                        /* (forward: the first shown of the next group) */
    }
    return cur;
}

/* the filter: KNOB 2 on the PRESETS page. A sound outside the new category: the first one in it is loaded */
static void preset_go(uint32_t n);
static void preset_cat_turn(int32_t dir)
{
    uint32_t total, cur = preset_pos(&total);
    ui.pcat = (uint8_t)((ui.pcat + (dir > 0 ? 1u : PC_COUNT - 1u)) % PC_COUNT);
    if (total && !preset_in(cur))
        preset_go(preset_step(cur, 1));
    ui_say("CAT ", PC_NAMES[ui.pcat]);
    ui.force = 1;
}
static uint32_t preset_cat_rank(uint32_t cur, uint32_t *count)   /* cur's place among those shown, and how many */
{
    uint32_t total, n, r = 0;
    preset_pos(&total);
    *count = 0;
    for (n = 0; n < total; n++)
        if (preset_in(n)) {
            r += n < cur;
            ++*count;
        }
    return r;
}

static void preset_go(uint32_t n)                    /* load list index n into the selected track */
{
    uint32_t k, e = preset_at(n, &k);
    if (is_drum(TSEL))
        return;                                      /* one GM kit: nothing to browse */
    if (e == NENGINES) {
        up_load(k);
        return;
    }
    if (e == PRESET_FM6) {                           /* an FM6 bank voice: the engine's first preset, then PTCH */
        if (TSEL->eng_req != ENGI_FM6)
            select_engine(ENGI_FM6);
        else
            apply_preset(0);                         /* (the rest of the sound as any preset sets it) */
        fm1_irq_off();
        TSEL->p[P_E7] = (int16_t)(FM6_NFACTORY + k);
        fm1_irq_on();
        fm6_load_slot(song.sel, FM6_NFACTORY + k);   /* (now: also a slot the track had loaded before) */
        ui.force = 1;
        return;
    }
    if (e != TSEL->eng_req)
        select_engine(e);
    apply_preset(k);
    ui.force = 1;
}

/* MIDI Program Change (Jangada 0.9.7, after Felucca 1.5.1 and renebohne's PR #179 there): program n on a track's
 * channel loads its engine's sound n as PRESETS lists them (the engine never changes; FM6: then the bank voices
 * that hold one, B1..B64 in order); the drum track: the kit n in the browser's order. A number past the last is
 * ignored, never wrapped, so a number is always the same sound. In the main loop (seq.c only marks it) */
static void pc_service(void)
{
    uint32_t i;
    static uint8_t cnt_shown;
    if (cnt.left != cnt_shown) {                     /* the count-in counting down (seq.c) */
        char b[12] = "COUNT-IN ";
        cnt_shown = cnt.left;
        if (cnt_shown) {
            fmt_int(b + 9, (cnt_shown - 1u) % 4u + 1u);
            ui_message(b);
        }
    }
    for (i = 0; i < NTRK; i++) {
        track_t *t = &trk[i];
        const engine_t *e = ENGINES[t->eng_req % NENGINES];
        uint32_t n = pc_req[i];
        char b[16];
        if (!n)
            continue;
        pc_req[i] = 0;
        n--;
        if (is_drum(t)) {
            if (n >= DRUM_KITS)
                continue;
            drum_kit_set(DS_KIT_NAV[n]);
        } else if (n < e->npresets) {
            apply_preset_to(t, n);
        } else if (t->eng_req == ENGI_FM6 && n - e->npresets < fm6_list_count()) {
            uint32_t k = fm6_list_nth(n - e->npresets);
            apply_preset_to(t, 0);
            fm1_irq_off();
            t->p[P_E7] = (int16_t)(FM6_NFACTORY + k);
            fm1_irq_on();
            fm6_load_slot(i, FM6_NFACTORY + k);
        } else {
            continue;
        }
        b[0] = 'T';
        b[1] = (char)('1' + i);
        b[2] = ' ';
        b[3] = 'P';
        b[4] = 'C';
        b[5] = ' ';
        fmt_int(b + 6, (int32_t)n);
        ui_message(b);
        ui.force = 1;
    }
}

/* Jangada 0.6: an FM6 track on a bank voice (PTCH B1..B64, as the PRESETS list loads one) is named by its patch,
 * not by the preset it started from: the name -> b (11 bytes or more), 1; 0 = not one */
static int fm6_bank_sound(const track_t *t, char *b)
{
    uint32_t tr = (uint32_t)(t - trk);
    if (tr >= NTRK || is_drum(t) || t->eng_req != ENGI_FM6 || user_of(t) < UP_SLOTS ||
        t->p[P_E7] < (int16_t)FM6_NFACTORY)
        return 0;
    fm6_name(b, fm6_patch[tr]);
    return 1;
}

/* HOME: what KNOB k edits: the engine's four main parameters; on the drum track
 * LEVEL and REV (GLO > DRUMS), PAN and LEN */
static const param_desc_t *home_param(uint32_t k, int16_t **vp)
{
    static const uint8_t DRUM_HOME[4][2] = {{1, G_DRLVL}, {1, G_DRREV}, {0, P_PAN}, {0, P_SLEN}};
    uint32_t id;
    if (is_drum(TSEL)) {
        id = DRUM_HOME[k & 3u][1];
        if (DRUM_HOME[k & 3u][0]) {
            *vp = &song.g[id];
            return &GP[id];
        }
        *vp = &TSEL->p[id];
        return &TP[id];
    }
    id = ENGINES[TSEL->eng_req % NENGINES]->macro[k & 3u];
    *vp = &TSEL->p[id];
    return track_desc(TSEL, id);
}

/* select track i (KNOB 1 on TRACKS, the editor): its sound, pages and pattern from now on */
static void track_select(uint32_t i)
{
    if (i >= NTRK || i == song.sel)
        return;
    song.sel = (uint8_t)i;
    ui.entry_open = 0;
    ui.cursor = 0;
    ui.bank = 0;
    sync_reload = 1;
    ui.force = 1;
}

#include "midi_learn.c"     /* Jangada 0.9: MIDI LEARN (after Felucca 1.5), its UI side */
