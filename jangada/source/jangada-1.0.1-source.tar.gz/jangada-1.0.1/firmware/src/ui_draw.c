/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Felucca UI drawing: status bar (top), columns + gauges, graphs, focus readout,
 * footer (steps + engine / preset / page). */
static void draw_menu(void);
static uint32_t str_hash(uint32_t h, const char *s);

/* --------------------------------------------------------- drawing --- */
static int is_eng_name(const char *s)                 /* one of the ENGINES[]->name strings */
{
    uint32_t e;
    for (e = 0; e < NENGINES; e++)
        if (s == ENGINES[e]->name)
            return 1;
    return 0;
}

/* host tests hook in here (tests/layers_test.c: no label, value or unit is cut); nothing in the firmware */
#ifndef UI_HOOK_CUT
#define UI_HOOK_CUT(src, maxw) ((void)0)
#endif
/* at most 5 characters, and no wider than maxw */
static void fit(char *d, const char *src, const felucca_font_t *f, int32_t maxw)
{
    str_cpy(d, src, is_eng_name(src) ? 8 : 6);           /* engine names are kept whole */
    while (d[0] && text_w(f, d) > maxw) {
        UI_HOOK_CUT(src, maxw);
        d[str_len(d) - 1u] = 0;
    }
}

static int32_t batt_level(void)                         /* ADC ch3 thresholds */
{
    return song.batt_raw >= 591 ? 3 : song.batt_raw >= 561 ? 2 : song.batt_raw >= 531 ? 1 : 0;
}
/* charging (a USB host powers us; there is no charger status line): bars fill 1, 2, 3
 * every 0.6 s, so the header is redrawn twice a second at most; else the level */
static int32_t batt_shown(void)
{
    if (usb.config && !usb.suspended)
        return 1 + (int32_t)((fm1_ms / 600u) % 3u);
    return batt_level();
}

/* top bar: transport, BPM, octave | USB, battery, CPU; messages replace it */
static void draw_head(void)
{
    char b[16];
    uint32_t i;
    int32_t x;
    uint32_t rec = (song.rec >> song.sel) & 1u ? 2u : song.rec != 0u;   /* 2 the selected track armed, 1 another */
    uint32_t sig = (uint32_t)song.playing * 3u + rec * 5u + (uint32_t)(song.octave + 8) * 11u + song.sel * 13131u +
                   (ui.msg_t ? str_hash(7u, ui.msg) : 0u) + (uint32_t)song.g[G_BPM] * 101u + (ui.bpm_t != 0) * 31u +
                   (uint32_t)batt_shown() * 7777u + (usb.config && !usb.suspended) * 99991u;
    if (!ui.force && sig == ui.head_sig)
        return;
    ui.head_sig = sig;
    cv_begin(240, H_HEAD, C_BG);
    if (ui.msg_t) {
        cv_text(4, 1, &FONT_S, ui.msg, C_HI);
        cv_blit(0, Y_HEAD);
        return;
    }
    if (song.playing) {                               /* > play, square stop */
        for (i = 0; i < 5u; i++)
            cv_rect(4 + (int32_t)i * 2, 4 + (int32_t)i, 2, 10 - 2 * (int32_t)i, C_WHITE);
    } else {
        cv_rect(4, 5, 8, 8, C_HI);
    }
    if (rec)                                          /* recording armed: white = this track, gray = another */
        cv_rect(18, 6, 6, 6, rec == 2u ? C_WHITE : C_GRAY);
    fmt_int(b, song.g[G_BPM]);
    x = 32;
    if (FELUCCA_ICONS) {                              /* metronome, then the BPM */
        cv_icon(x, 2, ICON_TEMPO, C_GRAY);
        x += 14;
    }
    x = cv_text(x, 1, &FONT_S, b, ui.bpm_t ? C_WHITE : C_HI);   /* white while SELECT turns it */
    if (song.octave) {
        str_cpy(b, song.octave > 0 ? "+" : "", 4);
        fmt_int(b + str_len(b), song.octave);
        cv_text(x + 12, 1, &FONT_S, "OCT", C_GRAY);
        cv_text(x + 40, 1, &FONT_S, b, C_HI);
    }
    if (FELUCCA_ICONS) {                              /* the selected track: tape + number */
        cv_icon(156, 2, ICON_TAPE, C_GRAY);
        b[0] = (char)('1' + song.sel);
        b[1] = 0;
        cv_text(170, 1, &FONT_S, b, C_HI);
    } else {
        b[0] = 'T';
        b[1] = (char)('1' + song.sel);
        b[2] = 0;
        cv_text(158, 1, &FONT_S, b, C_HI);
    }
    {   /* battery, 3 bars; USB when a host is there */
        int32_t lvl = batt_shown(), k;
        int32_t bx = 236 - 19;                          /* right edge (the CPU figure is in the console) */
        cv_rect(bx, 4, 17, 1, C_GRAY);
        cv_rect(bx, 12, 17, 1, C_GRAY);
        cv_rect(bx, 4, 1, 9, C_GRAY);
        cv_rect(bx + 16, 4, 1, 9, C_GRAY);
        cv_rect(bx + 17, 6, 2, 5, C_GRAY);
        for (k = 0; k < lvl; k++)
            cv_rect(bx + 2 + k * 5, 6, 3, 5, lvl == 1 && batt_level() <= 1 ? C_WHITE : C_HI);
        if (usb.config && !usb.suspended)
            cv_text(bx - 28, 1, &FONT_S, "USB", C_DIM);
    }
    cv_blit(0, Y_HEAD);
}
/* full redraw: the strips (head, columns, graph, foot) cover the rest, so only
 * the space between them is cleared (Jangada: cards, no rules) */
static void draw_frame(void)
{
    lcd_fill(0, H_HEAD, 240, COL_Y - H_HEAD, C_BG);
    lcd_fill(0, COL_Y + COL_H, 240, Y_GRAPH - COL_Y - COL_H, C_BG);
    lcd_fill(0, Y_GRAPH + H_GRAPH, 240, Y_FOOT - Y_GRAPH - H_GRAPH, C_BG);
}

/* one column, a card: [icon] LABEL / value unit / gauge, redrawn only when it changed. The value is
 * M (15 px) when it fits with its unit, else S. ratio: 0..1000 for the gauge, -1 = no gauge.
 * icon: ICON_* (icons.c), ICON_AUTO = by label */
#define LABEL_X (FELUCCA_ICONS ? ICON_CELL + ICON_GAP : 0)
#define COL_X 4                                         /* the card's content: x 4 .. 55 */
#define COL_IN 52
static void big_one(uint32_t c, int32_t cx, int32_t cy, int32_t R, int with_value);
static void draw_column(uint32_t c, const char *label, const char *val, const char *unit, uint16_t vc,
                        int32_t ratio, uint32_t icon)
{
    char l[8], v[10], u[8], key[32];
    const felucca_font_t *vf;
    int32_t x, gw = COL_IN, fx;
    if (icon == ICON_AUTO)
        icon = icon_for_label(label);
    if (c < 4u) {                                       /* (the big values' circles, graph_big) */
        ui.big_r[c] = (int16_t)ratio;
        ui.big_i[c] = (uint8_t)icon;
    }
    if (str_eq(unit, label))
        unit = "";                                      /* BPM 120 BPM, USB MIDI USB: once is enough */
    str_cpy(l, label, 6);
    if (icon != ICON_NONE && text_w(&FONT_S, l) > COL_IN - LABEL_X)
        icon = ICON_NONE;                               /* a long label takes the icon's room */
    fit(l, label, &FONT_S, COL_IN - (icon != ICON_NONE ? LABEL_X : 0));
    fit(v, val, &FONT_S, COL_IN);                       /* (engine names whole) */
    vf = text_w(&FONT_M, v) + (unit[0] ? 2 + text_w(&FONT_S, unit) : 0) <= COL_IN ? &FONT_M : &FONT_S;
    fit(u, unit, &FONT_S, COL_IN - text_w(vf, v) - 2);
    if (c < 4u) {                                       /* (the big values, graph_big: whole, their own font) */
        str_cpy(ui.big_l[c], l, 8);
        str_cpy(ui.big_v[c], val, 12);
        str_cpy(ui.big_u[c], unit, 8);
        ui.big_c[c] = vc;
    }
    str_cpy(key, l, 8);                                 /* cache key: texts + colour + gauge */
    str_cpy(key + str_len(key), "|", 2);
    str_cpy(key + str_len(key), v, 8);
    str_cpy(key + str_len(key), "|", 2);
    str_cpy(key + str_len(key), u, 8);
    {
        uint32_t n = str_len(key);
        key[n] = (char)('A' + (vc == C_WHITE) + (vc == C_DIM) * 2);
        key[n + 1] = (char)(' ' + (ratio < 0 ? 0 : 1 + ratio / 20));
        key[n + 2] = (char)(icon == ICON_NONE ? '~' : '!' + icon % 90u);   /* same label, other icon */
        key[n + 3] = (char)('0' + ui.ev_cols);
        key[n + 4] = 0;
    }
    if (!ui.force && str_eq(key, ui.col[c]))
        return;
    str_cpy(ui.col[c], key, sizeof ui.col[c]);
    cv_begin(60, COL_H, C_BG);
    if (ui.ev_cols) {                                   /* (issue #5) no card: the knob's circle, its name under it */
        big_one(c, 30, 17, 12, 2);
        cv_blit(c * 60u, COL_Y);
        return;
    }
    if (l[0] || v[0])
        cv_card(2, 1, 56, COL_H - 2);                   /* screen rows 22 .. 71 */
    if (FELUCCA_ICONS && icon != ICON_NONE && l[0])
        cv_icon(COL_X, Y_LABEL - COL_Y + 2, icon, C_GRAY);   /* icon rows = the label's cap height */
    cv_text(COL_X + (l[0] && icon != ICON_NONE ? LABEL_X : 0), Y_LABEL - COL_Y, &FONT_S, l, C_GRAY);
    x = cv_text(COL_X, Y_VALUE - COL_Y, vf, v, vc);
    cv_text(x + 2, Y_VALUE - COL_Y, &FONT_S, u, C_DIM);
    if (ratio >= 0) {                                   /* gauge: track, fill, 1 px end line */
        int32_t gy = Y_GAUGE - COL_Y - 2;
        fx = ratio * (gw - 1) / 1000;
        cv_rect(COL_X, gy, gw, 3, C_RAISE);
        cv_rect(COL_X, gy, fx, 3, C_DIM);
        cv_rect(COL_X + fx, gy - 1, 1, 5, vc == C_WHITE ? C_WHITE : C_HI);
    }
    cv_blit(c * 60u, COL_Y);
}

/* Matches voice.c: attack is linear, decay and release are exponential
 * (env += (target - env) * k each tick, ~99 % after the set time). Time
 * axis is the parameter value (the times themselves are exponential).
 * Jangada 0.9.8 (issue #6): with the knobs in a row on top (ui.ev_cols) the whole strip, the shape
 * filled, and a dot where the loudest voice of the track is on it. */
static void graph_adsr(const track_t *t, uint16_t c)
{
    int32_t a = 4 + t->p[P_ATK] * 50 / 127, d = 6 + t->p[P_DEC] * 50 / 127, r = 6 + t->p[P_REL] * 60 / 127;
    int32_t top = ui.ev_cols ? 14 : 8, bot = ui.ev_cols ? 108 : 90, sus = t->p[P_SUS] * 1000 / 127;   /* 0..1000 */
    int32_t x0 = 6, x1 = x0 + a, x2 = x1 + d, x3 = 232 - r, x, px = x0, py = bot, lvl = 0, best = -1, bs = 0;
    int32_t e = 32768;                                                  /* exp(-4.6 u), Q15 */
    uint16_t fill = mix565(c, C_BG, 78);
    uint32_t i;
#define EGY(l) (bot - (l) * (bot - top) / 1000)
    for (x = x0; x <= 232; x++) {
        if (x <= x1)                                                    /* attack: linear */
            lvl = (x - x0) * 1000 / a;
        else if (x <= x2) {                                             /* decay: exponential to SUS */
            e = (e * (32768 - 150733 / d)) >> 15;                       /* k^d = exp(-4.6) */
            lvl = sus + ((1000 - sus) * e >> 15);
        } else if (x <= x3) {                                           /* sustain */
            lvl = sus;
            e = 32768;
        } else {                                                        /* release: exponential to 0 */
            e = (e * (32768 - 150733 / r)) >> 15;
            lvl = sus * e >> 15;
        }
        if (ui.ev_cols && EGY(lvl) < bot)
            cv_rect(x, EGY(lvl), 1, bot - EGY(lvl), fill);
        cv_line(px, py, x, EGY(lvl), c);
        px = x;
        py = EGY(lvl);
    }
    cv_line(0, bot + 1, 239, bot + 1, C_LINE);
    for (i = 0; i < NVOICE && ui.ev_cols; i++)                          /* the loudest voice sounding */
        if (t->v[i].active && t->v[i].stage && t->v[i].env > best) {
            best = t->v[i].env;
            bs = t->v[i].stage;
        }
    if (best >= 0) {
        lvl = clamp(best >> 14, 0, 1000);                               /* Q24 -> 0..1000 */
        x = bs == 1 ? x0 + a * lvl / 1000
          : bs == 3 ? x3 + r * clamp(sus - lvl, 0, sus) / (sus | 1)
          : lvl > sus + 8 ? x1 + d * (1000 - lvl) / (1000 - sus + 1) : (x2 + x3) / 2;
        cv_rect(x, top, 1, bot - top, mix565(c, C_BG, 60));
        cv_disc(x * 16, EGY(lvl) * 16, 56, C_WHITE);
    }
#undef EGY
}

/* the LFO: two cycles from its PHS; with the knobs in a row on top, the whole strip and a dot at the
 * phase it is at (Jangada 0.9.8) */
static void graph_lfo(const track_t *t, uint16_t c)
{
    int32_t x, yc = ui.ev_cols ? 62 : 50, amp = ui.ev_cols ? 46 : 38, py = yc;
    uint32_t ph = (uint32_t)t->p[P_LPHASE] << 25;
    for (x = 0; x < 240; x++) {                      /* (lfo_wave only reads the track) */
        int32_t y = yc - lfo_wave((track_t *)t, ph + (uint32_t)x * (0xFFFFFFFFu / 120u)) * amp / 32768;
        if (t->p[P_LWAVE] == 4)
            y = yc - ((int32_t)((x / 20 * 2654435761u) >> 16) - 32768) * amp / 32768;
        if (x)
            cv_line(x - 1, py, x, y, c);
        py = y;
    }
    cv_line(0, yc, 239, yc, C_LINE);
    if (ui.ev_cols) {
        int32_t y = t->p[P_LWAVE] == 4 ? yc - t->lfo_val * amp / 32768 : yc - lfo_wave((track_t *)t, t->lfo_ph) * amp / 32768;
        x = (int32_t)((t->lfo_ph - ph) / (0xFFFFFFFFu / 120u));
        cv_disc(x * 16, y * 16, 56, C_WHITE);
        cv_disc((x + 120) * 16, y * 16, 40, mix565(C_WHITE, C_BG, 40));
    }
}

/* MOD 1..4 (Jangada 0.9.8, issue #6): SRC -> DST -> SOUND, the amount as a bar from the middle, and
 * the source's shape under it, as tall as the amount (upside down when it is negative) */
static int32_t mod_shape(const track_t *t, uint32_t src, int32_t x)   /* x 0..223 -> Q15 */
{
    switch (src) {
    case 1:                                          /* LFO: two cycles */
        return lfo_wave((track_t *)t, ((uint32_t)t->p[P_LPHASE] << 25) + (uint32_t)x * (0xFFFFFFFFu / 112u));
    case 2: {                                        /* ENV: rise, fall to SUS, hold, let go */
        int32_t a = 8 + t->p[P_ATK] / 3, d = 10 + t->p[P_DEC] / 3, r = 10 + t->p[P_REL] / 2, s = t->p[P_SUS] * 258;
        return x < a ? x * 32767 / a : x < a + d ? 32767 - (32767 - s) * (x - a) / d : x < 223 - r ? s : s * (223 - x) / r;
    }
    case 5:                                          /* RND: a new value a note */
        return (int32_t)(((uint32_t)(x / 28 + 1) * 2654435761u) >> 16) - 32768;
    case 9:                                          /* DRIFT: slow, wandering */
        return (sine_i((uint32_t)x * 19173961u) >> 1) + (sine_i((uint32_t)x * 47934903u + 0x40000000u) >> 2);
    case 10: case 11: case 12: case 13:              /* MAC1..4: where the macro is */
        return song.g[G_MAC1 + src - 10u] * 258;
    default:                                         /* VEL KEY MODW AT EXPR: over their range */
        return src ? x * 32767 / 223 : 0;
    }
}
static void graph_mod(const track_t *t, uint16_t c)
{
    const page_t *pg = cur_page();
    uint32_t src = (uint32_t)t->p[pg->id[0]], i;
    int32_t amt = t->p[pg->id[2]], on = src && amt, x, py = 0, yc = 88, h;
    uint16_t col = on ? c : C_DIM;
    for (i = 0; i < 3u; i++) {                       /* SRC -> DST -> SOUND */
        char v[12];
        const char *u, *s = v;
        int32_t bx = 4 + (int32_t)i * 80;
        if (i < 2u) {                                /* as the knobs name them (DST: the engine's own) */
            int16_t *vp;
            const param_desc_t *pd = page_desc(pg, i, &vp);
            param_format(pd, *vp, v, &u);
        } else
            s = "SOUND";
        cv_card(bx, 4, 72, 30);
        cv_text(bx + 36 - text_w(&FONT_S, s) / 2, 12, &FONT_S, s, i < 2u ? col : C_GRAY);
        if (i < 2u) {                                /* the arrow */
            cv_line(bx + 73, 19, bx + 79, 19, col);
            cv_line(bx + 76, 16, bx + 79, 19, col);
            cv_line(bx + 76, 22, bx + 79, 19, col);
        }
    }
    cv_rect(8, 44, 224, 3, C_RAISE);                 /* AMT from the middle */
    cv_rect(amt < 0 ? 120 + amt * 112 / 64 : 120, 44, amt < 0 ? -amt * 112 / 64 : amt * 112 / 63, 3, col);
    cv_rect(120, 42, 1, 7, C_GRAY);
    h = 2 + (amt < 0 ? -amt : amt) * 26 / 64;
    cv_line(8, yc, 231, yc, C_LINE);
    for (x = 0; x < 224; x++) {
        int32_t y = yc - mod_shape(t, src, x) * h / 32768 * (amt < 0 ? -1 : 1);
        if (x)
            cv_line(7 + x, py, 8 + x, y, col);
        py = y;
    }
    if (src == 1u && on) {                           /* the LFO: where it is */
        uint32_t d = t->lfo_ph - ((uint32_t)t->p[P_LPHASE] << 25);
        x = (int32_t)(d / (0xFFFFFFFFu / 112u));
        cv_disc((8 + x) * 16, (yc - lfo_wave((track_t *)t, t->lfo_ph) * h / 32768 * (amt < 0 ? -1 : 1)) * 16, 48, C_WHITE);
    }
}

static void graph_steps(const track_t *t, uint16_t c)
{
    uint32_t i, len = (uint32_t)t->p[P_SLEN];
    for (i = 0; i < NSTEP; i++) {                    /* 4 rows of 16 thin bars */
        int32_t x = 6 + (int32_t)(i % 16u) * 14 + (int32_t)(i % 16u) / 4 * 4, y = 6 + (int32_t)(i / 16u) * 24;
        const step_t *st = &t->step[i];
        if (i >= len)
            continue;
        if (step_on(st))
            cv_rect(x, y, 1, 14, c);
        else if (st->time == ST_TIE)
            cv_rect(x, y + 6, 1, 8, C_DIM);
        else
            cv_rect(x, y + 13, 1, 1, C_DIM);
        if (st->flags & SF_ACCENT)
            cv_rect(x - 1, y - 2, 3, 1, c);
        if ((song.playing && i == t->seq_idx) || i == ui.cursor)
            cv_rect(x - 1, y + 16, 3, 3, C_WHITE);
    }
}
/* STEP page: the cursor's 16-step bank as a little piano roll */
static void graph_roll(const track_t *t, uint16_t c)
{
    uint32_t i, j, len = (uint32_t)t->p[P_SLEN], base = ui.bank * 16u;
    int32_t lo = 127, hi = 0, prev_y = -1;
    for (i = 0; i < len; i++)
        for (j = 0; j < t->step[i].n; j++) {
            if (t->step[i].note[j] < lo)
                lo = t->step[i].note[j];
            if (t->step[i].note[j] > hi)
                hi = t->step[i].note[j];
        }
    if (lo > hi) {
        lo = 48;
        hi = 72;
    }
    if (hi - lo < 12)
        hi = lo + 12;
    for (i = 0; i < 16u; i++) {
        uint32_t si = base + i;
        const step_t *st = &t->step[si];
        int32_t x = (int32_t)i * 15, yb = 86;
        if (si >= len)
            break;
        if (si == ui.cursor)
            cv_rect(x + 5, 92, 3, 3, C_WHITE);
        if (song.playing && si == t->seq_idx)
            cv_rect(x + 1, 97, 12, 1, C_WHITE);
        if (st->time == ST_TIE && prev_y >= 0) {
            cv_rect(x, prev_y, 14, 1, C_GRAY);
            continue;
        }
        if (!step_on(st)) {
            cv_rect(x + 6, yb, 2, 1, C_DIM);
            prev_y = -1;
            continue;
        }
        for (j = 0; j < st->n; j++) {
            int32_t y = 80 - (st->note[j] - lo) * 74 / (hi - lo);
            cv_rect(x + 2, y, 10, 1, (st->flags & SF_ACCENT) ? C_WHITE : c);
            if (j == 0)
                prev_y = y;
        }
        if (st->flags & SF_SLIDE)
            cv_line(x + 11, prev_y, x + 17, prev_y + 2, c);
    }
}
static void graph_scale(const track_t *t, uint16_t c)
{
    static const uint8_t BLACK[12] = {0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 1, 0};
    uint32_t i, mask = scale_mask(t);
    for (i = 0; i < 12u; i++) {
        uint32_t deg = (i + 12u - (uint32_t)t->p[P_ROOT]) % 12u;
        int32_t x = 6 + (int32_t)i * 19;
        uint16_t col = (mask >> deg) & 1u ? (deg == 0u ? C_WHITE : c) : C_DIM;
        cv_rect(x, BLACK[i] ? 10 : 40, 16, 1, col);
        cv_rect(x + 7, BLACK[i] ? 10 : 40, 1, 40, col);
    }
}

static void graph_fx(const track_t *t, uint16_t c)
{
    uint32_t i;
    for (i = 0; i < 4u; i++) {
        int32_t h = t->p[P_DIST + i] * 80 / 127, x = (int32_t)i * 60 + 28;
        cv_rect(x, 10, 1, 80, C_LINE);
        cv_rect(x, 90 - h, 1, h, c);
        cv_rect(x - 3, 90 - h, 7, 1, c);
    }
}
/* SLICER page: the pattern's 16 steps, a 'x' step a full bar; a '.' step: GATE a bar as high as
 * it stays open (DEPTH), STUT hatched (it repeats the last 'x'); the step playing underlined.
 * Grey when the SLICER is OFF. */
static void graph_slicer(const track_t *t, uint16_t c)
{
    uint32_t i, pat = sl_pattern(t), mode = (uint32_t)t->p[P_SLCR], cur = sl[t - trk].idx;
    int32_t open = 70 - t->p[P_SLDEPTH] * 70 / 127;      /* px a closed GATE step keeps */
    uint16_t col = mode == SL_OFF ? C_DIM : c;
    for (i = 0; i < 16u; i++) {
        int32_t x = 4 + (int32_t)i * 14 + (int32_t)(i / 4u) * 2, y;
        if ((pat >> i) & 1u) {
            cv_rect(x, 10, 11, 70, col);
        } else if (mode == SL_STUT) {
            for (y = 10; y < 80; y += 4)
                cv_rect(x, y, 11, 1, col);
        } else {
            cv_rect(x, 79, 11, 1, C_LINE);
            if (open)
                cv_rect(x, 80 - open, 11, open, C_DIM);
        }
        if (mode != SL_OFF && i == cur)
            cv_rect(x, 85, 11, 3, C_WHITE);
    }
}
/* Jangada DRONES page (drone.c): the four walks as threads that drift up and down (grey while the part is
 * silent or EVOL and TENS are 0), and the tension: the bar is where it is now, the white mark where TENS
 * takes it (a RAMP: the bar travels there over the bars) */
static void graph_drone(const track_t *t, uint16_t c)
{
    const drone_t *d = &drn[(uint32_t)(t - trk) % NTRK];
    int32_t i, now = d->tens >> 16, goal = t->p[P_TENS] * 258, w = now * 96 / 32767, g = goal * 96 / 32767;
    uint16_t col = d->on ? c : C_DIM;
    char b[8];
    for (i = 0; i < DR_NW; i++) {
        int32_t x = 14 + i * 26, y = 50 - (d->on ? d->w[i] : 0) * 36 / 32767;
        cv_rect(x + 3, 12, 1, 76, C_LINE);
        cv_rect(x, y - 2, 7, 4, col);
    }
    cv_text(124, 10, &FONT_S, "TENSION", C_GRAY);
    cv_rect(124, 40, 96, 14, C_RAISE);
    if (w)
        cv_rect(124, 40, w, 14, d->on ? c : C_DIM);
    cv_rect(124 + (g > 95 ? 95 : g), 36, 2, 22, C_WHITE);
    fmt_int(b, (now * 100 + 16383) / 32767);
    i = cv_text(124, 64, &FONT_S, b, C_HI);
    cv_text(i + 2, 64, &FONT_S, "%", C_DIM);
    if (t->p[P_TRAMP])
        cv_text(170, 64, &FONT_S, N_TRAMP[(uint32_t)t->p[P_TRAMP] % 7u], C_AMB);
}
/* Jangada 0.9.7 VIVO (issue #4): the pattern as a ring, step 1 at the top. Outside, the rhythm VIVO plays from
 * (Euclid's hits, the rule's cells, or the note steps); inside, what played in the last pass, an accent white;
 * the step playing ringed */
static void graph_vivo(const track_t *t, uint16_t c)
{
    uint32_t k = song.sel % NTRK, len = t->p[P_SLEN] ? (uint32_t)t->p[P_SLEN] : 1u, i;
    int32_t cx = 120 * 16, cy = 50 * 16, ro = 42 * 16, ri = 29 * 16;
    char b[16];
    for (i = 0; i < len; i++) {
        uint32_t a = i * (0xFFFFFFFFu / len);
        int32_t sx = (sine_i(a) * 16) >> 15, sy = -((sine_i(a + 0x40000000u) * 16) >> 15);
        uint32_t m = t->p[P_VEVOL] && vv[k].born ? vv_bit(vv[k].row, i) : vv_base(t, i, len);
        int32_t dr = len > 32u ? 36 : 54;
        cv_disc(cx + sx * ro / 16, cy + sy * ro / 16, m ? dr : 18, m ? c : C_DIM);
        if (vv_bit(vv[k].hit, i))
            cv_disc(cx + sx * ri / 16, cy + sy * ri / 16, vv_bit(vv[k].acc, i) ? dr : dr - 16,
                    vv_bit(vv[k].acc, i) ? C_WHITE : mix565(c, C_BG, 30));
        if (song.playing && i == t->seq_idx % len)
            cv_ring(cx + sx * ro / 16, cy + sy * ro / 16, dr + 28, 14, C_WHITE);
    }
    if (t->p[P_VEVOL])
        str_cpy(b, N_VRULE[t->p[P_VEVOL] & 7], sizeof b);
    else if (t->p[P_VPULS]) {
        fmt_int(b, t->p[P_VPULS] > (int16_t)len ? (int32_t)len : t->p[P_VPULS]);
        str_cpy(b + str_len(b), "/", 4);
        fmt_int(b + str_len(b), (int32_t)len);
    } else
        str_cpy(b, vv_on(t) ? "STEPS" : "OFF", sizeof b);
    cv_text(120 - text_w(&FONT_M, b) / 2, 41, &FONT_M, b, vv_on(t) ? C_HI : C_DIM);
}

static uint32_t steps_hash(const track_t *t)
{
    uint32_t h = 2166136261u, i;
    for (i = 0; i < NSTEP; i++) {
        const step_t *st = &t->step[i];
        h = (h ^ (st->note[0] + st->n * 128u + st->time * 1024u + st->flags * 4096u + st->note[1] * 65536u)) *
            16777619u;
    }
    return h;
}

static uint32_t str_hash(uint32_t h, const char *s)
{
    while (*s)
        h = (h ^ (uint8_t)*s++) * 16777619u;
    return h;
}

/* Jangada 0.7 (after SLOOP 2.4): a page without a graph shows its values large (graph_big) */
static int big_page(const page_t *pg) { return pg->graph == GR_NONE && pg->scope != SC_STEP && pg->scope != SC_TRK; }
/* the knobs as a row of circles on top, a picture under them: an engine's EDIT pages (0.9.7), ENV, LFO and
 * MOD 1..4 (0.9.8, issue #6); not on the drum track */
static int row_page(const page_t *pg)
{
    return !is_drum(TSEL) && ((pg->scope == SC_ENGINE && big_page(pg)) || pg->graph == GR_ADSR || pg->graph == GR_LFO ||
                              pg->graph == GR_MOD);
}
static uint32_t graph_signature(void)
{
    const page_t *pg = cur_page();
    const track_t *t = TSEL;
    uint32_t h = 2166136261u, i;
    if (ui.home)
        return h ^ (ui.frame / 2u);                  /* scope: redraw every other frame */
    if (row_page(pg))
        h ^= ui.frame / 2u;                          /* Jangada 0.9.7: the engine's picture moves (ui_eng.c); 0.9.8: ENV LFO MOD */
    if (big_page(pg))                                /* the big values: as the columns show them */
        for (i = 0; i < 4u; i++)
            h = str_hash(str_hash(str_hash(h ^ ui.big_c[i] * 31u ^ (uint32_t)ui.big_r[i] * 7919u ^ ui.big_i[i] * 104729u ^ ui.big_k[i] * 15485863u,
                                           ui.big_v[i]), ui.big_l[i]), ui.big_u[i]);
    h ^= (uint32_t)pg->graph * 131u + TSEL->eng_req + song.sel * 7777u;
    for (i = 0; i < P_COUNT; i++)
        h = (h ^ (uint32_t)t->p[i]) * 16777619u;
    h ^= (uint32_t)TSEL->preset * 7u + (uint32_t)song.g[G_SLOT] * 13u + TSEL->user * 257u + up_gen * 7919u + ui.uslot * 104729u;
    if (pg->graph == GR_SLCR && t->p[P_SLCR])        /* the SLICER's step playing */
        h ^= (sl[song.sel].idx + 1u) * 2654435761u;
    if (pg->graph == GR_DRONE) {                     /* Jangada DRONES: the walks and the tension move alone */
        const drone_t *d = &drn[song.sel % NTRK];
        for (i = 0; i < DR_NW; i++)
            h = (h ^ (uint32_t)(d->on ? d->w[i] >> 10 : 0)) * 16777619u;
        h = (h ^ (uint32_t)(d->tens >> 24) ^ (uint32_t)d->on << 16) * 16777619u;
    }
    if (pg->graph == GR_VIVO) {                      /* VIVO: the playhead, the pass, the cells */
        const uint32_t *w = &vv[song.sel % NTRK].row[0];
        h ^= (song.playing ? t->seq_idx + 1u : 0u) * 2654435761u + steps_hash(t);
        h = (h ^ w[0] ^ w[1] * 3u ^ vv[song.sel % NTRK].hit[0] * 5u ^ vv[song.sel % NTRK].hit[1] * 7u ^
             vv[song.sel % NTRK].acc[0] * 11u ^ vv[song.sel % NTRK].born) * 16777619u;
    }
    if (pg->graph == GR_BROWSE)                      /* Jangada 0.6: the FM6 bank voices listed (a write) */
        h ^= (uint32_t)fm6_bank_gen * 2654435761u;
    if (pg->graph == GR_SLOTS)                       /* (a checksum over each slot) */
        for (i = 0; i < 4u; i++)
            h ^= (uint32_t)project_used(i) << (20u + i);
    if (pg->graph == GR_STEPS || pg->graph == GR_ROLL) {
        uint32_t ph = song.playing ? t->seq_idx : 0xFFFFu;
        if (pg->graph == GR_ROLL && ph / 16u != ui.bank)
            ph = 0xFFFFu;                            /* the roll shows the cursor's bank only */
        h ^= steps_hash(t) + ph * 31u + ui.cursor * 7919u;
    }
    return h;
}
/* preset browser: the global list (every engine, the FM6 bank voices, the user presets), current one in white */
static void graph_browse(void)
{
    uint32_t total, cur = preset_pos(&total), e, k;
    int32_t row;
    if (!total)
        return;
    for (row = -3; row <= 3; row++) {
        int32_t y = 4 + (row + 3) * 17;
        char tag[4], nm[13];
        int sel = row == 0;
        e = preset_at((cur + total * 4u + (uint32_t)row) % total, &k);
        if (e == NENGINES) {                             /* user preset: "U07" and its name */
            up_slot_label(tag, k);
            up_name(k, nm);
        } else if (e == PRESET_FM6) {                    /* Jangada 0.6: an FM6 bank voice: its bank, its name */
            str_cpy(tag, k < FM6_BANK_VOICES ? "BK1" : "BK2", sizeof tag);
            str_cpy(nm, fm6_bank_nm[k % FM6_BANK_N], sizeof nm);
        } else {
            str_cpy(tag, ENGINES[e]->name, sizeof tag);
            str_cpy(nm, ENGINES[e]->presets[k].name, sizeof nm);
        }
        if (sel)
            cv_rrect(6, y - 1, 228, 17, 4, C_SEL, C_SURF);
        cv_text(14, y, &FONT_S, tag, sel ? C_HI : C_DIM);
        cv_text(54, y, &FONT_S, nm, sel ? C_WHITE : C_GRAY);
    }
}

/* user preset slots around the selected one: "U07  NAME" / EMPTY, the selected one in white */
static void graph_user(void)
{
    int32_t row, first = clamp((int32_t)ui.uslot - 3, 0, UP_SLOTS - 7);
    for (row = 0; row < 7; row++) {
        uint32_t k = (uint32_t)(first + row);
        int32_t y = 4 + row * 17;
        char tag[4], nm[13];
        int sel = k == ui.uslot, used = up_used(k);
        up_slot_label(tag, k);
        if (used)
            up_name(k, nm);
        else
            str_cpy(nm, "EMPTY", sizeof nm);
        if (sel)
            cv_rrect(6, y - 1, 228, 17, 4, C_SEL, C_SURF);
        cv_text(14, y, &FONT_S, tag, sel ? C_WHITE : C_GRAY);
        cv_text(54, y, &FONT_S, nm, used ? (sel ? C_WHITE : C_HI) : sel ? C_GRAY : C_DIM);
    }
}

/* project slots: used / empty, the selected one in white */
static void graph_slots(void)
{
    uint32_t i;
    for (i = 0; i < 4u; i++) {
        int32_t y = 8 + (int32_t)i * 26;
        char b[4];
        int sel = (int32_t)i + 1 == song.g[G_SLOT];
        b[0] = (char)('1' + i);
        b[1] = 0;
        if (sel)
            cv_rrect(6, y - 2, 228, 20, 4, C_SEL, C_SURF);
        cv_text(14, y, &FONT_S, b, sel ? C_WHITE : C_GRAY);
        cv_text(40, y, &FONT_S, project_used(i) ? "USED" : "EMPTY",
                project_used(i) ? (sel ? C_WHITE : C_HI) : sel ? C_GRAY : C_DIM);
    }
}

/* TRACKS page: four channel strips (mixer style), one under each column: number +
 * REC / ARM / MUTE, the sound's short name, then a level fader with the output meter
 * (note activity), the pattern over its LEN (time running down; bar width = notes in
 * the step) and the play head. The selected track is drawn bright. Every part is
 * its own small canvas with its own signature: while the transport runs only the
 * head markers and the meters move. */
#define TS_HEAD_Y (Y_GRAPH + 2)
#define TS_NAME_Y (Y_GRAPH + 20)
#define TS_Y (Y_GRAPH + 38)
#define TS_H 84                                      /* body: rows Y_GRAPH + 38 .. + 121 */
static struct {
    uint32_t head[NTRK], name[NTRK], fader[NTRK], ov[NTRK], mark[NTRK];
    uint8_t meter[NTRK];
} ts;

static int32_t meter_px(int32_t a)                   /* |sample| (Q15) -> px: 6 dB = TS_H / 10 */
{
    int32_t lg = 0, v;
    if (a < 64)
        return 0;
    while ((a >> lg) > 1)
        lg++;
    v = lg * 8 + (((a << 3) >> lg) & 7);             /* 8 log2(a): 48 (-54 dB) .. 128 (+6 dB) */
    return clamp((v - 48) * (TS_H - 2) / 80, 0, TS_H - 2);
}

static uint32_t trk_level(uint32_t c)                /* LEVEL 0..127 (the drum track: GLO > DRUMS LEVEL) */
{
    return (uint32_t)(is_drum(&trk[c]) ? song.g[G_DRLVL] : trk[c].p[P_LEVEL]) & 127u;
}

static void trk_short_name(uint32_t c, char *b)      /* the track's sound, b holds 13 */
{
    const track_t *t = &trk[c];
    const engine_t *e = ENGINES[t->eng_req % NENGINES];
    if (is_drum(&trk[c]))
        str_cpy(b, drum_kit() ? DRUM_KIT_NAMES[drum_kit()] : "DRUM", 13);   /* Jangada: the kit */
    else if (user_of(t) < UP_SLOTS)
        up_name(user_of(t), b);
    else if (fm6_bank_sound(t, b))                   /* Jangada 0.6: an FM6 bank voice */
        ;
    else if (e->npresets)
        str_cpy(b, e->presets[t->preset % e->npresets].name, 13);
    else
        str_cpy(b, e->name, 13);
}

static void draw_tracks(void)
{
    uint32_t c;
    if (ui.force) {
        lcd_fill(0, Y_GRAPH, 240, H_GRAPH, C_BG);
        for (c = 0; c < NTRK; c++)
            ts.meter[c] = 0;
    }
    for (c = 0; c < NTRK; c++) {
        track_t *t = &trk[c];
        uint32_t x0 = c * 60u + 4u, sel = c == song.sel, lvl = trk_level(c), mute = !lvl || t->p[P_MUTE];
        uint32_t arm = (song.rec >> c) & 1u, st = arm ? (song.playing ? 1u : 2u) : mute ? 3u : 0u, sig;
        uint32_t len = t->p[P_SLEN] > 0 ? (uint32_t)t->p[P_SLEN] : 1u, row = 0xFFFFu;
        int32_t pk, m;
        char b[16];
        if (is_drum(&trk[c])) {
            pk = drums.peak;
            drums.peak = 0;
        } else {
            pk = t->peak;
            t->peak = 0;
        }
        /* head: number (white = selected), REC / ARM / MUTE */
        sig = 1u + sel + st * 2u;
        if (ui.force || sig != ts.head[c]) {
            ts.head[c] = sig;
            b[0] = (char)('1' + c);
            b[1] = 0;
            cv_begin(54, 16, C_BG);
            cv_text(0, 0, &FONT_S, b, sel ? C_WHITE : C_GRAY);
            if (sel)
                cv_rect(0, 15, 8, 1, C_WHITE);
            if (st == 1u || st == 2u) {
                cv_rect(14, 5, 6, 6, st == 1u ? C_WHITE : C_AMB);
                cv_text(24, 0, &FONT_S, st == 1u ? "REC" : "ARM", st == 1u ? C_WHITE : C_AMB);
            } else if (st) {
                cv_text(14, 0, &FONT_S, "MUTE", C_DIM);
            }
            cv_blit(x0, TS_HEAD_Y);
        }
        /* the sound: preset name (user preset, DRUM), cut to the column */
        trk_short_name(c, b);
        while (b[0] && text_w(&FONT_S, b) > 54)
            b[str_len(b) - 1u] = 0;
        sig = str_hash(2u + sel, b);
        if (ui.force || sig != ts.name[c]) {
            ts.name[c] = sig;
            cv_begin(54, 16, C_BG);
            cv_text(0, 0, &FONT_S, b, sel ? C_HI : C_DIM);
            cv_blit(x0, TS_NAME_Y);
        }
        /* fader (LEVEL) + meter of the output */
        m = mute ? 0 : meter_px(pk);
        if (m < ts.meter[c] - 3)
            m = ts.meter[c] - 3;                     /* falls ~20 dB/s */
        ts.meter[c] = (uint8_t)(m < 0 ? 0 : m);
        sig = 1u + lvl + ts.meter[c] * 128u + sel * 65536u + (sel && ui.hot_t && ui.hot_col == 1u) * 131072u +
              (t->p[P_MUTE] != 0) * 262144u;
        if (ui.force || sig != ts.fader[c]) {
            int32_t fy = (int32_t)(TS_H - 2u) - (int32_t)lvl * (TS_H - 4) / 127;
            ts.fader[c] = sig;
            cv_begin(12, TS_H, C_BG);
            cv_rect(3, 0, 1, TS_H, C_LINE);
            if (lvl) {
                cv_rect(2, fy, 3, TS_H - fy, C_DIM);
                cv_rect(0, fy - 1, 7, 2, (sig & 131072u) ? C_WHITE : sel ? C_HI : C_GRAY);
            } else {
                cv_rect(0, TS_H - 2, 7, 2, C_DIM);
            }
            if (ts.meter[c])
                cv_rect(9, TS_H - ts.meter[c], 3, ts.meter[c], C_AMB);
            cv_blit(x0, TS_Y);
        }
        /* the pattern: one band per step over LEN, a note step as wide as its notes */
        sig = steps_hash(t) * 31u + len * 7u + sel;
        if (ui.force || sig != ts.ov[c]) {
            uint32_t i;
            ts.ov[c] = sig;
            cv_begin(34, TS_H, C_BG);
            cv_rect(17, 0, 1, TS_H, C_LINE);
            for (i = 0; i < len; i++) {
                const step_t *s = &t->step[i];
                int32_t r0 = (int32_t)(i * TS_H / len), r1 = (int32_t)((i + 1u) * TS_H / len), h = r1 - r0;
                if (h > 2)
                    h--;                             /* a gap between steps when there is room */
                if (h < 1)
                    h = 1;
                if (step_on(s)) {
                    int32_t w = 2 + 6 * (int32_t)s->n;
                    cv_rect(17 - w / 2, r0, w, h, (s->flags & SF_ACCENT) && sel ? C_WHITE : sel ? C_HI : C_GRAY);
                } else if (s->time == ST_TIE) {
                    cv_rect(16, r0, 3, r1 - r0, C_DIM);
                }
            }
            cv_blit(x0 + 14u, TS_Y);
        }
        /* play head: a small arrow right of the pattern (white while recording) */
        if (song.playing)
            row = ((t->seq_idx % len) * 2u + 1u) * TS_H / (2u * len);
        sig = 1u + row + (st == 1u) * 65536u;
        if (ui.force || sig != ts.mark[c]) {
            int32_t i;
            ts.mark[c] = sig;
            cv_begin(5, TS_H, C_BG);
            if (row != 0xFFFFu)
                for (i = -2; i <= 2; i++) {
                    int32_t w = 5 - 2 * (i < 0 ? -i : i);
                    cv_rect(5 - w, (int32_t)row + i, w, 1, st == 1u ? C_WHITE : C_AMB);
                }
            cv_blit(x0 + 49u, TS_Y);
        }
    }
}

/* oscilloscope of the output, triggered on a rising zero crossing */
static void graph_scope(uint16_t c)
{
    static int16_t snap[SCOPE_N];
    uint32_t w = scope_w, i, trig = 0;
    int32_t py = 50, x, peak = 1500;
    for (i = 0; i < SCOPE_N; i++) {
        snap[i] = scope_buf[(w + i) & (SCOPE_N - 1u)];
        if (snap[i] > peak)
            peak = snap[i];
        else if (-snap[i] > peak)
            peak = -snap[i];
    }
    for (i = 1; i < SCOPE_N - 240u; i++)
        if (snap[i - 1] < 0 && snap[i] >= 0) {
            trig = i;
            break;
        }
    cv_line(0, 50, 239, 50, C_LINE);
    for (x = 0; x < 240; x++) {
        int32_t y = 50 - snap[trig + (uint32_t)x] * 44 / peak;   /* auto-scaled */
        if (x)
            cv_line(x - 1, py, x, y, c);
        py = y;
    }
}

/* the big values (Jangada 0.9.4, issue #5): each knob as a circle that grows with its value, its name and value
 * under it, as water and wind would move: the shape follows what the parameter does (big_style). The one turned
 * white, an inactive one dim; a value with no gauge (a list, on / off) in its circle's place */
enum { BS_DISC, BS_RIPPLE, BS_SPIRAL, BS_WAVE, BS_INTERF };
enum { BK_AMOUNT, BK_BIPOLAR, BK_LIST };                /* ui.big_k: 0..max; -max..max (from its middle); a list */
static uint32_t big_style(uint32_t icon)
{
    switch (icon) {
    case ICON_RESO: case ICON_FEEDBACK: case ICON_REVERB: case ICON_DELAY: case ICON_CHORUS: case ICON_DAMP:
    case ICON_DECAY: case ICON_RELEASE: case ICON_SIZE:
        return BS_RIPPLE;                               /* rings spreading: what rings on, echoes, dies away */
    case ICON_RATE: case ICON_TEMPO: case ICON_TIME: case ICON_PHASE: case ICON_SWEEP: case ICON_VIBRATO:
    case ICON_FADE: case ICON_GLIDE: case ICON_DIVISION: case ICON_SWING:
        return BS_SPIRAL;                               /* a spiral unfolding: time, speed, motion */
    case ICON_SHAPE: case ICON_WAVE: case ICON_PULSE: case ICON_FOLD: case ICON_BITS: case ICON_DIST:
    case ICON_DRIVE: case ICON_NOISE: case ICON_GRAIN:
        return BS_WAVE;                                 /* calm to stormy: the shape of the sound */
    case ICON_MOD: case ICON_DETUNE: case ICON_RATIO: case ICON_ALGORITHM: case ICON_PAN:
        return BS_INTERF;                               /* two sources crossing: modulation, detune */
    default:
        return BS_DISC;                                 /* a dot growing into a disc: an amount */
    }
}

static uint32_t isqrt_u(uint32_t x)
{
    uint32_t r = 0, b = 1u << 30;
    while (b > x)
        b >>= 2;
    while (b) {
        if (x >= r + b) {
            x -= r + b;
            r = (r >> 1) + b;
        } else {
            r >>= 1;
        }
        b >>= 2;
    }
    return r;
}

/* one indicator around (cx, cy), radius R, all in 1/16 px; v 0..1000 */
static void big_circle(int32_t cx, int32_t cy, int32_t R, int32_t v, uint32_t style, uint16_t col, int neg)
{
    int32_t i, k, mx = neg ? -1 : 1;                    /* below zero: mirrored (a spiral turns the other way) */
    switch (style) {
    case BS_DISC:                                       /* a dot that grows into the disc */
        k = 24 + (R - 30) * (int32_t)isqrt_u((uint32_t)v * 1000u) / 1000;
        if (neg)
            cv_ring(cx, cy, k - 20, 40, col);           /* below zero: the same size, hollow */
        else
            cv_disc(cx, cy, k, col);
        break;
    case BS_RIPPLE: {                                   /* more rings as it grows, spreading outward */
        int32_t n = 1 + (v * 5 + 500) / 1000, reach = 32 + (R - 40) * v / 1000;
        for (k = 0; k < n; k++)
            cv_ring(cx, cy, reach * (k + 1) / n, k == n - 1 ? 40 : 19,
                    k == n - 1 ? col : mix565(col, C_BG, 35 + 40 * (n - 1 - k) / n));
        cv_disc(cx, cy, 26, col);
        break;
    }
    case BS_SPIRAL: {                                   /* unfolds as it turns; the tip is the value */
        int32_t turns = 150 + 3200 * v / 1000, steps = turns * 300 / 1000 + 2, x = cx, y = cy;   /* turns in 1/1000 */
        for (i = 0; i < steps; i++) {
            int32_t t = turns * i / (steps - 1), r = (R - 40) * t / 3350;
            uint32_t a = (uint32_t)t * 4294967u;        /* 1/1000 turn -> a phase */
            x = cx + mx * ((r * sine_i(a)) >> 15);
            y = cy - ((r * sine_i(a + 0x40000000u)) >> 15);
            cv_disc(x, y, 15, col);
        }
        cv_disc(x, y, 34, C_WHITE);
        break;
    }
    case BS_WAVE: {                                     /* a calm circle that turns stormy */
        int32_t lobes = 3 + (v * 9 + 500) / 1000, amp = R * 28 / 100 * v / 1000, base = R * 62 / 100;
        for (i = 0; i < 480; i++) {
            uint32_t a = (uint32_t)i * 8947849u;        /* 480 steps a turn */
            int32_t w = (sine_i(a * (uint32_t)lobes) * (1000 - v * 4 / 10) +
                         sine_i(a * (uint32_t)(2 * lobes + 1) + 888634858u) * (v * 4 / 10)) / 1000;   /* Q15 */
            int32_t r = base + ((amp * w) >> 15);
            cv_disc(cx + ((r * sine_i(a + 0x40000000u)) >> 15), cy + ((r * sine_i(a)) >> 15), 15, col);
        }
        break;
    }
    default: {                                          /* BS_INTERF: two sources move apart, their rings cross */
        int32_t off = R * 45 / 100 * v / 1000, sx;
        for (sx = -off; sx <= off; sx += 2 * off) {
            for (k = 1; k <= 4; k++)
                cv_ring(cx + sx, cy, (R - (sx < 0 ? -sx : sx) - 32) * k / 4, 19, mix565(col, C_BG, 20 + 15 * k));
            cv_disc(cx + sx, cy, 26, col);
            if (!off)
                break;
        }
        break;
    }
    }
}

#include "ui_eng.c"                                 /* Jangada 0.9.7 (issue #5): the engine's picture */

/* Jangada 0.9.7 (issue #5): a note value as dots, as many as the notes it makes in a bar ("1/8": eight, "8T":
 * twelve, a dotted one with a dot in the middle); longer than a bar, a share of the disc ("2BAR": half of it).
 * 0 = not a note value */
static int32_t frac_notes(const char *v, int *dotted)
{
    int32_t n = 0;
    const char *p = v;
    *dotted = 0;
    if (p[0] == '1' && p[1] == '/')
        p += 2;
    while (*p >= '0' && *p <= '9')
        n = n * 10 + *p++ - '0';
    if (!n || n > 64)
        return 0;
    if (*p == 'B' && p[1] == 'A' && p[2] == 'R' && !p[3])
        return -n;                                      /* bars */
    if (v[0] == '1' && v[1] == '/') {
        if (*p == 'D' && !p[1])
            *dotted = 1;
        else if (*p == 'T' && !p[1])
            n = n * 3 / 2;
        else if (*p)
            return 0;
        return n;
    }
    return *p == 'T' && !p[1] ? n * 3 / 2 : 0;          /* "8T" */
}
static void frac_draw(int32_t cx, int32_t cy, int32_t R, int32_t n, int dotted, uint16_t col)
{
    int32_t i;
    if (n == 1) {
        cv_disc(cx, cy, R * 62 / 100, col);
    } else if (n < 0) {                                 /* a share of the disc: 1 / bars of it */
        int32_t k, steps = 64 / -n + 1;
        for (k = 0; k < steps; k++) {
            uint32_t a = (uint32_t)k * (0xFFFFFFFFu / (uint32_t)(-n) / (uint32_t)(steps - 1 > 0 ? steps - 1 : 1));
            for (i = 0; i <= R * 62 / 100; i += 12)
                cv_disc(cx + ((i * sine_i(a)) >> 15), cy - ((i * sine_i(a + 0x40000000u)) >> 15), 14, col);
        }
    } else {
        int32_t rr = n <= 4 ? R * 55 / 100 : R * 72 / 100, d = rr * 314 / 100 / n;   /* dots a little apart */
        if (d > R * 26 / 100)
            d = R * 26 / 100;
        if (d < 10)
            d = 10;
        for (i = 0; i < n; i++) {
            uint32_t a = (uint32_t)i * (0xFFFFFFFFu / (uint32_t)n);
            cv_disc(cx + ((rr * sine_i(a)) >> 15), cy - ((rr * sine_i(a + 0x40000000u)) >> 15), d, i ? col : C_WHITE);
        }
    }
    if (dotted)
        cv_disc(cx, cy, R * 16 / 100, C_WHITE);
}

/* one knob's circle at (cx, cy) (px), radius R (px); its name under it, and its value when there is room */
static void big_one(uint32_t c, int32_t cx, int32_t cy, int32_t R, int with_value)
{
    int32_t uw, w, x, fn, dotted;
    const felucca_font_t *f = &FONT_M;
    uint16_t vc = ui.big_c[c] == C_WHITE ? C_WHITE : ui.big_c[c] == C_DIM ? C_DIM : C_HI;
    if (!ui.big_l[c][0])
        return;
    uw = ui.big_u[c][0] ? text_w(&FONT_S, ui.big_u[c]) + 3 : 0;
    fn = ui.big_k[c] == BK_LIST ? frac_notes(ui.big_v[c], &dotted) : 0;
    if (fn) {
        frac_draw(cx * 16, cy * 16, R * 16, fn, dotted, vc);
    } else if (ui.big_r[c] >= 0 && ui.big_k[c] != BK_LIST) {
        int32_t v = ui.big_r[c] > 1000 ? 1000 : ui.big_r[c], neg = 0;
        if (ui.big_k[c] == BK_BIPOLAR) {                /* its size: how far from zero */
            neg = v < 500;
            v = neg ? (500 - v) * 2 : (v - 500) * 2;
        }
        big_circle(cx * 16, cy * 16, R * 16, v, big_style(ui.big_i[c]), vc, neg);
    } else {                                            /* no gauge: the value large in the circle's place */
        int32_t room = R * 2 + 8;
        const felucca_font_t *g = text_w(&FONT_L, ui.big_v[c]) <= room ? &FONT_L : text_w(&FONT_M, ui.big_v[c]) <= room ? &FONT_M : &FONT_S;
        cv_text(cx - text_w(g, ui.big_v[c]) / 2, cy - (g == &FONT_L ? 15 : 10), g, ui.big_v[c], vc);
    }
    if (with_value == 2) {                              /* the columns' row: while its knob turns, the value in the name's place */
        const char *s = vc == C_WHITE && !fn && ui.big_r[c] >= 0 && ui.big_k[c] != BK_LIST ? ui.big_v[c] : ui.big_l[c];
        cv_text(cx - text_w(&FONT_S, s) / 2, cy + R + 5, &FONT_S, s, s == ui.big_v[c] ? C_WHITE : C_GRAY);
        return;
    }
    cv_text(cx - text_w(&FONT_S, ui.big_l[c]) / 2, cy + R + 6, &FONT_S, ui.big_l[c], C_GRAY);
    if (!with_value || ((ui.big_r[c] < 0 || ui.big_k[c] == BK_LIST) && !fn))
        return;
    if (text_w(f, ui.big_v[c]) + uw > 58)
        f = &FONT_S;
    w = text_w(f, ui.big_v[c]) + (text_w(f, ui.big_v[c]) + uw <= 58 ? uw : 0);
    x = cv_text(cx - w / 2, cy + R + 24, f, ui.big_v[c], vc);
    if (uw && w > text_w(f, ui.big_v[c]))
        cv_text(x + 3, f == &FONT_M ? cy + R + 27 : cy + R + 24, &FONT_S, ui.big_u[c], C_DIM);
}

static void graph_big(void)
{
    uint32_t c;
    if (ui.ev_cols && eng_view())                     /* the engine's picture; its knobs are in the columns' row */
        return;
    for (c = 0; c < 4u; c++)
        big_one(c, 30 + 60 * (int32_t)c, 38, 24, 1);
}

static void draw_graph(void)
{
    const page_t *pg = cur_page();
    const track_t *t = TSEL;
    uint16_t c = ACC;
    uint32_t sig, top, drum_note = !ui.home && is_drum(t) && !page_for_drum(pg), card;
    if (!ui.home && pg->graph == GR_TRK) {
        draw_tracks();
        ui.graph_top = 1;                            /* the next graph draws its top rows again */
        return;
    }
    if (ui.home || pg->scope != SC_ENGINE || pg->graph != GR_NONE)
        an.want = 0;                                 /* no engine picture: fx.c measures nothing (ui_eng.c) */
    sig = graph_signature();
    if (!ui.force && sig == ui.graph_sig)
        return;
    ui.graph_sig = sig;
    cv_begin(240, H_GRAPH, C_BG);
    card = ui.home || drum_note || (pg->graph != GR_NONE && pg->graph != GR_ARP && !(ui.ev_cols && row_page(pg)));   /* (ARP: no graph) */
    if (card)                                        /* the graph's card (rows Y_GRAPH .. + 122) */
        cv_card(2, 0, 236, H_GRAPH - 1);
    cv_clip(4, 2, 236, H_GRAPH - 3);
    cv_oy = G_OY;
    if (ui.home) {
        graph_scope(c);
    } else if (drum_note) {                          /* a page the drum track has no use for */
        static const char *const L[2] = {"DRUM TRACK", "SEQ  TRACKS  GLO DRUMS"};
        cv_text((240 - text_w(&FONT_S, L[0])) / 2, 26, &FONT_S, L[0], C_HI);
        cv_text((240 - text_w(&FONT_S, L[1])) / 2, 52, &FONT_S, L[1], C_DIM);
    } else {
        switch (pg->graph) {
        case GR_ADSR:
            if (ui.ev_cols)
                cv_oy = 0;
            graph_adsr(t, c);
            break;
        case GR_LFO:
            if (ui.ev_cols)
                cv_oy = 0;
            graph_lfo(t, c);
            break;
        case GR_MOD:
            cv_oy = 0;
            graph_mod(t, c);
            break;
        case GR_STEPS:
            graph_steps(t, c);
            break;
        case GR_ROLL:
            graph_roll(t, c);
            break;
        case GR_SCALE:
            graph_scale(t, c);
            break;
        case GR_FX:
            graph_fx(t, c);
            break;
        case GR_SLCR:
            graph_slicer(t, c);
            break;
        case GR_DRONE:
            graph_drone(t, c);
            break;
        case GR_VIVO:
            graph_vivo(t, c);
            break;
        case GR_BROWSE:
            cv_oy = 0;
            graph_browse();
            break;
        case GR_SLOTS:
            cv_oy = 0;
            graph_slots();
            break;
        case GR_USER:
            cv_oy = 0;
            graph_user();
            break;
        default:
            if (big_page(pg)) {
                cv_oy = 0;
                graph_big();
            }
            break;
        }
    }
    top = !ui.home && !drum_note && (pg->graph == GR_BROWSE || pg->graph == GR_SLOTS || pg->graph == GR_USER ||
                                     pg->graph == GR_MOD || big_page(pg) || (ui.ev_cols && row_page(pg)));   /* these draw from the top */
    cv_oy = 0;
    cv_noclip();
    /* graphs keep out of the top G_OY rows: skip them unless something is (or was) there */
    cv_blit_from(0, Y_GRAPH, top || ui.graph_top || ui.force ? 0u : G_OY);
    ui.graph_top = (uint8_t)top;
}

static void draw_foot(void)
{
    char s[48], pn[16], en[10], ti[20];
    const track_t *t = TSEL;
    uint32_t sig;
    const page_t *pg = cur_page();
    const engine_t *e = ENGINES[TSEL->eng_req % NENGINES];
    const char *ename = is_drum(t) ? "DRUM" : e->name;
    int32_t x;
    pn[0] = 0;
    if (is_drum(t))
        str_cpy(pn, "GM KIT", sizeof pn);
    else if (user_of(t) < UP_SLOTS)
        up_name(user_of(t), pn);                       /* a user preset */
    else if (fm6_bank_sound(t, pn))                    /* Jangada 0.6: an FM6 bank voice, by its name */
        ;
    else if (e->npresets)
        str_cpy(pn, e->presets[TSEL->preset % e->npresets].name, sizeof pn);
    if (ui.home) {
        str_cpy(ti, "HOME", sizeof ti);
    } else {                                           /* page title + number in its family: "ENV DEST 2/2" */
        uint32_t i, n = 0, k = 0;
        const char *pt = pg->scope == SC_ENGINE && pg->id[0] < P_E8 ? e->page_title[pg->id[0] != P_E0] : 0;   /* EDIT 1 / 2: the engine's */
        for (i = 0; i < NPAGES; i++)
            if (PAGES[i].fam == pg->fam && page_used(i)) {
                n++;
                if (i == ui.page)
                    k = n;
            }
        str_cpy(ti, pt ? pt : pg->title, 10);
        if (n > 1) {
            str_cpy(ti + str_len(ti), " ", 4);
            fmt_int(ti + str_len(ti), (int32_t)k);
            str_cpy(ti + str_len(ti), "/", 4);
            fmt_int(ti + str_len(ti), (int32_t)n);
        }
    }
    str_cpy(s, ename, sizeof s);
    s[str_len(s) + 1u] = 0;
    s[str_len(s)] = (char)('1' + song.sel);
    str_cpy(s + str_len(s), pn, 16);
    str_cpy(s + str_len(s), ti, sizeof ti);
    {   /* step markers: the playhead only when it is in the shown bank, the cursor only in SEQ */
        uint32_t ph = song.playing && t->seq_idx / 16u == ui.bank ? t->seq_idx : 0xFFu;
        sig = str_hash(0x9E3779B9u, s) + ph * 97u + (song.seq_mode ? ui.cursor : 0xFFu) * 3001u + steps_hash(t) +
              ui.bank * 7u + (uint32_t)t->p[P_SLEN] * 13u + ml_ui.on * 7919u;
    }
    if (!ui.force && sig == ui.foot_sig)
        return;
    ui.foot_sig = sig;
    cv_begin(240, H_FOOT, C_BG);
    if (ml_ui.on) {                                   /* row 1 while MIDI LEARN: what is picked, its CC */
        char ml[32];
        ml_line(ml);
        cv_text(6, 1, &FONT_S, ml, C_WHITE);
    } else {
        uint32_t i;
        for (i = 0; i < 16u; i++) {                   /* row 1: the cursor's bank as 16 thin bars */
            uint32_t si = ui.bank * 16u + i;
            int32_t sx = 6 + (int32_t)i * 14 + (int32_t)(i / 4u) * 4;
            const step_t *st = &t->step[si];
            if (si >= (uint32_t)t->p[P_SLEN])
                continue;
            if (step_on(st))
                cv_rect(sx, 2, 1, 9, C_HI);
            else
                cv_rect(sx, 10, 1, 1, C_DIM);
            if ((song.playing && si == t->seq_idx) || (song.seq_mode && si == ui.cursor))
                cv_rect(sx - 1, 13, 3, 3, C_WHITE);
        }
    }
    x = 4;
    if (FELUCCA_ICONS) {                              /* row 2: engine icon + name, preset, page */
        cv_icon(x, 21, engine_icon(ename), C_GRAY);
        x += 14;
    }
    fit(en, ename, &FONT_S, 90 - (x - 4));
    x = cv_text(x, 20, &FONT_S, en, C_HI);
    {
        char pf[16];
        int32_t room = 236 - text_w(&FONT_S, ti) - 10 - (x + 10);
        str_cpy(pf, pn, sizeof pf);
        while (pf[0] && text_w(&FONT_S, pf) > room)
            pf[str_len(pf) - 1u] = 0;
        cv_text(x + 10, 20, &FONT_S, pf, C_AMB);
    }
    cv_text(236 - text_w(&FONT_S, ti), 20, &FONT_S, ti, C_GRAY);
    cv_blit(0, Y_FOOT);
}
static void draw_columns(void)
{
    uint32_t c;
    char val[12];
    const char *unit;
    ui.ev_cols = (uint8_t)(!ui.home && row_page(cur_page()));
    if (ui.home) {
        for (c = 0; c < 4u; c++) {
            int16_t *vp;
            const param_desc_t *d = home_param(c, &vp);
            param_format(d, *vp, val, &unit);
            draw_column(c, d->label, val, unit, VAL(c), RATIO(d, *vp), param_icon(d, *vp));
        }
        return;
    }
    if (is_drum(TSEL) && !page_for_drum(cur_page())) {   /* "DRUM TRACK" (the graph says so) */
        for (c = 0; c < 4u; c++)
            draw_column(c, "", "", "", C_HI, -1, ICON_AUTO);
        return;
    }
    if (cur_page()->scope == SC_TRK) {                 /* TRACK LEVEL LEN PAN of the selected track */
        const track_t *t = TSEL;
        uint32_t lvl = trk_level(song.sel);
        /* Jangada: TYPE; track 4 switches DRUM / SYNTH here, 1..3 are synths (ALGORITHM picks the track) */
        draw_column(0, "TYPE", is_drum(t) ? "DRUM" : "SYNTH", "", song.sel == TRK_DRUM ? VAL(0u) : C_DIM,
                    song.sel == TRK_DRUM ? (is_drum(t) ? 0 : 1000) : -1, ICON_AUTO);
        if (!lvl || t->p[P_MUTE]) {                    /* (MUTE: a turn of KNOB 2 unmutes, tracks_edit) */
            str_cpy(val, "MUTE", 12);
            unit = "";
        } else if (is_drum(t)) {
            fmt_int(val, (int32_t)lvl);
            unit = "";
        } else {
            param_format(&TP[P_LEVEL], (int32_t)lvl, val, &unit);
        }
        draw_column(1, "LEVEL", val, unit, lvl && !t->p[P_MUTE] ? VAL(1u) : C_DIM, (int32_t)lvl * 1000 / 127, ICON_AUTO);
        param_format(&TP[P_SLEN], t->p[P_SLEN], val, &unit);
        draw_column(2, "LEN", val, unit, VAL(2u), RATIO(&TP[P_SLEN], t->p[P_SLEN]), ICON_AUTO);
        param_format(&TP[P_PAN], t->p[P_PAN], val, &unit);
        draw_column(3, "PAN", val, unit, VAL(3u), RATIO(&TP[P_PAN], t->p[P_PAN]), param_icon(&TP[P_PAN], t->p[P_PAN]));
        return;
    }
    if (cur_page()->graph == GR_BROWSE) {
        uint32_t total, cur = preset_pos(&total), shown, r = preset_cat_rank(cur, &shown);
        char u[8];
        if (!ui.pcat)
            r = cur, shown = total;                       /* (ALL: the place in the whole list) */
        fmt_int(val, preset_in(cur) ? (int32_t)r + 1 : 0);
        fmt_int(u, (int32_t)shown);                       /* (0.9: the count in its own column: "/145" no longer fit) */
        draw_column(0, "No.", val, "", VAL(0u), -1, ICON_NONE);
        draw_column(1, "CAT", is_drum(TSEL) ? "" : PC_NAMES[ui.pcat], "", VAL(1u), -1, ICON_AUTO);   /* (0.8.1; 0.8.2: KNOB 2) */
        draw_column(2, "KIND", is_drum(TSEL) || !total ? "" : preset_kind(cur), "", VAL(2u), -1,   /* (Jangada 0.6) */
                    !is_drum(TSEL) && total && preset_group(cur) < NENGINES ? engine_icon(ENGINES[preset_group(cur)]->name) : ICON_AUTO);
        draw_column(3, "TOTAL", is_drum(TSEL) ? "" : u, "", C_DIM, -1, ICON_AUTO);
        return;
    }
    if (cur_page()->graph == GR_USER) {                  /* SLOT, then three GO buttons */
        int used = up_used(ui.uslot);
        up_slot_label(val, ui.uslot);
        draw_column(0, "SLOT", val, "", VAL(0u), (int32_t)ui.uslot * 1000 / (int32_t)(UP_SLOTS - 1u), ICON_AUTO);
        draw_column(1, "LOAD", "--", "", used ? C_HI : C_DIM, -1, ICON_AUTO);
        draw_column(2, "ERASE", "--", "", used ? C_HI : C_DIM, -1, ICON_AUTO);
        draw_column(3, "SAVE", "--", "", C_HI, -1, ICON_AUTO);
        return;
    }
    if (cur_page()->scope == SC_STEP) {
        static const char *const TIME_N[3] = {"NOTE", "TIE", "REST"};
        const step_t *st = &TSEL->step[ui.cursor];
        char u[8];
        if (st->n) {
            note_name(val, st->note[0]);
            u[0] = 0;
            if (st->n > 1) {
                str_cpy(u, "+", 8);
                fmt_int(u + 1, st->n - 1);
            }
        } else {
            str_cpy(val, "--", 12);
            u[0] = 0;
        }
        {
            static const char *const FLAG_N[4] = {"-", "ACC", "SLD", "A+S"};
            char sn[8], sl[8];
            fmt_int(sn, (int32_t)ui.cursor + 1);
            str_cpy(sl, "/", 8);
            fmt_int(sl + 1, TSEL->p[P_SLEN]);
            draw_column(0, "STEP", sn, sl, VAL(0u), -1, ICON_AUTO);
            if (cur_page()->id[1] == 4u) {                /* STEP 2 (Jangada): RTCH CHNC */
                static const char *const RAT_N[4] = {"x1", "x2", "x3", "x4"};
                static const char *const CHN_N[4] = {"100%", "75%", "50%", "25%"};
                draw_column(1, "RTCH", RAT_N[(st->flags & SF_RATCH) >> SF_RATCH_SH], "", step_on(st) ? VAL(1u) : C_DIM, -1, ICON_AUTO);
                draw_column(2, "CHNC", CHN_N[(st->flags & SF_CHANCE) >> SF_CHANCE_SH], "", step_on(st) ? VAL(2u) : C_DIM, -1, ICON_AUTO);
                fmt_int(u, st->vel ? st->vel : 96);   /* VEL (0.9.7) */
                draw_column(3, "VEL", st->flags & SF_ACCENT ? "127" : u, "", step_on(st) ? VAL(3u) : C_DIM,
                            step_on(st) ? (st->flags & SF_ACCENT ? 127 : st->vel ? st->vel : 96) * 1000 / 127 : -1, ICON_AUTO);
                return;
            }
            draw_column(1, "NOTE", val, u, step_on(st) ? VAL(1u) : C_DIM, -1, ICON_AUTO);
            draw_column(2, "TIME", TIME_N[st->time % 3u], "", VAL(2u), -1, ICON_AUTO);
            draw_column(3, "FLAG", FLAG_N[(st->flags & SF_ACCENT ? 1u : 0u) | (st->flags & SF_SLIDE ? 2u : 0u)], "",
                        VAL(3u), -1, ICON_AUTO);
        }
        return;
    }
    for (c = 0; c < 4u; c++) {
        int16_t *vp;
        const param_desc_t *d = page_desc(cur_page(), c, &vp);
        if (!d || !d->label || d->label[0] == '-') {
            draw_column(c, "", "", "", C_HI, -1, ICON_AUTO);
            continue;
        }
        if (cur_page()->id[c] == G_MIDI && cur_page()->scope == SC_GLOBAL) {
            str_cpy(val, !usb.up ? "OFF" : usb.config ? "MIDI" : usb.setups ? "ENUM" : usb.sof_seen ? "BUS" : "WAIT", 12);
            unit = "USB";
            draw_column(c, "USB", val, unit, C_HI, -1, ICON_AUTO);
            continue;
        }
        if (cur_page()->id[c] == G_INFO && cur_page()->scope == SC_GLOBAL) {
            fmt_int(val, (int32_t)(song.cpu_q8 * 100u / 256u));
            unit = C1_ON() ? "%x2" : "%";                /* Jangada 1.0: x2, the second core takes parts (fx.c) */
        } else {
            param_format(d, *vp, val, &unit);
        }
        ui.big_k[c] = d->fmt == F_ENUM ? BK_LIST : d->min < 0 ? BK_BIPOLAR : BK_AMOUNT;   /* (graph_big) */
        draw_column(c, d->label, val, unit, VAL(c), d->fmt == F_ENUM && d->max < 2 ? -1 : RATIO(d, *vp),
                    param_icon(d, *vp));
    }
}


static int layers_draw(void);                       /* ui_layers.c */
static uint8_t vis_on;          /* Jangada 0.7: the visualiser is open (ui_vis.c, through ui_layers.c) */
static void ui_draw(void)
{
    ui.frame++;
    if (ui.menu) {
        draw_menu();
        ui.force = 0;
        return;
    }
    if (layers_draw())                                  /* Jangada: a layer held (ui_layers.c) */
        return;
    if (ui.confirm) {                                   /* clear-the-sequence dialog */
        if (ui.force) {
            char b[16] = "CLEAR TRACK 1?", s[20] = "CLEAR T1 SEQUENCE?";   /* the header (T1..T4) is hidden */
            const char *q = ui.confirm == 2 ? b : s, *h = "OCT- NO    OCT+ YES";
            b[12] = (char)('1' + ui.confirm_trk);
            s[7] = b[12];
            lcd_fill(0, 0, 240, 240, C_BG);
            cv_begin(240, 100, C_BG);                   /* a dialog card */
            cv_card(12, 0, 216, 100);
            cv_text((240 - text_w(&FONT_M, q)) / 2, 26, &FONT_M, q, C_WHITE);
            cv_text((240 - text_w(&FONT_S, h)) / 2, 58, &FONT_S, h, C_GRAY);
            cv_blit(0, 70);
            ui.force = 0;
        }
        return;
    }
    if (vis_on) {                                       /* left for another page (or HOME): it closes */
        vis_on = 0;
        ui.force = 1;
    }
    cursor_fix();
    if (ui.force)
        draw_frame();
    felucca_dbg.stage = 3;
    draw_head();
    felucca_dbg.stage = 4;
    draw_columns();
    felucca_dbg.stage = 5;
    draw_graph();
    if (ui.msg_t)
        ui.msg_t--;
    if (ui.bpm_t)
        ui.bpm_t--;
    if (ui.arm_t && !--ui.arm_t)
        ui.arm = 0;
    if (ui.hot_t)
        ui.hot_t--;
    felucca_dbg.stage = 6;
    draw_foot();
    ui.force = 0;
}

