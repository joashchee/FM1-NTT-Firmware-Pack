/* SPDX-License-Identifier: MPL-2.0
 * Copyright (C) 2026 Kerem Kilic (Ellic Studio) */
/* Actual policy, IRQ/CPU1 gate and wrapper code with a simulated RAM driver.
 * Run in default, custom-region, loader-override and expanded-capacity modes,
 * and with a board's own map (5: the SMK-37's, boards/smk37/fm1_flash.h);
 * tests/run_flash_tests.sh also checks invalid configurations. */
#include <stdint.h>
#ifndef FM1_CPU1
#define FM1_CPU1 1
#endif
#include <stdio.h>

#if TEST_LAYOUT == 1
#define FM1_FLASH_WRITE_REGIONS(X) X(0x98000u, 0x99000u) X(0x9A000u, 0x9B000u)
#elif TEST_LAYOUT == 2
#define FL_RANGE_OK(off, n) (FL_IN(off, n, 0x4000u, 0x97000u) || FL_IN(off, n, 0xE0000u, 0xFC000u))
#elif TEST_LAYOUT == 3
#define FM1_FLASH_SIZE 0x400000u
#define FM1_FLASH_WRITE_REGIONS(X) X(0x100000u, 0x400000u)
#elif TEST_LAYOUT == 4
#define FM1_FLASH_WRITE_REGIONS(X)
#elif TEST_LAYOUT == 5
#define FL_MAP_ONLY 1                                   /* the SMK-37's map and its regions, over this policy */
#include "../boards/smk37/fm1_flash.h"
#endif
#include "fm1_flash_policy.h"

static uint32_t cfg, core, c1, syncs;
#define FM1_FLASH_ICFG_READ() cfg
#define FM1_FLASH_ICFG_WRITE(v) (cfg = (v))
#define FM1_FLASH_SYNC() ((void)++syncs)
#define FM1_FLASH_CORE() core
#define FM1_FLASH_C1_CON c1
#include "fm1_flash_access.h"

static unsigned calls, fail_at;
static uint32_t seen_off[8], seen_n[8];
static uintptr_t seen_buf[8];
static int transact(uint32_t off, const void *p, uint32_t n)
{
    if (!fm1_flash_access_ok()) return FL_ERR_BUSY;
    if (calls < 8) {
        seen_off[calls] = off; seen_n[calls] = n; seen_buf[calls] = (uintptr_t)p;
    }
    calls++;
    return fail_at == calls ? FL_ERR_TIMEOUT : 0;
}
static int fl_prog_ram(uint32_t off, const uint8_t *p, uint32_t n, uint32_t *took)
{ (void)took; return transact(off, p, n); }
static int fl_read_ram(uint32_t off, uint8_t *p, uint32_t n)
{ return transact(off, p, n); }
static int fl_erase4k_ram(uint32_t off, uint32_t *took)
{ return transact(off, took, 4096); }
static uint32_t fl_jedec_ram(void)
{ return transact(0, 0, 0) ? 0 : 0x856014u; }
static uint32_t fl_status_ram(void)
{ return transact(0, 0, 0) ? UINT32_MAX : 0; }
#define FL_UID 1
static int fl_uid_ram(uint8_t *p) { return transact(0, p, 16); }
#define FL_FAR(fn) (fn)
#define FL_XIP(off) (0x02000000u + (off) - 0x4000u)
#include "fm1_flash_api.h"

static unsigned checks, fails;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL %d: %s\n", __LINE__, #c); fails++; } } while (0)
#define RAM(p) ((uint8_t *)(uintptr_t)(p))

static void reset(void)
{
    calls = fail_at = core = c1 = syncs = 0;
    cfg = 0x7B5u;                                   /* both interrupt enables set (bits 8 and 9) */
    fm1_flash_cpu1_idle = 0;
}

static void policy(void)
{
    CHECK(!FL_IN(0x90000u, 1u, 0xA0000u, 0x90000u));
    CHECK(!FL_READ_OK(UINT32_MAX, 2u));
    CHECK(FL_READ_OK(FM1_FLASH_SIZE, 0u));
    CHECK(!FL_READ_OK(FM1_FLASH_SIZE, 1u));
    CHECK(!FL_READ_OK(FM1_FLASH_SIZE - 1u, 2u));
    CHECK(FL_RAM_OK(RAM(0x1C00000u), 0x80000u));
    CHECK(FL_RAM_OK(RAM(0x1C80000u), 0u));
    CHECK(!FL_RAM_OK(RAM(0x1C7FFFFu), 2u));
    CHECK(!FL_RAM_OK(RAM(0x2000000u), 1u));
    CHECK(!FL_RAM_OK(RAM(UINTPTR_MAX), 2u));
    CHECK(!FL_WRITE_OK(FM1_FLASH_SIZE, 1u));
#if TEST_LAYOUT == 0
    CHECK(FL_WRITE_OK(0x97000u, 0x49000u));
    CHECK(FL_WRITE_OK(FL_OTA_LO, FL_OTA_HI - FL_OTA_LO));
    CHECK(FL_WRITE_OK(FL_AUTO_LO, FL_AUTO_HI - FL_AUTO_LO));
    CHECK(FL_WRITE_OK(0xFC000u, 0x3000u));
    CHECK(!FL_WRITE_OK(0xFFFFFu, 1u));
    CHECK(!FL_WRITE_OK(0x4000u, 4096u));
#elif TEST_LAYOUT == 1
    CHECK(FL_WRITE_OK(0x98000u, 4096u));
    CHECK(!FL_WRITE_OK(0x98FFFu, 2u));
    CHECK(!FL_WRITE_OK(0x98000u, 0x3000u));
    CHECK(!FL_WRITE_OK(FL_OTA_LO, 1u));
#elif TEST_LAYOUT == 2
    CHECK(FL_WRITE_OK(0x4000u, 0x93000u));
    CHECK(!FL_WRITE_OK(0x97000u, 4096u));
    CHECK(FL_WRITE_OK(0xE0000u, 0x1C000u));
    CHECK(!FL_WRITE_OK(0xFC000u, 1u));
#elif TEST_LAYOUT == 3
    CHECK(FL_WRITE_OK(0x100000u, 0x300000u));
    CHECK(!FL_WRITE_OK(0xFFFFFu, 1u));
    CHECK(!FL_PLAIN_OK(0x100000u, 1u)); /* capacity does not extend XIP */
#elif TEST_LAYOUT == 5
    {
        /* every sector: writable exactly in the SMK's windows (the store, the settings, the autosave, the two more,
         * the update's staging, the stock marker), never in a protected range nor the app area */
        uint32_t s, ok = 1;
        for (s = 0; s < FM1_FLASH_SIZE; s += 0x1000u) {
            int win = (s >= FL_DATA_LO && s < FL_DATA_HI) || (s >= FL_GLOB_LO && s < FL_GLOB_HI) ||
                      (s >= FL_AUTO_LO && s < FL_AUTO_HI) || (s >= FL_XDATA0_LO && s < FL_XDATA0_HI) ||
                      (s >= FL_XDATA1_LO && s < FL_XDATA1_HI) || (s >= FL_OTA_LO && s < FL_OTA_HI) ||
                      (s >= FL_FREE_LO && s < FL_FREE_HI) || s == FL_STOCK_MARK;
            if (FL_WRITE_OK(s, 0x1000u) != win || (win && (FL_PROTECTED(s, 0x1000u) || s < FL_APP_HI)))
                ok = 0;
        }
        CHECK(ok);
    }
    CHECK(FL_WRITE_OK(FL_DATA_LO, FL_DATA_HI - FL_DATA_LO) && FL_WRITE_OK(FL_GLOB_LO, FL_GLOB_HI - FL_GLOB_LO));
    CHECK(FL_WRITE_OK(FL_OTA_LO, FL_OTA_HI - FL_OTA_LO));
    CHECK(!FL_WRITE_OK(FL_BTIF, 1u) && !FL_WRITE_OK(FL_USRTRIM, 0x1000u) && !FL_WRITE_OK(FL_PROT2_LO, 1u));
    CHECK(!FL_WRITE_OK(0xFF000u, 1u) && !FL_WRITE_OK(0x4000u, 1u) && !FL_WRITE_OK(FL_APP_HI - 1u, 1u));
    CHECK(!FL_WRITE_OK(FL_OTA_HI - 0x100u, 0x200u));    /* the staging's end touches BTIF: not one byte of it */
    CHECK(!FL_WRITE_OK(0x97000u, 0x1000u));               /* the FM-1's store: the SMK's app area */
    CHECK(FM1_FLASH_PLAIN_LO == FL_APP_HI && FL_PLAIN_OK(FL_USRTRIM, 0x1000u) && !FL_PLAIN_OK(FL_APP_HI - 1u, 1u));
#else
    CHECK(!FL_WRITE_OK(0x98000u, 1u));
    CHECK(!FL_WRITE_OK(FL_OTA_LO, 1u));
#endif
}

/* a write across regions that touch: checked page by page before the first, as fl_prog_ram checks each page */
static void spans(void)
{
#if TEST_LAYOUT == 0
    reset();
    CHECK(fl_write(0xE6F00u, RAM(0x1C10000u), 0x200u) == 0 && calls == 2);    /* AUTO -> XDATA1 at 0xE7000 */
    CHECK(seen_off[0] == 0xE6F00u && seen_off[1] == 0xE7000u);
    reset();
    CHECK(fl_write(0x96F80u, RAM(0x1C10000u), 0x100u) == 0 && calls == 2);    /* XDATA0 -> store at 0x97000 */
    reset();
    CHECK(fl_write(0x92F00u, RAM(0x1C10000u), 0x200u) == FL_ERR_RANGE && calls == 0);   /* the app area: no page */
    CHECK(fl_write(0xFEF00u, RAM(0x1C10000u), 0x200u) == FL_ERR_RANGE && calls == 0);   /* past the globals */
#elif TEST_LAYOUT == 1
    reset();
    CHECK(fl_write(0x98F00u, RAM(0x1C10000u), 0x200u) == FL_ERR_RANGE && calls == 0);   /* a gap: no page */
#elif TEST_LAYOUT == 5
    reset();
    CHECK(fl_write(0xA2F00u, RAM(0x1C10000u), 0x200u) == 0 && calls == 2);    /* AUTO -> XDATA1 at 0xA3000 */
    reset();
    CHECK(fl_write(0xE9F00u, RAM(0x1C10000u), 0x200u) == 0 && calls == 2);    /* the store -> the stock marker */
    reset();
    CHECK(fl_write(0xBFF00u, RAM(0x1C10000u), 0x200u) == FL_ERR_RANGE && calls == 0);   /* the staging -> BTIF */
    CHECK(fl_write(0xC1F00u, RAM(0x1C10000u), 0x200u) == FL_ERR_RANGE && calls == 0);   /* USRTRIM -> the store */
    CHECK(fl_write(0x9CF00u, RAM(0x1C10000u), 0x200u) == FL_ERR_RANGE && calls == 0);   /* the app area -> XDATA0 */
    reset();
    CHECK(fl_write(0xEDF00u, RAM(0x1C10000u), 0x200u) == 0 && calls == 2);    /* the settings -> FL_FREE */
    reset();
    CHECK(fl_write(0xF3F00u, RAM(0x1C10000u), 0x200u) == FL_ERR_RANGE && calls == 0);   /* FL_FREE -> USR */
#endif
}

static void locking(void)
{
    const uint32_t states[] = {0u, 0x100u, 0x200u, 0x300u, 0x5B5u, 0x4B5u, 0x7B5u, UINT32_MAX};
    unsigned i;
    for (i = 0; i < sizeof states / sizeof states[0]; i++) {
        uint32_t outer, inner;
        reset(); cfg = states[i];
        outer = irq_save();
        CHECK(outer == states[i]);
        CHECK(cfg == (states[i] & ~0x300u));
        inner = irq_save();
        CHECK(inner == cfg);
        irq_restore(inner);
        CHECK(cfg == (states[i] & ~0x300u));
        irq_restore(outer);
        CHECK(cfg == states[i]);
    }
    reset();
    CHECK(!fm1_flash_access_ok()); /* enabled IRQs */
    cfg &= ~0x200u;
    CHECK(fm1_flash_access_ok()); /* cli (bit 9) alone: off, as the SDK's cpu_irq_disabled */
    cfg = 0x7B5u & ~0x100u;
    CHECK(fm1_flash_access_ok()); /* irq_save (bit 8); CPU1 never started */
    c1 = 10u;
    CHECK(fm1_flash_access_ok()); /* CPU1 held */
    c1 = 8u;
    CHECK(fm1_flash_access_ok() == !FM1_CPU1); /* unknown/busy CPU1: refused in a build with the second core */
    fm1_flash_cpu1_idle = 1;
    CHECK(fm1_flash_access_ok()); /* registered RAM idle */
    core = 1;
    CHECK(!fm1_flash_access_ok()); /* CPU1 may not own SFC */
}

static void wrappers(void)
{
    uint32_t off, limit, state;
    int rc;
#if TEST_LAYOUT == 0
    off = 0x970F0u; limit = FL_GLOB_HI;           /* the defaults touch from 0x93000 up to the globals' end */
#elif TEST_LAYOUT == 1
    off = 0x980F0u; limit = 0x99000u;
#elif TEST_LAYOUT == 2
    off = 0x4000u + 0xF0u; limit = 0x97000u;
#elif TEST_LAYOUT == 3
    off = 0x1000F0u; limit = FM1_FLASH_SIZE;
#elif TEST_LAYOUT == 5
    off = FL_DATA_LO + 0xF0u; limit = FL_FREE_HI;   /* the SMK's store, up to FL_FREE's end (USR) */
#else
    reset();
    CHECK(fl_write(0x98000u, RAM(0x1C10000u), 1u) == FL_ERR_RANGE);
    CHECK(calls == 0);
    return;
#endif
    reset(); state = cfg;
    CHECK(fl_write(off, RAM(0x1C10000u), 600) == 0);
    CHECK(cfg == state && calls == 4);
    CHECK(seen_n[0] == 16 && seen_n[1] == 256 && seen_n[2] == 256 && seen_n[3] == 72);
    CHECK(seen_off[1] == off + 16 && seen_buf[3] == 0x1C10210u);
    reset(); state = cfg;
    CHECK(fl_write(limit - 16u, RAM(0x1C10000u), 17u) == FL_ERR_RANGE);
    CHECK(calls == 0 && cfg == state); /* reject before any page changes */
    CHECK(fl_write(off, RAM(0x1C7FFFFu), 2u) == FL_ERR_BUFFER);
    CHECK(fl_write(off, RAM(0x2000000u), 1u) == FL_ERR_BUFFER);
    CHECK(calls == 0);
    CHECK(fl_write(off, RAM(0x1C10000u), 0u) == 0 && calls == 0);
    CHECK(fl_write(off, 0, 0u) == 0 && fl_write(UINT32_MAX, 0, 0u) == 0 && calls == 0);   /* nothing: 0, as before */
    CHECK(fl_read(off, 0, 0u) == 0 && calls == 0);
    reset(); cfg &= ~0x100u; state = cfg; fail_at = 2;
    CHECK(fl_write(off, RAM(0x1C10000u), 600) == FL_ERR_TIMEOUT);
    CHECK(calls == 2 && cfg == state); /* disabled stays disabled on failure */
    reset(); c1 = 8;
#if FM1_CPU1
    CHECK(fl_write(off, RAM(0x1C10000u), 1u) == FL_ERR_BUSY);
    CHECK(calls == 0 && cfg == 0x7B5u);
#else
    CHECK(fl_write(off, RAM(0x1C10000u), 1u) == 0 && calls == 1); /* no second core in this build */
    calls = 0;
#endif
    fm1_flash_cpu1_idle = 1;
    CHECK(fl_write(off, RAM(0x1C10000u), 1u) == 0 && calls == 1);
    reset(); state = cfg;
    CHECK(fl_read(0x20u, RAM(0x1C10000u), 600) == 0);
    CHECK(calls == 3 && cfg == state && seen_n[2] == 88 && seen_off[2] == 0x220u);
    reset();
    CHECK(fl_read(FM1_FLASH_SIZE - 1u, RAM(0x1C10000u), 2u) == FL_ERR_RANGE);
    CHECK(fl_read(0, RAM(0x1C7FFFFu), 2u) == FL_ERR_BUFFER);
    CHECK(calls == 0);
    fail_at = 2;
    CHECK(fl_read(0, RAM(0x1C10000u), 600) == FL_ERR_TIMEOUT && calls == 2);
    CHECK(cfg == 0x7B5u);
    reset(); state = cfg;
    rc = fl_erase4k(off & ~0xFFFu, (uint32_t *)RAM(0x1C10000u));
    CHECK(rc == 0 && calls == 1 && cfg == state);
#if FM1_CPU1
    c1 = 8;
    CHECK(fl_erase4k(off & ~0xFFFu, (uint32_t *)RAM(0x1C10000u)) == FL_ERR_BUSY);
    CHECK(calls == 1 && cfg == state);
#endif
    reset(); cfg &= ~0x100u; state = cfg;
    CHECK(fl_jedec() == 0x856014u && cfg == state);
    CHECK(fl_status() == 0 && cfg == state);
    CHECK(fl_uid(RAM(0x1C10000u)) == 0 && cfg == state);
#if FM1_CPU1
    c1 = 8;
    CHECK(fl_jedec() == 0 && cfg == state);
    CHECK(fl_status() == UINT32_MAX && cfg == state);
#endif
    CHECK(fl_verify_xip(FM1_FLASH_PLAIN_HI - 1u, RAM(0x1C10000u), 2u) == FL_ERR_RANGE);
    CHECK(fl_verify_xip(FM1_FLASH_PLAIN_LO, RAM(0x2000000u), 1u) == FL_ERR_BUFFER);
}

int main(void)
{
    policy(); locking(); wrappers(); spans();
    printf("flash layout %d (FM1_CPU1 %d): %u checks, %u failures\n", TEST_LAYOUT, FM1_CPU1, checks, fails);
    return fails != 0;
}
