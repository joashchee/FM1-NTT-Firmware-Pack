#!/usr/bin/env python3
# SPDX-License-Identifier: MPL-2.0
# Copyright (C) 2026 Charles Vestal
# Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments
"""tools/fm1_install.py against a simulated FM-1 (no hardware, no mido).
The fake device is the one in web/test_web.mjs: identity on the handshake,
then "device asks, host answers" reads of the logical image. Run from the repo root:
  python3 tests/install_test.py
Also checks logical_image/product_of against web/fm1pkg.js (needs node and
template/build/template.fwsc, skipped otherwise)."""
import io
import queue
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import fm1_install as I  # noqa: E402

I.DELAY.update(open=0, start=0.01, reply=0, loader=0.01, reboot=0.01, retry=0.02, poll=0.05, hs=0.1, hs_full=0.1,
               idle_check=0.4, idle_write=0.4, wait_loader=2, wait_reboot=2)
failed = 0


def ok(cond, what):
    global failed
    print(f"{what:<64} {'ok' if cond else 'FAIL'}")
    failed += not cond


# ---------------------------------------------------------- simulated FM-1 ---

class FakeLink:
    def __init__(self, dev, gen):
        self.dev, self.gen, self.q, self.closed = dev, gen, queue.Queue(), False

    @property
    def lost(self):
        return self.gen != self.dev.gen or not self.dev.connected

    def send(self, pkt):
        if self.lost:
            return False
        self.dev.sent.append(bytes(pkt))
        self.dev.rx(bytes(pkt))
        return True

    def read(self, timeout):
        try:
            return self.q.get(timeout=max(timeout, 0))
        except queue.Empty:
            return None

    def drain(self):
        while not self.q.empty():
            self.q.get_nowait()

    def close(self):
        self.closed = True


class FakeFM1:
    """a MIDI backend with one FM-1 on it"""

    def __init__(self, image, identity="FM-1_015", name="FM-1", unplug_after=None, after_write="FM-1_900",
                 stall_after=None, bad_addr=None, refuse_arm=False, new_ota=(), jedec=0):
        self.image, self.unplug_after, self.after_write = image, unplug_after, after_write
        self.new_ota, self.jedec = set(new_ota), jedec   # identities whose ota.c cuts the plain answer; bsp#29's bytes
        self.refuse_arm, self.armed, self.arms = refuse_arm, False, []
        self.stall_after, self.bad_addr = stall_after, bad_addr
        self.served = self.bad = self.upgrades = self.hs_full = 0
        self.sent, self.links, self.gen, self.lock = [], [], 0, threading.Lock()
        self.boot(identity, name)

    def boot(self, identity, name):
        with self.lock:
            self.gen += 1
            self.identity, self.name, self.connected = identity, name, True
            self.waiting, self.queue = None, []

    def input_names(self):
        return [self.name] if self.connected else []

    output_names = input_names

    def open(self, in_name, out_name):
        if in_name != self.name or not self.connected:
            raise IOError("no such port")
        link = FakeLink(self, self.gen)
        self.links.append(link)
        return link

    def tx(self, pkt):
        for link in self.links:
            if link.gen == self.gen and not link.closed:
                link.q.put(bytes(pkt))

    def ident(self, text):
        b = bytearray(text.encode() + bytes(27 - len(text)))
        b[24:27] = self.jedec.to_bytes(3, "big")
        self.tx(b"\xF0" + I.pack7(bytes([0, 0x59, 0x11, 27, 0, 0]) + b + bytes([~sum(b) & 0xFF])) + b"\xF7")

    def rx(self, d):
        u = I.unpack7(d[1:-1])
        if self.identity.startswith("FM1_") and len(u) >= 7 and u[:2] == b"\x00\x59" and u[2] in (49, 50):
            self.open_cmd(u[2], u[6:-1])        # M-VAVE's Open firmware: state, arm
            return
        new = self.identity in self.new_ota       # chip/ota.c from M-UPGRADE 3.11's fix on: NAME_ + 3 digits to HS_QUERY
        if d == I.HS_QUERY:
            self.ident(self.identity[:self.identity.index("_") + 4] if new else self.identity)
        elif d == I.HS_FULL:
            self.hs_full += 1
            if new:
                self.ident(self.identity)
        elif d == I.UPGRADE:
            if self.identity.startswith("FM1_") and not self.armed:
                return                          # Open ignores an update it was not armed for
            self.upgrades += 1
            first = self.bad_addr if self.bad_addr is not None else 0
            self.queue = ([(first + k * 512, 512) for k in range(6)] + [(I.FINISH_WRITE, 8)]
                          if self.identity.startswith("ota-")
                          else [(0, 64), (0x40, 160), (0x1000, 512), (I.FINISH_CHECK, 8)])
            self.next()
        elif self.waiting:
            u = I.unpack7(d[1:-1])
            addr, n = self.waiting
            fin = addr >= I.FINISH_CHECK
            want = b"success\0" if fin else self.image[addr:addr + n]
            if u[14:14 + len(want)] != want or len(u) != 15 + len(want):
                self.bad += 1
            self.waiting = None
            self.served += 1
            if self.unplug_after and self.served >= self.unplug_after:
                self.connected = False
                return
            if self.stall_after and self.served >= self.stall_after:
                return
            if addr == I.FINISH_CHECK:
                threading.Timer(0.05, self.boot, ("ota-FM-1_900", "Felucca Update")).start()
            elif addr == I.FINISH_WRITE:
                threading.Timer(0.05, self.boot, (self.after_write, "Felucca")).start()
            else:
                self.next()

    def open_cmd(self, cmd, data):
        if cmd == 49:
            out = b"FMC1" + bytes([1, 7, 0, 1]) + (512).to_bytes(2, "little") + (1 << 20).to_bytes(4, "little") + bytes(33)
        else:
            self.arms.append(bytes(data))
            ok_ = len(data) == 38 and data[:2] == bytes([1, 7]) and int.from_bytes(data[2:6], "little") == len(self.image)
            self.armed = ok_ and not self.refuse_arm
            out = b"\0" if self.armed else b"\x01"
        self.tx(b"\xF0" + I.pack7(bytes([0, 0x59, cmd, len(out), 0, 0]) + out + bytes([~sum(out) & 0xFF])) + b"\xF7")

    def next(self):
        if not self.queue:
            return
        self.waiting = addr, n = self.queue.pop(0)
        u = bytearray([0, 0x59, 0x30, 0, 0, 0, 0]) + addr.to_bytes(4, "little") + bytes([n & 0xFF, n >> 8, 0])
        u.append(~sum(u[6:14]) & 0xFF)
        self.tx(b"\xF0" + I.pack7(u) + b"\xF7")


# ----------------------------------------------------------------- helpers ---

def package(product="FM-1_900", marker=True, size=0x2000):
    raw = bytearray((i * 7) & 0xFF for i in range(size + I.BLOCKS))
    for i in range(I.BLOCKS):
        raw[i * I.BLK + I.KEEP] = (ord(product[i]) + i + 1) & 0xFF if i < len(product) else 0x7D
    raw[0x1800:0x1800 + 16] = I.LOADER_MARK if marker else bytes(16)
    return bytes(raw)


TMP = Path(tempfile.mkdtemp(prefix="felucca-install-"))


def pkgfile(name, raw):
    p = TMP / name
    p.write_bytes(raw)
    return str(p)


def cli(args, dev, answer=True):
    out, err = io.StringIO(), io.StringIO()
    old, sys.stderr = sys.stderr, err
    try:
        rc = I.main(args, backend=dev, out=out, ask=lambda _p: answer)
    finally:
        sys.stderr = old
    return rc, out.getvalue(), err.getvalue()


# ------------------------------------------------------------------- tests ---

def wire():
    data = bytes(range(256)) * 3
    ok(I.unpack7(I.pack7(data))[:len(data)] == data, "pack7 / unpack7 round trip")
    pkt = I.response(0x12345, b"\x01\x02\x03", fl=5)
    u = I.unpack7(pkt[1:-1])
    ok(u[:3] == b"\x00\x59\x30" and int.from_bytes(u[7:11], "little") == 0x12345 and u[14:17] == b"\x01\x02\x03"
       and ~sum(u[6:17]) & 0xFF == u[17], "response: header, address, data, checksum")
    raw = package("FM-1_906")
    ok(I.product_of(raw) == "FM-1_906" and len(I.logical_image(raw)) == len(raw) - 20, "product_of / logical_image (synthetic)")
    ok(I.HS_FULL == b"\xF0" + I.pack7(bytes([0, 0x59, 0x11, 1, 0, 0, 1, 0xFE])) + b"\xF7"
       and I.unpack7(I.HS_FULL[1:-1])[:8] == bytes([0, 0x59, 0x11, 1, 0, 0, 1, 0xFE]),
       "HS_FULL: 00 59 11, length 1, body 01, checksum FE")
    b = bytearray(b"FM-1_6010000" + bytes(15))
    b[24:27] = b"\xB3\x60\x14"                   # felucca-bsp#29: the flash's JEDEC id after the text
    i = I.parse_identity(b"\xF0" + I.pack7(bytes([0, 0x59, 0x11, 27, 0, 0]) + b + bytes([~sum(b) & 0xFF])) + b"\xF7")
    ok(i and i.text == "FM-1_6010000" and i.version == 6010000, "parse_identity: the text up to its first zero (#29's bytes after it)")
    raw = package("FM-1_9001000")                  # X0X from 0.10: major, minor, patch, two digits each
    ok(I.product_of(raw) == "FM-1_9001000", "product_of: a 12-character identity")


def installs():
    raw = package()
    image = I.logical_image(raw)
    p = pkgfile("ok.fwsc", raw)

    dev = FakeFM1(image)
    rc, out, err = cli([p, "--yes"], dev)
    ok(rc == 0 and dev.bad == 0 and dev.upgrades == 2 and dev.served == 11 and "done: the FM-1 runs FM-1_900" in out
       and "100%" in out, f"install: running -> loader -> Felucca ({dev.served} reads)")

    raw10 = package("FM-1_9001000")
    dev = FakeFM1(I.logical_image(raw10), identity="FM-1_909", after_write="FM-1_9001000")
    rc, out, err = cli([pkgfile("x10.fwsc", raw10), "--yes"], dev)
    ok(rc == 0 and dev.bad == 0 and "done: the FM-1 runs FM-1_9001000" in out,
       "install: 0.9 (FM-1_909) -> 0.10 (FM-1_9001000), the longer identity verified after")

    dev = FakeFM1(image, identity="ota-FM-1_900", name="Felucca Update")
    rc, out, err = cli([p, "--yes"], dev)
    ok(rc == 0 and dev.bad == 0 and dev.upgrades == 1 and "update mode" in out, "install: device already in update mode -> finishes the write")

    dev = FakeFM1(image)
    rc, out, err = cli([p], dev, answer=False)
    ok(rc == 1 and dev.upgrades == 0 and "cancelled" in out, "install: answer no -> nothing sent but the handshake")

    dev = FakeFM1(image, identity="FM-1_905", name="Felucca")
    rc, out, err = cli(["--info"], dev)
    ok(rc == 0 and "FM-1_905" in out and "running" in out and dev.upgrades == 0, "--info: identity of the connected FM-1")

    dev = FakeFM1(image, identity="ota-FM-1_900", name="Felucca Update")
    rc, out, err = cli(["--info"], dev)
    ok(rc == 0 and "update loader" in out and dev.hs_full == 0, "--info: device in update mode (never asked with 01)")

    # M-UPGRADE 3.11 takes NAME_ and 1-3 digits: chip/ota.c answers HS_QUERY with FM-1_601, HS_FULL with the whole
    rawl = package("FM-1_6010100")
    dev = FakeFM1(I.logical_image(rawl), identity="FM-1_6010000", name="FM-1", after_write="FM-1_6010100",
                  new_ota={"FM-1_6010000", "FM-1_6010100"}, jedec=0xB36014)
    rc, out, err = cli([pkgfile("long.fwsc", rawl), "--yes"], dev)
    ok(rc == 0 and dev.bad == 0 and "device:  FM-1_6010000" in out and "done: the FM-1 runs FM-1_6010100" in out,
       "install: FM-1_601 to the plain query, the whole identity to HS_FULL")
    rawl = package("FM-1_6010000")
    dev = FakeFM1(I.logical_image(rawl), identity="FM-1_6000900", name="FM-1", after_write="FM-1_6010000",
                  new_ota={"FM-1_6010000"})
    rc, out, err = cli([pkgfile("long.fwsc", rawl), "--yes"], dev)
    ok(rc == 0 and dev.bad == 0 and "done: the FM-1 runs FM-1_6010000" in out,
       "install: from a build before it (whole identity to the plain query) to one after")
    dev = FakeFM1(image, identity="FM-1_600", name="FM-1", new_ota={"FM-1_600"})
    rc, out, err = cli(["--info"], dev)
    ok(rc == 0 and "FM-1_600" in out and dev.hs_full == 1, "--info: a dev build's FM-1_600, the same both ways")
    dev = FakeFM1(image, identity="FM-1_015", name="FM-1")
    rc, out, err = cli(["--info"], dev)
    ok(rc == 0 and "FM-1_015" in out and dev.hs_full == 1, "--info: M-VAVE's firmware doesn't answer HS_FULL: its plain answer")


def errors():
    raw = package()
    image = I.logical_image(raw)
    p = pkgfile("ok.fwsc", raw)

    rc, out, err = cli([p, "--yes"], FakeFM1(image, name="IAC Driver Bus 1"))
    ok(rc == 3 and "not found" in err and "IAC Driver" in err, "no FM-1 port -> exit 3, lists the MIDI inputs")
    dev = FakeFM1(image)
    rc, out, err = cli([p, "--yes", "--port", "Felucca"], dev)
    ok(rc == 3 and dev.upgrades == 0, "--port that matches nothing -> exit 3")
    dev = FakeFM1(image, name="My Interface")
    rc, out, err = cli(["--info", "--port", "my int"], dev)
    ok(rc == 0 and "FM-1_015" in out, "--port picks a port the default match skips")

    t0 = time.monotonic()
    rc, out, err = cli([p, "--yes"], FakeFM1(image, unplug_after=2))
    ok(rc == 4 and "disconnected" in err and "nothing was written" in err and time.monotonic() - t0 < 3,
       "unplugged in step 1 -> exit 4 'lost', nothing written")
    t0 = time.monotonic()
    rc, out, err = cli([p, "--yes"], FakeFM1(image, identity="ota-FM-1_900", name="Felucca Update", unplug_after=3))
    ok(rc == 4 and "run the install again" in err and time.monotonic() - t0 < 3, "unplugged during the write -> exit 4 at once")
    rc, out, err = cli([p, "--yes"], FakeFM1(image, identity="ota-FM-1_900", name="Felucca Update", stall_after=3))
    ok(rc == 4 and "stopped answering" in err, "loader stops answering -> exit 4 after the idle time")
    rc, out, err = cli([p, "--yes"], FakeFM1(image, identity="ota-FM-1_900", name="Felucca Update", bad_addr=len(image)))
    ok(rc == 4 and "outside the package" in err, "read past the package -> exit 4")

    rc, out, err = cli([p, "--yes"], FakeFM1(image, after_write="FM-1_015"))
    ok(rc == 6 and "reports FM-1_015" in err, "another identity after the restart -> exit 6")
    dev = FakeFM1(image, identity="XY-9_001", name="usb-midi")
    rc, out, err = cli([p, "--yes"], dev)
    ok(rc == 6 and dev.upgrades == 0, "another model -> exit 6, nothing sent")

    class Stuck(FakeFM1):          # the loader never shows up
        def boot(self, identity, name):
            super().boot(identity, name)
            if identity.startswith("ota-"):
                self.connected = False
    rc, out, err = cli([p, "--yes"], Stuck(image))
    ok(rc == 5 and "loader did not appear" in err, "no loader after step 1 -> exit 5")

    plain = pkgfile("plain.fwsc", package(marker=False))
    dev = FakeFM1(image)
    rc, out, err = cli([plain, "--yes"], dev)
    ok(rc == 2 and "no Felucca update loader" in err and dev.sent == [], "package without the loader marker -> exit 2, no MIDI")
    dev = FakeFM1(I.logical_image(package(marker=False)))
    rc, out, err = cli([plain, "--yes", "--force"], dev)
    ok(rc == 0 and dev.bad == 0, "... installs with --force")
    rc, out, err = cli([pkgfile("short.fwsc", b"\0" * 100), "--yes"], FakeFM1(image))
    ok(rc == 2 and "too short" in err, "not a package -> exit 2")
    rc, out, err = cli([str(TMP / "missing.fwsc"), "--yes"], FakeFM1(image))
    ok(rc == 2, "missing file -> exit 2")


def from_open():
    """M-VAVE's FM1 Open firmware: back to M-VAVE's own firmware (any version) only, after arming its updater"""
    sha = lambda raw: __import__("hashlib").sha256(raw).digest()
    stock_raw = package("FM-1_015", marker=False)
    stock, ours = pkgfile("FM-1.fwsc", stock_raw), pkgfile("ours.fwsc", package())
    image = I.logical_image(stock_raw)
    dev = FakeFM1(image, identity="FM1_OFFICIAL_OPEN", name="FM1 Community", after_write="FM-1_015")
    rc, out, err = cli([stock, "--yes"], dev)
    ok(rc == 0 and dev.bad == 0 and len(dev.arms) == 1 and dev.arms[0][6:] == sha(stock_raw)
       and "done: the FM-1 runs FM-1_015" in out, "Open -> stock V15: armed (length, its SHA-256), no --force needed")
    v16_raw = package("FM-1_016", marker=False)
    dev = FakeFM1(I.logical_image(v16_raw), identity="FM1_OFFICIAL_OPEN", name="FM1 Community", after_write="FM-1_016")
    rc, out, err = cli([pkgfile("FM-1-v16.fwsc", v16_raw), "--yes"], dev)
    ok(rc == 0 and len(dev.arms) == 1 and dev.arms[0][6:] == sha(v16_raw), "... stock V16 too: any M-VAVE version")
    dev = FakeFM1(image, identity="FM1_COMMUNITY_3", name="FM1 Community", after_write="FM-1_015")
    rc, out, err = cli([stock, "--yes"], dev)
    ok(rc == 0 and len(dev.arms) == 1, "... a community build (FM1_COMMUNITY_n) too")
    dev = FakeFM1(I.logical_image(package()), identity="FM1_OFFICIAL_OPEN", name="FM1 Community")
    rc, out, err = cli([ours, "--yes"], dev)
    ok(rc == 6 and "stock firmware back first" in err and dev.arms == [] and dev.upgrades == 0,
       "Open -> one of ours: refused, nothing sent (stock first)")
    dev = FakeFM1(image, identity="FM1_OFFICIAL_OPEN", name="FM1 Community", refuse_arm=True)
    rc, out, err = cli([stock, "--yes"], dev)
    ok(rc == 4 and "refused" in err and dev.upgrades == 0, "Open refuses the arming -> exit 4, nothing written")
    rc, out, err = cli(["--info"], FakeFM1(image, identity="FM1_OFFICIAL_OPEN", name="FM1 Community"))
    ok(rc == 0 and "FM1_OFFICIAL_OPEN" in out, "--info finds Open on its own port name")


def against_js():
    clean = ROOT / "template/build/template.fwsc"
    if not shutil.which("node") or not clean.exists():
        print("logical image vs fm1pkg.js: skipped (needs node and template/build/template.fwsc)")
        return
    js = ("import { logicalImage, productOf } from %r; import { readFileSync } from 'node:fs';"
          "const p = readFileSync(process.argv[1]); process.stderr.write(productOf(p));"
          "process.stdout.write(logicalImage(p));") % str(ROOT / "web/fm1pkg.js")
    r = subprocess.run(["node", "--input-type=module", "-e", js, str(clean)], capture_output=True, check=True)
    raw = clean.read_bytes()
    ok(I.logical_image(raw) == r.stdout and I.product_of(raw) == r.stderr.decode(),
       f"logical_image / product_of == fm1pkg.js ({clean.name}, {I.product_of(raw)})")
    ok(I.LOADER_MARK in raw, f"{clean.name} carries the Felucca loader marker")


wire()
installs()
errors()
from_open()
against_js()
shutil.rmtree(TMP, ignore_errors=True)
print(f"INSTALL TESTS FAILED ({failed})" if failed else "install tests passed")
sys.exit(1 if failed else 0)
