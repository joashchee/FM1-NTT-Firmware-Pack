@gcc %* -lpthread
